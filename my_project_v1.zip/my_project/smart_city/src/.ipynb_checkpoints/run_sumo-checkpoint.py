import argparse
import importlib
import os
from pathlib import Path
from typing import Type

import traci

import tripinfo_calculator
from controller import IntersectionController


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data" / "sumo"
DEFAULT_SUMO_CFG = str(DATA_DIR / "osm.net_cut.sumocfg")
DEFAULT_TRIPINFO = str(BASE_DIR / "result" / "tripinfo.xml")
VERBOSE_STEPS = 600


def load_participant_controller(module_name: str) -> Type[IntersectionController]:
    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        raise RuntimeError(
            f"Не удалось импортировать модуль '{module_name}'. Проверьте PARTICIPANT_MODULE/--participant-module."
        ) from exc

    controller_cls = getattr(module, "ParticipantController", None)
    if controller_cls is None:
        raise RuntimeError(f"В модуле '{module_name}' отсутствует класс ParticipantController.")
    if not issubclass(controller_cls, IntersectionController):
        raise TypeError("ParticipantController должен наследоваться от IntersectionController.")
    return controller_cls


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Запуск симуляции SUMO с контроллером участника.")
    parser.add_argument("--sumo-cfg", default=DEFAULT_SUMO_CFG, help="Путь до конфигурации SUMO.")
    parser.add_argument(
        "--participant-module",
        default=os.environ.get("PARTICIPANT_MODULE", "participant_controller"),
        help="Python-модуль с классом ParticipantController.",
    )
    parser.add_argument("--steps", type=int, default=3600, help="Количество шагов симуляции.")
    parser.add_argument("--tls-id", default=None, help="ID светофора (если None, управляем всеми).")
    return parser


def create_controller(module_name: str, tls_id: str):
    controller_cls = load_participant_controller(module_name)
    return controller_cls(tls_ids=tls_id)


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    tripinfo_file = os.environ.get("TRIPINFO_OUTPUT", DEFAULT_TRIPINFO)
    tripinfo_path = Path(tripinfo_file)
    tripinfo_path.parent.mkdir(parents=True, exist_ok=True)
    if tripinfo_path.exists():
        tripinfo_path.unlink()

    cmd = ["sumo", "-c", args.sumo_cfg, "--tripinfo-output", str(tripinfo_path)]
    print(f"Запуск SUMO с конфигом: {args.sumo_cfg}")
    traci.start(cmd)
    print("SUMO запущен. Начинаем симуляцию")
    controller = create_controller(args.participant_module, args.tls_id)
    print(f"Управляем светофорами: {controller.tls_ids}")

    try:
        for step in range(args.steps):
            traci.simulationStep()
            controller.step()
            if (step + 1) % VERBOSE_STEPS == 0:
                print(f"Прогресс: {step + 1}/{args.steps} шагов")
    finally:
        traci.close()

    print(f"Симуляция завершена. Файл tripinfo: {tripinfo_path}")
    metrics = tripinfo_calculator.calculate_metrics(str(tripinfo_path))
    tripinfo_calculator.print_metrics(metrics)
    tripinfo_calculator.save_result_json(metrics)


if __name__ == "__main__":
    main()
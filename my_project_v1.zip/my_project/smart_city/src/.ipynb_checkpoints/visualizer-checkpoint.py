import pygame
import numpy as np
from typing import Dict, List, Tuple
import traci
import time

class SUMOVisualizer:
    def __init__(self, 
                 screen_width: int = 1200,
                 screen_height: int = 800,
                 scale: float = 2.0):
        """
        Визуализатор SUMO с PyGame
        
        :param screen_width: ширина экрана
        :param screen_height: высота экрана
        :param scale: масштаб карты
        """
        pygame.init()
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.scale = scale
        
        # Цвета
        self.colors = {
            'background': (240, 240, 240),
            'road': (100, 100, 100),
            'lane_markings': (255, 255, 255),
            'vehicle': (70, 130, 180),  # стальной синий
            'bus': (220, 20, 60),       # красный
            'truck': (34, 139, 34),     # зеленый лесной
            'junction': (50, 50, 50),
            'traffic_light_red': (255, 0, 0),
            'traffic_light_yellow': (255, 255, 0),
            'traffic_light_green': (0, 255, 0),
            'traffic_light_grey': (100, 100, 100),
            'detector': (255, 165, 0),  # оранжевый
            'text': (0, 0, 0),
            'info_panel': (255, 255, 255, 200),
            'chart_background': (255, 255, 255)
        }
        
        # Создаем окно
        self.screen = pygame.display.set_mode((screen_width, screen_height))
        pygame.display.set_caption("Адаптивное управление светофорами - RL Visualizer")
        
        # Шрифты
        self.font_small = pygame.font.SysFont('Arial', 12)
        self.font_medium = pygame.font.SysFont('Arial', 14, bold=True)
        self.font_large = pygame.font.SysFont('Arial', 18, bold=True)
        
        # Смещение для центрирования карты
        self.offset_x = screen_width // 2
        self.offset_y = screen_height // 2
        
        # Данные для графиков
        self.waiting_times = []
        self.queue_lengths = []
        self.throughput_history = []
        self.max_history_points = 100
        
        # Словарь для хранения геометрии дорог
        self.roads = {}
        
        # Флаг паузы
        self.paused = False
        
    def convert_coords(self, x: float, y: float) -> Tuple[int, int]:
        """Конвертирует SUMO координаты в экранные"""
        screen_x = int(x * self.scale + self.offset_x)
        screen_y = int(-y * self.scale + self.offset_y)
        return screen_x, screen_y
    
    def draw_road_network(self):
        """Рисует дорожную сеть"""
        # Получаем список ребер
        edges = traci.edge.getIDList()
        
        for edge_id in edges:
            # Получаем форму ребра (список точек)
            shape = traci.edge.getShape(edge_id)
            if len(shape) < 2:
                continue
            
            # Рисуем дорогу
            for i in range(len(shape) - 1):
                x1, y1 = self.convert_coords(shape[i][0], shape[i][1])
                x2, y2 = self.convert_coords(shape[i+1][0], shape[i+1][1])
                
                # Основная дорога (толстая)
                pygame.draw.line(self.screen, self.colors['road'], 
                               (x1, y1), (x2, y2), 6)
                
                # Разметка (тонкая белая)
                pygame.draw.line(self.screen, self.colors['lane_markings'],
                               (x1, y1), (x2, y2), 1)
    
    def draw_vehicles(self):
        """Рисует все транспортные средства"""
        vehicles = traci.vehicle.getIDList()
        
        for veh_id in vehicles:
            try:
                pos = traci.vehicle.getPosition(veh_id)
                angle = traci.vehicle.getAngle(veh_id)
                veh_type = traci.vehicle.getTypeID(veh_id)
                
                x, y = self.convert_coords(pos[0], pos[1])
                
                # Цвет в зависимости от типа ТС
                if 'bus' in veh_type.lower():
                    color = self.colors['bus']
                elif 'truck' in veh_type.lower():
                    color = self.colors['truck']
                else:
                    color = self.colors['vehicle']
                
                # Определяем размер в зависимости от скорости
                speed = traci.vehicle.getSpeed(veh_id)
                size = max(4, min(8, speed / 5))
                
                # Рисуем прямоугольник (повернутый по направлению движения)
                vehicle_rect = pygame.Rect(0, 0, size*3, size)
                vehicle_rect.center = (x, y)
                
                # Поворот прямоугольника
                rotated_surface = pygame.Surface((vehicle_rect.width, vehicle_rect.height), 
                                               pygame.SRCALPHA)
                pygame.draw.rect(rotated_surface, color, 
                               (0, 0, vehicle_rect.width, vehicle_rect.height))
                rotated_surface = pygame.transform.rotate(rotated_surface, -angle)
                
                # Центрируем повернутый прямоугольник
                rotated_rect = rotated_surface.get_rect(center=(x, y))
                self.screen.blit(rotated_surface, rotated_rect)
                
                # Если скорость низкая, рисуем индикатор задержки
                if speed < 0.5:
                    pygame.draw.circle(self.screen, (255, 100, 100), (x, y), 2)
                    
            except traci.TraCIException:
                continue
    
    def draw_traffic_lights(self):
        """Рисует светофоры и их текущее состояние"""
        tls_list = traci.trafficlight.getIDList()
        
        for tls_id in tls_list:
            try:
                # Получаем позицию светофора
                pos = traci.junction.getPosition(tls_id)
                x, y = self.convert_coords(pos[0], pos[1])
                
                # Получаем текущее состояние
                state = traci.trafficlight.getRedYellowGreenState(tls_id)
                current_phase = traci.trafficlight.getPhase(tls_id)
                next_switch = traci.trafficlight.getNextSwitch(tls_id)
                current_time = traci.simulation.getTime()
                
                # Рисуем светофор
                radius = 10
                pygame.draw.circle(self.screen, self.colors['junction'], (x, y), radius)
                
                # Рисуем индикаторы состояния
                offset = 15
                for i, signal in enumerate(state[:4]):  # берем первые 4 сигнала для отображения
                    color = self.colors['traffic_light_grey']
                    if signal == 'r':
                        color = self.colors['traffic_light_red']
                    elif signal == 'y':
                        color = self.colors['traffic_light_yellow']
                    elif signal == 'G' or signal == 'g':
                        color = self.colors['traffic_light_green']
                    
                    # Позиция индикатора вокруг светофора
                    indicator_x = x + offset * np.cos(i * np.pi/2)
                    indicator_y = y + offset * np.sin(i * np.pi/2)
                    
                    pygame.draw.circle(self.screen, color, 
                                     (int(indicator_x), int(indicator_y)), 4)
                
                # Отображаем информацию
                info_text = f"TLS: {tls_id[:8]}"
                info_surface = self.font_small.render(info_text, True, self.colors['text'])
                self.screen.blit(info_surface, (x - 20, y - 25))
                
                time_text = f"Phase: {current_phase}, Next: {next_switch - current_time:.0f}s"
                time_surface = self.font_small.render(time_text, True, self.colors['text'])
                self.screen.blit(time_surface, (x - 30, y + 15))
                
            except traci.TraCIException:
                continue
    
    def draw_detectors(self):
        """Рисует детекторы транспортных средств"""
        detectors = traci.inductionloop.getIDList()
        
        for det_id in detectors:
            try:
                lane_id = traci.inductionloop.getLaneID(det_id)
                if not lane_id:
                    continue
                    
                # Получаем позицию детектора
                pos = traci.inductionloop.getPosition(det_id)
                x, y = self.convert_coords(pos[0], pos[1])
                
                # Получаем загруженность детектора
                occupancy = traci.inductionloop.getLastStepOccupancy(det_id)
                
                # Цвет в зависимости от загруженности
                intensity = min(255, int(occupancy * 255 * 10))
                detector_color = (255, 255 - intensity, 0)
                
                # Рисуем детектор
                pygame.draw.circle(self.screen, detector_color, (int(x), int(y)), 5)
                pygame.draw.circle(self.screen, (0, 0, 0), (int(x), int(y)), 5, 1)
                
                # Отображаем ID детектора
                if occupancy > 0.1:  # показываем только активные
                    text = self.font_small.render(f"{det_id[-3:]}", True, self.colors['text'])
                    self.screen.blit(text, (int(x) + 8, int(y) - 5))
                    
            except traci.TraCIException:
                continue
    
    def draw_info_panel(self, step: int, metrics: Dict):
        """Рисует панель с информацией и графиками"""
        # Полупрозрачная панель
        panel_height = 200
        panel_surface = pygame.Surface((self.screen_width, panel_height), pygame.SRCALPHA)
        panel_surface.fill(self.colors['info_panel'])
        self.screen.blit(panel_surface, (0, self.screen_height - panel_height))
        
        # Текущее время симуляции
        sim_time = traci.simulation.getTime()
        time_text = f"Шаг: {step} | Время симуляции: {sim_time:.1f} с"
        time_surface = self.font_large.render(time_text, True, self.colors['text'])
        self.screen.blit(time_surface, (20, self.screen_height - panel_height + 10))
        
        # Основные метрики
        y_offset = self.screen_height - panel_height + 40
        metrics_text = [
            f"Транспортных средств: {traci.vehicle.getIDCount()}",
            f"Средняя скорость: {self.get_average_speed():.1f} м/с",
            f"Стоящих ТС: {self.get_stopped_vehicles()}",
            f"Общая длина очередей: {self.get_total_queue_length():.0f} м"
        ]
        
        for i, text in enumerate(metrics_text):
            metric_surface = self.font_medium.render(text, True, self.colors['text'])
            self.screen.blit(metric_surface, (20, y_offset + i * 25))
        
        # Рисуем график средней задержки
        self.draw_chart(800, self.screen_height - panel_height + 10, 
                       self.waiting_times, "Средняя задержка (с)", (0, 100))
        
        # Рисуем график длины очередей
        self.draw_chart(800, self.screen_height - panel_height + 110,
                       self.queue_lengths, "Длина очередей (м)", (0, 200))
        
        # Инструкции
        instructions = [
            "Управление:",
            "P - Пауза/Продолжить",
            "R - Сбросить симуляцию",
            "S - Сохранить скриншот",
            "+/- - Изменить масштаб"
        ]
        
        x_offset = self.screen_width - 250
        for i, text in enumerate(instructions):
            instr_surface = self.font_small.render(text, True, (50, 50, 150))
            self.screen.blit(instr_surface, (x_offset, y_offset + i * 20))
    
    def draw_chart(self, x: int, y: int, data: List[float], title: str, y_range: Tuple[float, float]):
        """Рисует простой график"""
        width, height = 350, 80
        chart_surface = pygame.Surface((width, height))
        chart_surface.fill(self.colors['chart_background'])
        
        # Рисуем рамку
        pygame.draw.rect(chart_surface, (0, 0, 0), (0, 0, width, height), 1)
        
        if len(data) > 1:
            # Нормализуем данные
            y_min, y_max = y_range
            points = []
            
            for i, value in enumerate(data[-100:]):  # последние 100 точек
                x_pos = i * width / min(100, len(data))
                y_pos = height - ((value - y_min) / (y_max - y_min)) * height
                y_pos = max(0, min(height, y_pos))
                points.append((x_pos, y_pos))
            
            # Рисуем линию
            if len(points) > 1:
                pygame.draw.lines(chart_surface, (70, 130, 180), False, points, 2)
        
        # Отображаем заголовок
        title_surface = self.font_small.render(title, True, self.colors['text'])
        chart_surface.blit(title_surface, (5, 5))
        
        # Отображаем текущее значение
        if data:
            current_value = data[-1]
            value_text = f"{current_value:.1f}"
            value_surface = self.font_small.render(value_text, True, self.colors['text'])
            chart_surface.blit(value_surface, (width - 40, 5))
        
        self.screen.blit(chart_surface, (x, y))
    
    def get_average_speed(self) -> float:
        """Вычисляет среднюю скорость всех ТС"""
        vehicles = traci.vehicle.getIDList()
        if not vehicles:
            return 0.0
        
        total_speed = 0
        count = 0
        for veh_id in vehicles:
            try:
                speed = traci.vehicle.getSpeed(veh_id)
                total_speed += speed
                count += 1
            except traci.TraCIException:
                continue
        
        return total_speed / count if count > 0 else 0.0
    
    def get_stopped_vehicles(self) -> int:
        """Считает количество остановившихся ТС (скорость < 0.5 м/с)"""
        vehicles = traci.vehicle.getIDList()
        stopped = 0
        
        for veh_id in vehicles:
            try:
                if traci.vehicle.getSpeed(veh_id) < 0.5:
                    stopped += 1
            except traci.TraCIException:
                continue
        
        return stopped
    
    def get_total_queue_length(self) -> float:
        """Вычисляет общую длину очередей"""
        lanes = traci.lane.getIDList()
        total_length = 0.0
        
        for lane_id in lanes:
            try:
                total_length += traci.lane.getJamLengthMeters(lane_id)
            except traci.TraCIException:
                continue
        
        return total_length
    
    def update_metrics(self):
        """Обновляет метрики для графиков"""
        # Средняя задержка
        vehicles = traci.vehicle.getIDList()
        total_waiting = 0
        for veh_id in vehicles:
            try:
                total_waiting += traci.vehicle.getWaitingTime(veh_id)
            except:
                continue
        
        avg_waiting = total_waiting / len(vehicles) if vehicles else 0
        self.waiting_times.append(avg_waiting)
        
        # Длина очередей
        total_queue = self.get_total_queue_length()
        self.queue_lengths.append(total_queue)
        
        # Ограничиваем историю
        if len(self.waiting_times) > self.max_history_points:
            self.waiting_times.pop(0)
            self.queue_lengths.pop(0)
    
    def handle_events(self) -> bool:
        """Обрабатывает события PyGame, возвращает False если нужно выйти"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    self.paused = not self.paused
                elif event.key == pygame.K_r:
                    # Сброс метрик
                    self.waiting_times = []
                    self.queue_lengths = []
                    self.throughput_history = []
                elif event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS:
                    self.scale = min(5.0, self.scale * 1.1)
                elif event.key == pygame.K_MINUS:
                    self.scale = max(0.5, self.scale * 0.9)
                elif event.key == pygame.K_s:
                    # Сохранение скриншота
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    filename = f"screenshot_{timestamp}.png"
                    pygame.image.save(self.screen, filename)
                    print(f"Скриншот сохранен как {filename}")
        
        return True
    
    def render(self, step: int, metrics: Dict = None):
        """Основной метод рендеринга"""
        # Очищаем экран
        self.screen.fill(self.colors['background'])
        
        # Рисуем все элементы
        self.draw_road_network()
        self.draw_vehicles()
        self.draw_traffic_lights()
        self.draw_detectors()
        self.draw_info_panel(step, metrics or {})
        
        # Обновляем метрики
        self.update_metrics()
        
        # Обновляем экран
        pygame.display.flip()
        
        # Обрабатываем события
        return self.handle_events()


def run_simulation_with_visualization(
    sumo_cfg_path: str,
    participant_module: str = "participant_controller",
    steps: int = 3600,
    tls_id: str = None
):
    """
    Запускает симуляцию SUMO с визуализацией
    
    :param sumo_cfg_path: путь к конфигурационному файлу SUMO
    :param participant_module: модуль с контроллером
    :param steps: количество шагов симуляции
    :param tls_id: ID светофора (если None, управляем всеми)
    """
    # Импортируем контроллер
    import importlib
    module = importlib.import_module(participant_module)
    controller_cls = getattr(module, "ParticipantController")
    
    # Запускаем SUMO с GUI
    import traci
    from pathlib import Path
    
    tripinfo_path = Path("result/tripinfo.xml")
    tripinfo_path.parent.mkdir(exist_ok=True)
    
    # Запускаем SUMO-GUI вместо SUMO
    cmd = ["sumo-gui", "-c", sumo_cfg_path, "--tripinfo-output", str(tripinfo_path)]
    traci.start(cmd)
    
    # Создаем контроллер
    controller = controller_cls(tls_ids=tls_id)
    
    # Создаем визуализатор
    visualizer = SUMOVisualizer()
    
    # Главный цикл симуляции
    try:
        for step in range(steps):
            # Проверяем паузу
            while visualizer.paused:
                if not visualizer.handle_events():
                    traci.close()
                    pygame.quit()
                    return
                pygame.time.wait(100)
            
            # Шаг симуляции
            traci.simulationStep()
            observation = controller.step()
            
            # Рендеринг
            metrics = {
                "step": step,
                "vehicles": traci.vehicle.getIDCount(),
                "avg_speed": visualizer.get_average_speed(),
                "stopped": visualizer.get_stopped_vehicles()
            }
            
            if not visualizer.render(step, metrics):
                break
            
            # Небольшая задержка для удобного просмотра
            pygame.time.wait(50)
            
            # Вывод прогресса
            if (step + 1) % 100 == 0:
                print(f"Прогресс: {step + 1}/{steps} шагов")
    
    finally:
        traci.close()
        pygame.quit()
    
    # Вычисляем и выводим итоговые метрики
    from tripinfo_calculator import calculate_metrics, print_metrics
    metrics = calculate_metrics(str(tripinfo_path))
    print_metrics(metrics)
    
    print("Симуляция завершена!")


if __name__ == "__main__":
    # Пример использования
    run_simulation_with_visualization(
        sumo_cfg_path="../data/sumo/osm.net_cut.sumocfg",
        steps=1000
    )
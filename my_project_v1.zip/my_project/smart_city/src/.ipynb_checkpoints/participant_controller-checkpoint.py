import os
from typing import Dict, List

from controller import IntersectionController

DEBUG = False

# Стратегии для примера:
#   balanced   — равные доли для всех зелёных фаз
#   ns_bias    — отдаём 45 секунд чётным фазам и только 5 секунд нечётным
STRATEGY = os.environ.get("CONTROL_STRATEGY", "balanced").strip().lower()
STRATEGY = 'balanced'

class ParticipantController(IntersectionController):
    """
    Два простых режима:
    1. balanced — поровну делим зелёное время.
    2. ns_bias — сильно отдаём приоритет чётным фазам (например, север-юг).
       Чтобы попробовать его, раскомментируйте STRATEGY = "ns_bias" выше.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if STRATEGY == "ns_bias":
            even_duration = 45.0
            odd_duration = 5.0
        else:
            even_duration = odd_duration = 30.0

        self.green_phases: Dict[str, List[int]] = {}
        self.cursor: Dict[str, int] = {}
        self.phase_duration: Dict[tuple[str, int], float] = {}

        for tls_id in self.tls_ids:
            phases = self.get_phase_catalog(tls_id)
            greens = [
                phase.index
                for phase in phases
                if "y" not in phase.state and any(ch in ("G", "g") for ch in phase.state)
            ]
            if not greens:
                raise RuntimeError(f"В программе светофора '{tls_id}' нет ни одной зелёной фазы.")
            greens.sort()
            self.green_phases[tls_id] = greens
            self.cursor[tls_id] = 0

            for idx, phase_idx in enumerate(greens):
                duration = even_duration if idx % 2 == 0 else odd_duration
                self.phase_duration[(tls_id, phase_idx)] = duration

    def decide_next_phase(self, observation):
        decision: Dict[str, Dict[str, float]] = {}
        for tls_id in self.tls_ids:
            light_info = observation["lights"][tls_id]
            if light_info["time_to_next_switch"] > 0.5:
                continue

            greens = self.green_phases[tls_id]
            idx = self.cursor[tls_id]
            next_phase = greens[idx]
            self.cursor[tls_id] = (idx + 1) % len(greens)

            duration = self.phase_duration.get((tls_id, next_phase), 30.0)
            action = {
                "phase_id": next_phase,
                "duration": duration,
            }
            if DEBUG:
                print(f"[participant_controller] set {tls_id} -> phase {next_phase} for {duration}s")
            decision[tls_id] = action

        return decision or None

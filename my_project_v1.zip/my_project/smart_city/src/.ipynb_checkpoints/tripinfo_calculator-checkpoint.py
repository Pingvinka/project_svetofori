import xml.etree.ElementTree as ET
import os
import json


Z0 = 3_119_217.10


def calculate_metrics(tripinfo_file_path: str) -> dict:
    """
    Вычисляет метрики на основе tripinfo.xml.
    Args: tripinfo_file_path (str): Путь к файлу tripinfo.xml.
    Returns: dict: Словарь с вычисленными метриками.
    """
    if not os.path.exists(tripinfo_file_path):
        print(f"Файл с логами {tripinfo_file_path} не найден")
        return None

    print(f"Файл с логами {tripinfo_file_path}")

    try:
        tree = ET.parse(tripinfo_file_path)
        root = tree.getroot()

        total_delay = 0
        total_duration = 0
        total_route_length = 0
        total_depart_delay = 0
        vehicle_count = 0

        for trip in root.findall('tripinfo'):
            time_loss_str = trip.get('timeLoss')
            duration_str = trip.get('duration')
            route_length_str = trip.get('routeLength')
            depart_delay_str = trip.get('departDelay')

            time_loss = float(time_loss_str) if time_loss_str is not None else 0.0
            duration = float(duration_str) if duration_str is not None else 0.0
            route_length = float(route_length_str) if route_length_str is not None else 0.0
            depart_delay = float(depart_delay_str) if depart_delay_str is not None else 0.0

            total_depart_delay += depart_delay
            total_duration += duration
            total_route_length += route_length
            total_delay += time_loss
            vehicle_count += 1

        avg_delay = total_delay / vehicle_count if vehicle_count > 0 else 0
        avg_duration = total_duration / vehicle_count if vehicle_count > 0 else 0
        avg_route_length = total_route_length / vehicle_count if vehicle_count > 0 else 0
        efficiency = 1.0 - (total_delay / Z0) if Z0 != 0 else float('nan')

        metrics = {
            'total_vehicles': vehicle_count,
            'total_cumulative_delay_Zn': total_delay,
            'average_delay_per_vehicle': avg_delay,
            'total_duration': total_duration,
            'average_duration': avg_duration,
            'total_route_length': total_route_length,
            'average_route_length': avg_route_length,
            'total_depart_delay': total_depart_delay,
            'efficiency': efficiency,
        }

        return metrics

    except ET.ParseError as e:
        print(f"Ошибка при парсинге XML файла: {e}")
        return None
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        return None

def print_metrics(metrics):
    if metrics is None:
        print("Нет данных для печати.")
        return

    print("\n📊 --- Результаты метрик ---", flush=True)
    print(f"Количество транспортных средств (N): {metrics['total_vehicles']}", flush=True)
    print(f"Общая совокупная задержка (Zn, сумма timeLoss): {metrics['total_cumulative_delay_Zn']:.2f} сек", flush=True)
    print(f"Средняя задержка на ТС: {metrics['average_delay_per_vehicle']:.2f} сек", flush=True)
    print(f"Общая продолжительность поездок: {metrics['total_duration']:.2f} сек", flush=True)
    print(f"Средняя продолжительность поездки: {metrics['average_duration']:.2f} сек", flush=True)
    print(f"Общая длина маршрутов: {metrics['total_route_length']:.2f} м", flush=True)
    print(f"Средняя длина маршрута: {metrics['average_route_length']:.2f} м", flush=True)
    print(f"Общая задержка отправления: {metrics['total_depart_delay']:.2f} сек", flush=True)
    print(f"Эффективность (1 - Zn/Z0): {metrics['efficiency']:.6f}", flush=True)
    print("----------------------------\n", flush=True)

def save_result_json(metrics, output_dir="result"):
    """
    Сохраняет результат в JSON-файл в каталоге `result` в формате AllCups.
    """
    os.makedirs(output_dir, exist_ok=True)

    result_path = os.path.join(output_dir, "result.json")

    if metrics is None:
        result = {
            "status": "ERR",
            "errors": ["Не удалось вычислить метрики. Проверьте файл tripinfo.xml и повторите попытку"]
        }
    else:
        efficiency = metrics.get('efficiency', 0.0)
        result = {
            "status": "OK",
            "validationQuality": efficiency,
            "testingQuality": efficiency
        }

    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"Результат записан в {result_path}", flush=True)
    print("Содержимое result.json:")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


def main():
    tripinfo_filename = "tripinfo.xml"
    tripinfo_path = os.path.join(os.getcwd(), tripinfo_filename)
    metrics = calculate_metrics(tripinfo_path)
    print_metrics(metrics)
    save_result_json(metrics)

if __name__ == "__main__":
    main()

# ============================================
# download_krasnodar_map.py
# ============================================

import os
import subprocess
from pathlib import Path
import urllib.request
import time

def download_krasnodar_map():
    """Скачивает карту Краснодара из OpenStreetMap и конвертирует в формат SUMO"""
    
    print("="*70)
    print("ЗАГРУЗКА КАРТЫ КРАСНОДАРА ИЗ OPENSTREETMAP")
    print("="*70)
    
    # Координаты Краснодара (bounding box)
    # Формат: левая_долгота, нижняя_широта, правая_долгота, верхняя_широта
    KRASNODAR_BBOX = "38.87,45.01,39.20,45.13"  # Центр Краснодара
    
    # Пути
    project_root = Path.cwd()
    data_dir = project_root / "smart_city" / "data" / "sumo"
    data_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. Скачиваем OSM файл
    print("\n1. Скачиваем карту Краснодара с OpenStreetMap...")
    osm_file = data_dir / "krasnodar.osm.xml"
    url = f"https://api.openstreetmap.org/api/0.6/map?bbox={KRASNODAR_BBOX}"
    
    try:
        # Скачиваем файл
        print(f"   URL: {url}")
        print(f"   Сохраняем как: {osm_file}")
        
        urllib.request.urlretrieve(url, osm_file)
        print(f"   ✅ Файл скачан успешно!")
        
        # Проверяем размер
        size_mb = osm_file.stat().st_size / (1024 * 1024)
        print(f"   Размер: {size_mb:.1f} МБ")
        
    except Exception as e:
        print(f"   ❌ Ошибка скачивания: {e}")
        print(f"\n   Альтернативный вариант: загрузите вручную с:")
        print(f"   https://www.openstreetmap.org/export#map=13/45.0352/39.0345")
        print(f"   И сохраните как: {osm_file}")
        return None
    
    # 2. Конвертируем OSM в SUMO формат
    print("\n2. Конвертируем OSM в SUMO формат...")
    
    # Пути к утилитам SUMO
    sumo_home = os.environ.get('SUMO_HOME', 'C:/Program Files (x86)/Eclipse/Sumo')
    netconvert = os.path.join(sumo_home, 'bin', 'netconvert.exe')
    polyconvert = os.path.join(sumo_home, 'bin', 'polyconvert.exe')
    
    if not os.path.exists(netconvert):
        print(f"   ❌ netconvert.exe не найден!")
        print(f"   Проверьте путь: {netconvert}")
        return None
    
    # 2.1 Конвертируем дорожную сеть
    net_file = data_dir / "krasnodar.net.xml"
    print(f"   Создаем дорожную сеть: {net_file.name}")
    
    cmd_netconvert = [
        netconvert,
        "--osm-files", str(osm_file),
        "-o", str(net_file),
        "--geometry.remove", "true",
        "--ramps.guess", "true",
        "--roundabouts.guess", "true",
        "--junctions.join", "true",
        "--tls.guess-signals", "true",
        "--tls.discard-simple", "true",
        "--tls.join", "true",
        "--output.original-names", "true",
        "--street-sign-output", "true"
    ]
    
    try:
        result = subprocess.run(cmd_netconvert, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            print(f"   ✅ Дорожная сеть создана!")
            
            # Показываем статистику
            if "nodes:" in result.stdout:
                for line in result.stdout.split('\n'):
                    if "nodes:" in line or "edges:" in line or "junctions:" in line:
                        print(f"   {line.strip()}")
        else:
            print(f"   ❌ Ошибка конвертации: {result.stderr}")
            return None
            
    except subprocess.TimeoutExpired:
        print(f"   ⏱️  Конвертация заняла слишком много времени")
        return None
    
    # 2.2 Конвертируем здания и полигоны (для красоты)
    poly_file = data_dir / "krasnodar.poly.xml"
    print(f"\n3. Создаем полигоны (здания, парки и т.д.): {poly_file.name}")
    
    cmd_polyconvert = [
        polyconvert,
        "--osm-files", str(osm_file),
        "--net-file", str(net_file),
        "-o", str(poly_file),
        "--type-file", os.path.join(sumo_home, 'data', 'typemap', 'osmPolygons.typ.xml')
    ]
    
    try:
        result = subprocess.run(cmd_polyconvert, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            print(f"   ✅ Полигоны созданы!")
            
            # Проверяем создание файла
            if poly_file.exists():
                size_kb = poly_file.stat().st_size / 1024
                print(f"   Размер файла полигонов: {size_kb:.1f} КБ")
        else:
            print(f"   ⚠️  Ошибка создания полигонов: {result.stderr}")
            # Это не критично, продолжаем без полигонов
    
    except Exception as e:
        print(f"   ⚠️  Ошибка при создании полигонов: {e}")
        # Продолжаем без полигонов
    
    # 3. Создаем конфигурационный файл для новой карты
    print("\n4. Создаем конфигурационный файл SUMO...")
    sumo_cfg = data_dir / "krasnodar.sumocfg"
    
    cfg_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<configuration xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/sumoConfiguration.xsd">
    <input>
        <net-file value="{net_file.name}"/>
        <additional-files value="{poly_file.name}"/>
        <route-files value="krasnodar_routes.rou.xml"/>
    </input>
    
    <time>
        <begin value="0"/>
        <end value="3600"/>
        <step-length value="1"/>
    </time>
    
    <processing>
        <ignore-route-errors value="true"/>
        <time-to-teleport value="300"/>
        <time-to-teleport.highways value="60"/>
    </processing>
    
    <report>
        <verbose value="true"/>
        <no-step-log value="true"/>
    </report>
    
    <gui_only>
        <gui-settings-file value="krasnodar_viewsettings.xml"/>
        <delay value="100"/>
        <start value="true"/>
    </gui_only>
</configuration>"""
    
    with open(sumo_cfg, 'w', encoding='utf-8') as f:
        f.write(cfg_content)
    
    print(f"   ✅ Конфиг создан: {sumo_cfg.name}")
    
    # 4. Создаем настройки отображения для красоты
    print("\n5. Создаем настройки отображения...")
    viewsettings_file = data_dir / "krasnodar_viewsettings.xml"
    
    viewsettings_content = '''<?xml version="1.0" encoding="UTF-8"?>
<viewsettings xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/viewSettingsFile.xsd">
    <!-- Яркая цветовая схема для Краснодара -->
    <scheme name="krasnodar_bright">
        <!-- Цвета дорог -->
        <background backgroundColor="240,240,240"/>
        <lane colorRoad="200,200,200" colorRailway="150,150,150"/>
        <vehicle colorCar="50,100,200" colorBus="220,50,50" colorTruck="50,180,50" colorBicycle="255,165,0"/>
        
        <!-- Здания -->
        <junction color="80,80,80"/>
        <poi color="150,100,50"/>
        
        <!-- Детекторы и светофоры -->
        <tlLogic color="255,200,0"/>
        <detector color="255,100,100"/>
        
        <!-- Декорации -->
        <selection color="255,255,0,128"/>
        <grid color="220,220,220,100"/>
    </scheme>
    
    <viewport zoom="1500" x="3987910.48" y="5579972.36"/>
    <delay value="100"/>
    
    <!-- Визуальные эффекты -->
    <vehicles value="true">
        <exaggeration value="1.2"/>
        <showBlinker value="true"/>
        <drawCarriages value="true"/>
    </vehicles>
    
    <edges value="true">
        <showLaneDirection value="true"/>
        <showLinkRules value="true"/>
        <showLinkDecals value="true"/>
        <widthExaggeration value="1.5"/>
    </edges>
    
    <junctions value="true">
        <size value="2.0"/>
    </junctions>
</viewsettings>'''
    
    with open(viewsettings_file, 'w', encoding='utf-8') as f:
        f.write(viewsettings_content)
    
    print(f"   ✅ Настройки отображения созданы: {viewsettings_file.name}")
    
    # 5. Создаем простые маршруты для теста
    print("\n6. Создаем тестовые маршруты...")
    routes_file = data_dir / "krasnodar_routes.rou.xml"
    
    # Сначала нужно узнать ID ребер в сети
    print("   (Сначала нужно запустить симуляцию чтобы увидеть доступные маршруты)")
    print("   Пока создаем простой файл маршрутов")
    
    routes_content = '''<?xml version="1.0" encoding="UTF-8"?>
<routes xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/routes_file.xsd">
    <!-- Разнообразные типы транспортных средств -->
    <vType id="passenger_car" vClass="passenger" accel="2.6" decel="4.5" sigma="0.5" length="5.0" maxSpeed="50" color="50,100,200"/>
    <vType id="sports_car" vClass="passenger" accel="3.5" decel="6.0" sigma="0.3" length="4.5" maxSpeed="80" color="255,50,50"/>
    <vType id="bus" vClass="bus" accel="1.2" decel="3.0" sigma="0.5" length="12.0" maxSpeed="40" color="220,50,50"/>
    <vType id="truck" vClass="truck" accel="1.0" decel="2.5" sigma="0.5" length="16.0" maxSpeed="35" color="50,180,50"/>
    <vType id="delivery_van" vClass="delivery" accel="1.8" decel="4.0" sigma="0.4" length="6.0" maxSpeed="45" color="255,165,0"/>
    <vType id="bicycle" vClass="bicycle" accel="0.8" decel="1.5" sigma="0.5" length="1.8" maxSpeed="25" color="255,100,100"/>
    <vType id="motorcycle" vClass="motorcycle" accel="3.0" decel="5.0" sigma="0.4" length="2.2" maxSpeed="70" color="150,50,200"/>
    
    <!-- Временные маршруты (будут заменены после анализа сети) -->
    <route id="route0" edges="edge1 edge2 edge3"/>
    <route id="route1" edges="edge4 edge5 edge6"/>
    
    <!-- Некоторые транспортные средства для теста -->
    <flow id="car_flow" type="passenger_car" route="route0" begin="0" end="3600" period="5"/>
    <flow id="bus_flow" type="bus" route="route1" begin="0" end="3600" period="30"/>
    
</routes>'''
    
    with open(routes_file, 'w', encoding='utf-8') as f:
        f.write(routes_content)
    
    print(f"   ✅ Файл маршрутов создан (нужно будет доработать)")
    
    print("\n" + "="*70)
    print("ГОТОВО! Карта Краснодара создана.")
    print("="*70)
    
    print(f"\n📁 СОЗДАННЫЕ ФАЙЛЫ:")
    print(f"   1. {osm_file.name} - OSM карта Краснодара")
    print(f"   2. {net_file.name} - Дорожная сеть SUMO")
    print(f"   3. {poly_file.name} - Здания и полигоны")
    print(f"   4. {sumo_cfg.name} - Конфигурация симуляции")
    print(f"   5. {routes_file.name} - Маршруты (требует доработки)")
    
    print(f"\n🚀 Для запуска симуляции используйте:")
    print(f"   sumo-gui -c {sumo_cfg}")
    
    return {
        'osm': osm_file,
        'net': net_file,
        'poly': poly_file,
        'cfg': sumo_cfg,
        'routes': routes_file
    }

if __name__ == "__main__":
    download_krasnodar_map()
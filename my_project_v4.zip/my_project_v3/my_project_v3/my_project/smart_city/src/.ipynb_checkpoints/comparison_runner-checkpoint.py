# comparison_runner.py
import os
import json
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import traci
from typing import Dict, List, Tuple
from dataclasses import dataclass

from tripinfo_calculator import calculate_metrics

@dataclass
class StrategyResult:
    """Результаты одной стратегии"""
    name: str
    metrics: Dict
    simulation_time: float
    steps: int
    config: Dict

class StrategyComparison:
    """Сравнение различных стратегий управления светофорами"""
    
    def __init__(self, sumo_cfg_path: str, result_dir: str = "result"):
        self.sumo_cfg_path = sumo_cfg_path
        self.result_dir = Path(result_dir)
        self.result_dir.mkdir(exist_ok=True)
        
        # Создаем подпапку для сравнения
        self.comparison_dir = self.result_dir / "comparison"
        self.comparison_dir.mkdir(exist_ok=True)
        
        self.results: List[StrategyResult] = []
        
    def run_strategy(self, strategy_name: str, controller_class, 
                    steps: int = 1000, **kwargs) -> StrategyResult:
        """
        Запускает симуляцию с определенной стратегией
        
        Args:
            strategy_name: название стратегии
            controller_class: класс контроллера
            steps: количество шагов симуляции
            **kwargs: параметры для контроллера
        """
        print(f"\n{'='*60}")
        print(f"Запуск стратегии: {strategy_name}")
        print(f"{'='*60}")
        
        # Создаем уникальный файл результатов
        timestamp = int(time.time())
        tripinfo_path = self.result_dir / f"tripinfo_{strategy_name}_{timestamp}.xml"
        
        # Команда SUMO
        cmd = [
            "sumo",
            "-c", self.sumo_cfg_path,
            "--tripinfo-output", str(tripinfo_path),
            "--no-warnings", "true",
            "--duration-log.disable", "true",
            "--no-step-log", "true",
            "--time-to-teleport", "300"
        ]
        
        start_time = time.time()
        
        try:
            # Закрываем предыдущие соединения
            try:
                traci.close()
            except:
                pass
            
            # Запускаем SUMO
            traci.start(cmd)
            
            # Создаем контроллер
            controller = controller_class(**kwargs)
            
            # Запускаем симуляцию
            for step in range(steps):
                traci.simulationStep()
                controller.step()
                
                # Прогресс каждые 100 шагов
                if (step + 1) % 100 == 0:
                    vehicles = traci.vehicle.getIDCount()
                    print(f"  Шаг {step+1:4}/{steps} | ТС: {vehicles:3d}")
            
            # Завершаем
            traci.close()
            
            # Вычисляем время
            simulation_time = time.time() - start_time
            
            # Анализируем результаты
            metrics = calculate_metrics(str(tripinfo_path))
            
            if metrics:
                result = StrategyResult(
                    name=strategy_name,
                    metrics=metrics,
                    simulation_time=simulation_time,
                    steps=steps,
                    config=kwargs
                )
                
                self.results.append(result)
                
                print(f"\n✅ Стратегия завершена:")
                print(f"   Время: {simulation_time:.1f} сек")
                print(f"   Эффективность: {metrics.get('efficiency', 0):.4f}")
                print(f"   Средняя задержка: {metrics.get('average_delay_per_vehicle', 0):.2f} сек")
                
                return result
            else:
                print("❌ Не удалось получить метрики")
                return None
                
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def save_comparison_results(self):
        """Сохраняет результаты сравнения"""
        if not self.results:
            print("Нет результатов для сохранения")
            return
        
        # Сохраняем в JSON
        results_data = []
        for result in self.results:
            results_data.append({
                'name': result.name,
                'simulation_time': result.simulation_time,
                'steps': result.steps,
                'config': result.config,
                'metrics': result.metrics
            })
        
        # Сохраняем в файл
        output_path = self.comparison_dir / f"comparison_results_{int(time.time())}.json"
        with open(output_path, 'w') as f:
            json.dump(results_data, f, indent=2, default=str)
        
        print(f"\n📊 Результаты сохранены: {output_path}")
        
        # Также сохраняем в CSV для удобства
        self.save_to_csv()
        
        return output_path
    
    def save_to_csv(self):
        """Сохраняет результаты в CSV"""
        if not self.results:
            return
        
        # Создаем DataFrame
        data = []
        for result in self.results:
            row = {
                'strategy': result.name,
                'simulation_time_sec': result.simulation_time,
                'steps': result.steps,
                'efficiency': result.metrics.get('efficiency', 0),
                'total_vehicles': result.metrics.get('total_vehicles', 0),
                'total_delay': result.metrics.get('total_cumulative_delay_Zn', 0),
                'avg_delay': result.metrics.get('average_delay_per_vehicle', 0),
                'avg_duration': result.metrics.get('average_duration', 0),
                'avg_speed_kmh': result.metrics.get('average_speed_kmh', 0),
                'total_route_length_km': result.metrics.get('total_route_length', 0) / 1000,
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        
        # Сохраняем
        csv_path = self.comparison_dir / "comparison_results.csv"
        df.to_csv(csv_path, index=False, encoding='utf-8')
        
        print(f"📄 CSV сохранен: {csv_path}")
        
        return df
    
    def visualize_comparison(self):
        """Визуализирует результаты сравнения"""
        if len(self.results) < 2:
            print("Нужно минимум 2 стратегии для сравнения")
            return
        
        # Создаем графики
        fig = plt.figure(figsize=(15, 10))
        
        strategies = [r.name for r in self.results]
        
        # 1. Эффективность
        ax1 = plt.subplot(2, 3, 1)
        efficiencies = [r.metrics.get('efficiency', 0) for r in self.results]
        bars1 = ax1.bar(strategies, efficiencies, color='skyblue', alpha=0.7)
        ax1.set_title('Эффективность стратегий', fontsize=14, fontweight='bold')
        ax1.set_ylabel('Эффективность', fontsize=12)
        ax1.set_ylim(0, 1.0)
        ax1.grid(True, alpha=0.3, axis='y')
        
        # Добавляем значения на столбцы
        for bar, eff in zip(bars1, efficiencies):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                    f'{eff:.4f}', ha='center', va='bottom', fontsize=10)
        
        # 2. Средняя задержка
        ax2 = plt.subplot(2, 3, 2)
        avg_delays = [r.metrics.get('average_delay_per_vehicle', 0) for r in self.results]
        bars2 = ax2.bar(strategies, avg_delays, color='lightcoral', alpha=0.7)
        ax2.set_title('Средняя задержка на ТС', fontsize=14, fontweight='bold')
        ax2.set_ylabel('Задержка (сек)', fontsize=12)
        ax2.grid(True, alpha=0.3, axis='y')
        
        # 3. Средняя скорость
        ax3 = plt.subplot(2, 3, 3)
        avg_speeds = [r.metrics.get('average_speed_kmh', 0) for r in self.results]
        bars3 = ax3.bar(strategies, avg_speeds, color='lightgreen', alpha=0.7)
        ax3.set_title('Средняя скорость ТС', fontsize=14, fontweight='bold')
        ax3.set_ylabel('Скорость (км/ч)', fontsize=12)
        ax3.grid(True, alpha=0.3, axis='y')
        
        # 4. Общее количество ТС
        ax4 = plt.subplot(2, 3, 4)
        total_vehicles = [r.metrics.get('total_vehicles', 0) for r in self.results]
        bars4 = ax4.bar(strategies, total_vehicles, color='gold', alpha=0.7)
        ax4.set_title('Общее количество ТС', fontsize=14, fontweight='bold')
        ax4.set_ylabel('Количество ТС', fontsize=12)
        ax4.grid(True, alpha=0.3, axis='y')
        
        # 5. Время симуляции
        ax5 = plt.subplot(2, 3, 5)
        sim_times = [r.simulation_time for r in self.results]
        bars5 = ax5.bar(strategies, sim_times, color='violet', alpha=0.7)
        ax5.set_title('Время выполнения симуляции', fontsize=14, fontweight='bold')
        ax5.set_ylabel('Время (сек)', fontsize=12)
        ax5.grid(True, alpha=0.3, axis='y')
        
        # 6. Радарная диаграмма (Radar Chart)
        ax6 = plt.subplot(2, 3, 6, projection='polar')
        
        # Нормализуем метрики для радарной диаграммы
        metrics_for_radar = ['efficiency', 'average_speed_kmh', 'total_vehicles']
        normalized_metrics = {}
        
        for metric in metrics_for_radar:
            values = [r.metrics.get(metric, 0) for r in self.results]
            if max(values) > 0:
                normalized = [v / max(values) for v in values]
            else:
                normalized = [0 for _ in values]
            normalized_metrics[metric] = normalized
        
        # Углы для осей
        angles = np.linspace(0, 2 * np.pi, len(metrics_for_radar), endpoint=False).tolist()
        angles += angles[:1]  # Замыкаем круг
        
        # Рисуем для каждой стратегии
        for i, strategy in enumerate(strategies):
            values = []
            for metric in metrics_for_radar:
                values.append(normalized_metrics[metric][i])
            values += values[:1]  # Замыкаем круг
            
            ax6.plot(angles, values, 'o-', linewidth=2, label=strategy)
            ax6.fill(angles, values, alpha=0.25)
        
        ax6.set_xticks(angles[:-1])
        ax6.set_xticklabels(['Эффективность', 'Скорость', 'Кол-во ТС'])
        ax6.set_title('Сравнение стратегий (нормализовано)', fontsize=14, fontweight='bold')
        ax6.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))
        
        plt.suptitle('СРАВНЕНИЕ СТРАТЕГИЙ УПРАВЛЕНИЯ СВЕТОФОРАМИ', 
                    fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        # Сохраняем график
        chart_path = self.comparison_dir / "comparison_chart.png"
        plt.savefig(chart_path, dpi=150, bbox_inches='tight')
        plt.show()
        
        print(f"\n📈 Графики сравнения сохранены: {chart_path}")
        
        return chart_path
    
    def print_summary_table(self):
        """Выводит таблицу сравнения"""
        if not self.results:
            print("Нет результатов для вывода")
            return
        
        print("\n" + "="*80)
        print("ТАБЛИЦА СРАВНЕНИЯ СТРАТЕГИЙ")
        print("="*80)
        
        # Создаем таблицу
        headers = ["Стратегия", "Эффективность", "Ср.задержка", 
                  "Ср.скорость", "Всего ТС", "Время (с)"]
        
        print(f"{headers[0]:25} {headers[1]:12} {headers[2]:12} "
              f"{headers[3]:12} {headers[4]:10} {headers[5]:10}")
        print("-" * 80)
        
        for result in sorted(self.results, key=lambda x: x.metrics.get('efficiency', 0), reverse=True):
            print(f"{result.name:25} "
                  f"{result.metrics.get('efficiency', 0):<12.4f} "
                  f"{result.metrics.get('average_delay_per_vehicle', 0):<12.2f} "
                  f"{result.metrics.get('average_speed_kmh', 0):<12.1f} "
                  f"{result.metrics.get('total_vehicles', 0):<10} "
                  f"{result.simulation_time:<10.1f}")
        
        print("="*80)
        
        # Определяем лучшую стратегию
        best_result = max(self.results, 
                         key=lambda x: x.metrics.get('efficiency', 0))
        
        print(f"\n🏆 ЛУЧШАЯ СТРАТЕГИЯ: {best_result.name}")
        print(f"   Эффективность: {best_result.metrics.get('efficiency', 0):.4f}")
        print(f"   Средняя задержка: {best_result.metrics.get('average_delay_per_vehicle', 0):.2f} сек")
        print(f"   Средняя скорость: {best_result.metrics.get('average_speed_kmh', 0):.1f} км/ч")

def run_complete_comparison():
    """Запускает полное сравнение всех стратегий"""
    import sys
    from pathlib import Path
    
    # Настройка путей
    project_root = Path.cwd()
    smart_city_dir = project_root / "smart_city"
    data_dir = smart_city_dir / "data" / "sumo"
    sumo_cfg_path = data_dir / "osm.net_cut.sumocfg"
    
    # Добавляем путь к модулям
    src_dir = smart_city_dir / "src"
    sys.path.insert(0, str(src_dir))
    
    # Импортируем контроллеры (они будут созданы далее)
    try:
        from strategy_controllers import (
            SimpleCyclicController,
            EnhancedAlgorithmicController,
            ImprovedQLearningController,
            PPOTrafficController,
            MultiAgentTrafficController
        )
    except ImportError:
        print("Сначала создайте файл strategy_controllers.py с контроллерами")
        return
    
    # Создаем объект сравнения
    comparison = StrategyComparison(
        sumo_cfg_path=str(sumo_cfg_path),
        result_dir=str(smart_city_dir / "result")
    )
    
    # 1. Простая циклическая стратегия
    comparison.run_strategy(
        strategy_name="Простая циклическая",
        controller_class=SimpleCyclicController,
        steps=1000
    )
    
    # 2. Улучшенная алгоритмическая стратегия
    comparison.run_strategy(
        strategy_name="Улучшенная алгоритмическая",
        controller_class=EnhancedAlgorithmicController,
        steps=1000
    )
    
    # 3. Улучшенный Q-learning
    comparison.run_strategy(
        strategy_name="Улучшенный Q-learning",
        controller_class=ImprovedQLearningController,
        steps=1000
    )
    
    # 4. PPO стратегия
    comparison.run_strategy(
        strategy_name="PPO (обучение с подкреплением)",
        controller_class=PPOTrafficController,
        steps=1000
    )
    
    # 5. Мультиагентная система
    comparison.run_strategy(
        strategy_name="Мультиагентная система",
        controller_class=MultiAgentTrafficController,
        steps=1000
    )
    
    # Сохраняем и визуализируем результаты
    comparison.save_comparison_results()
    comparison.visualize_comparison()
    comparison.print_summary_table()
    
    return comparison

if __name__ == "__main__":
    run_complete_comparison()
# tripinfo_calculator.py (исправленная версия)
import xml.etree.ElementTree as ET
import os
import json
import numpy as np
from pathlib import Path

def calculate_metrics(tripinfo_file_path: str) -> dict:
    """
    Вычисляет метрики на основе tripinfo.xml.
    Новая версия: вычисляет Z0 динамически как сумму времени поездок при свободном движении.
    """
    if not os.path.exists(tripinfo_file_path):
        print(f"Файл с логами {tripinfo_file_path} не найден")
        return None

    try:
        tree = ET.parse(tripinfo_file_path)
        root = tree.getroot()

        total_delay = 0
        total_duration = 0
        total_route_length = 0
        total_depart_delay = 0
        vehicle_count = 0
        total_free_flow_time = 0  # Время при свободном движении
        
        for trip in root.findall('tripinfo'):
            time_loss_str = trip.get('timeLoss')
            duration_str = trip.get('duration')
            route_length_str = trip.get('routeLength')
            depart_delay_str = trip.get('departDelay')
            depart_str = trip.get('depart')

            time_loss = float(time_loss_str) if time_loss_str is not None else 0.0
            duration = float(duration_str) if duration_str is not None else 0.0
            route_length = float(route_length_str) if route_length_str is not None else 0.0
            depart_delay = float(depart_delay_str) if depart_delay_str is not None else 0.0
            depart = float(depart_str) if depart_str is not None else 0.0

            total_depart_delay += depart_delay
            total_duration += duration
            total_route_length += route_length
            total_delay += time_loss
            vehicle_count += 1
            
            # Оценка времени при свободном движении (предполагаем скорость 13.9 м/с = 50 км/ч)
            free_flow_speed = 13.9  # м/с
            if route_length > 0 and free_flow_speed > 0:
                free_flow_time = route_length / free_flow_speed
                total_free_flow_time += free_flow_time

        if vehicle_count == 0:
            return {
                'total_vehicles': 0,
                'total_cumulative_delay_Zn': 0,
                'average_delay_per_vehicle': 0,
                'total_duration': 0,
                'average_duration': 0,
                'total_route_length': 0,
                'average_route_length': 0,
                'total_depart_delay': 0,
                'total_free_flow_time': 0,
                'efficiency': 0,
                'average_speed': 0
            }

        avg_delay = total_delay / vehicle_count
        avg_duration = total_duration / vehicle_count
        avg_route_length = total_route_length / vehicle_count
        
        # Эффективность = (время при свободном движении) / (фактическое время)
        # Если нет задержек, эффективность = 1
        # Если задержки большие, эффективность стремится к 0
        if total_duration > 0:
            efficiency = min(1.0, max(0.0, total_free_flow_time / total_duration))
        else:
            efficiency = 0
            
        # Средняя скорость
        total_time_hours = total_duration / 3600
        total_distance_km = total_route_length / 1000
        if total_time_hours > 0:
            avg_speed_kmh = total_distance_km / total_time_hours
        else:
            avg_speed_kmh = 0

        metrics = {
            'total_vehicles': vehicle_count,
            'total_cumulative_delay_Zn': total_delay,
            'average_delay_per_vehicle': avg_delay,
            'total_duration': total_duration,
            'average_duration': avg_duration,
            'total_route_length': total_route_length,
            'average_route_length': avg_route_length,
            'total_depart_delay': total_depart_delay,
            'total_free_flow_time': total_free_flow_time,
            'efficiency': efficiency,
            'average_speed_kmh': avg_speed_kmh
        }

        return metrics

    except ET.ParseError as e:
        print(f"Ошибка при парсинге XML файла: {e}")
        return None
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        return None

def print_metrics(metrics):
    if metrics is None:
        print("Нет данных для печати.")
        return

    print("\n📊 --- Результаты метрик ---", flush=True)
    print(f"Количество транспортных средств (N): {metrics['total_vehicles']}", flush=True)
    print(f"Общая совокупная задержка (Zn, сумма timeLoss): {metrics['total_cumulative_delay_Zn']:.2f} сек", flush=True)
    print(f"Средняя задержка на ТС: {metrics['average_delay_per_vehicle']:.2f} сек", flush=True)
    print(f"Общая продолжительность поездок: {metrics['total_duration']:.2f} сек", flush=True)
    print(f"Средняя продолжительность поездки: {metrics['average_duration']:.2f} сек", flush=True)
    print(f"Общая длина маршрутов: {metrics['total_route_length']:.2f} м", flush=True)
    print(f"Средняя длина маршрута: {metrics['average_route_length']:.2f} м", flush=True)
    print(f"Общая задержка отправления: {metrics['total_depart_delay']:.2f} сек", flush=True)
    print(f"Время при свободном движении: {metrics['total_free_flow_time']:.2f} сек", flush=True)
    print(f"Эффективность (свободное/фактическое время): {metrics['efficiency']:.4f}", flush=True)
    print(f"Средняя скорость ТС: {metrics['average_speed_kmh']:.1f} км/ч", flush=True)
    print("----------------------------\n", flush=True)

def save_result_json(metrics, output_dir="result"):
    os.makedirs(output_dir, exist_ok=True)
    result_path = os.path.join(output_dir, "result.json")

    if metrics is None:
        result = {
            "status": "ERR",
            "errors": ["Не удалось вычислить метрики. Проверьте файл tripinfo.xml и повторите попытку"]
        }
    else:
        efficiency = metrics.get('efficiency', 0.0)
        result = {
            "status": "OK",
            "validationQuality": efficiency,
            "testingQuality": efficiency
        }

    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"Результат записан в {result_path}", flush=True)

def main():
    tripinfo_filename = "tripinfo.xml"
    tripinfo_path = os.path.join(os.getcwd(), tripinfo_filename)
    metrics = calculate_metrics(tripinfo_path)
    print_metrics(metrics)
    save_result_json(metrics)

if __name__ == "__main__":
    main()
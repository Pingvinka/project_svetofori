# participant_controller.py (обновленная версия)
import os
from typing import Dict

# Импортируем все стратегии
from strategy_controllers import (
    SimpleCyclicController,
    EnhancedAlgorithmicController,
    ImprovedQLearningController,
    PPOTrafficController,
    MultiAgentTrafficController
)

# Выбор стратегии через переменную окружения
STRATEGY = os.environ.get("CONTROL_STRATEGY", "simple_cyclic").strip().lower()

# Маппинг стратегий на классы контроллеров
STRATEGY_MAP = {
    "simple_cyclic": SimpleCyclicController,
    "enhanced_algorithmic": EnhancedAlgorithmicController,
    "qlearning": ImprovedQLearningController,
    "ppo": PPOTrafficController,
    "multiagent": MultiAgentTrafficController,
    "participant": ImprovedQLearningController,  # по умолчанию
}

class ParticipantController:
    """
    Универсальный контроллер, который может использовать любую стратегию
    """
    
    def __new__(cls, *args, **kwargs):
        """Создает экземпляр соответствующего контроллера"""
        controller_class = STRATEGY_MAP.get(STRATEGY, SimpleCyclicController)
        
        print(f"🎮 Участник использует стратегию: {STRATEGY}")
        print(f"   Контроллер: {controller_class.__name__}")
        
        # Создаем экземпляр выбранного контроллера
        return controller_class(*args, **kwargs)

# Для обратной совместимости
if __name__ == "__main__":
    # Пример использования
    controller = ParticipantController(tls_ids=None)
    print(f"Создан контроллер: {controller.__class__.__name__}")
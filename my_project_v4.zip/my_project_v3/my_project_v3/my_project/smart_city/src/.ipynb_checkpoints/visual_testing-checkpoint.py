# visual_testing.py
"""
Модуль для визуального тестирования всех стратегий управления светофорами
с запуском SUMO-GUI и анимацией
"""

import os
import sys
import time
import subprocess
import traci
from pathlib import Path
from typing import Dict, List, Optional
import threading

# Добавляем путь к модулям проекта
project_root = Path.cwd()
smart_city_dir = project_root / "smart_city"
src_dir = smart_city_dir / "src"
sys.path.insert(0, str(src_dir))

# Импортируем контроллеры
from strategy_controllers import (
    SimpleCyclicController,
    EnhancedAlgorithmicController,
    ImprovedQLearningController,
    PPOTrafficController,
    MultiAgentTrafficController
)

# Настройки SUMO
SUMO_HOME_PATH = r"C:\Program Files (x86)\Eclipse\Sumo"
os.environ['SUMO_HOME'] = SUMO_HOME_PATH

# Пути к файлам
DATA_DIR = smart_city_dir / "data" / "sumo"
SUMO_CFG_PATH = DATA_DIR / "osm.net_cut.sumocfg"
RESULT_DIR = smart_city_dir / "result"

# Проверяем наличие SUMO-GUI
SUMO_GUI_BINARY = os.path.join(SUMO_HOME_PATH, 'bin', 'sumo-gui.exe')
if not os.path.exists(SUMO_GUI_BINARY):
    # Пробуем sumo.exe
    SUMO_BINARY = os.path.join(SUMO_HOME_PATH, 'bin', 'sumo.exe')
    if os.path.exists(SUMO_BINARY):
        SUMO_GUI_BINARY = SUMO_BINARY
        print("⚠️ sumo-gui.exe не найден, используем sumo.exe")
    else:
        print("❌ SUMO не найден! Проверьте установку.")
        sys.exit(1)

class VisualSimulation:
    """
    Класс для запуска визуальной симуляции с контроллером
    """
    
    def __init__(self, strategy_name: str, controller_class, steps: int = 500, 
                 gui_delay: int = 100, show_gui: bool = True):
        """
        Инициализация визуальной симуляции
        
        Args:
            strategy_name: название стратегии
            controller_class: класс контроллера
            steps: количество шагов симуляции
            gui_delay: задержка между шагами (мс)
            show_gui: показывать ли графический интерфейс
        """
        self.strategy_name = strategy_name
        self.controller_class = controller_class
        self.steps = steps
        self.gui_delay = gui_delay
        self.show_gui = show_gui
        
        # Статистика
        self.stats = {
            'start_time': 0,
            'end_time': 0,
            'vehicle_history': [],
            'phase_changes': 0,
            'max_vehicles': 0,
            'total_waiting_time': 0
        }
        
        # Создаем уникальный файл результатов
        timestamp = int(time.time())
        self.tripinfo_path = RESULT_DIR / f"tripinfo_{strategy_name}_{timestamp}.xml"
        
        print(f"\n🎮 ВИЗУАЛЬНОЕ ТЕСТИРОВАНИЕ: {strategy_name}")
        print(f"   Шагов: {steps}")
        print(f"   Задержка GUI: {gui_delay} мс")
        print(f"   Файл результатов: {self.tripinfo_path.name}")
    
    def _prepare_sumo_command(self) -> List[str]:
        """Подготавливает команду для запуска SUMO"""
        
        if self.show_gui and "sumo-gui" in SUMO_GUI_BINARY:
            binary = SUMO_GUI_BINARY
            gui_params = ["--start", "true", "--quit-on-end", "true"]
        else:
            binary = SUMO_GUI_BINARY.replace("sumo-gui", "sumo")
            gui_params = []
        
        cmd = [
            binary,
            "-c", str(SUMO_CFG_PATH),
            "--tripinfo-output", str(self.tripinfo_path),
            "--delay", str(self.gui_delay),
            *gui_params,
            "--time-to-teleport", "300",
            "--no-warnings", "true"
        ]
        
        return cmd
    
    def _print_progress(self, step: int, vehicles: int, waiting_time: float):
        """Выводит прогресс симуляции"""
        progress = (step + 1) / self.steps * 100
        sim_time = traci.simulation.getTime() if hasattr(traci, 'simulation') else 0
        
        print(f"  Шаг {step+1:4}/{self.steps} "
              f"({progress:5.1f}%) | "
              f"Время: {sim_time:6.1f} с | "
              f"ТС: {vehicles:3d} | "
              f"Ожидание: {waiting_time:6.1f} с", end='\r')
    
    def run(self) -> bool:
        """
        Запускает визуальную симуляцию
        
        Returns:
            bool: True если успешно, False если ошибка
        """
        print(f"\n🚀 ЗАПУСК SUMO-GUI...")
        print("   Откроется окно с визуализацией дорог и светофоров")
        print("   Для управления используйте:")
        print("   • Пауза: Ctrl+P или кнопка ▶️/⏸️")
        print("   • Ускорение: клавиша + или кнопка >>")
        print("   • Замедление: клавиша - или кнопка <<")
        print("   • Скриншот: Ctrl+S или кнопка 📷")
        print("   • Закрыть: Alt+F4 или кнопка ✕")
        
        # Подготавливаем команду
        cmd = self._prepare_sumo_command()
        
        # Закрываем предыдущие соединения
        try:
            traci.close()
        except:
            pass
        
        try:
            # Запускаем SUMO
            traci.start(cmd)
            
            # Создаем контроллер
            controller = self.controller_class(tls_ids=None)
            print(f"   🎛️ Контроллер создан: {controller.__class__.__name__}")
            print(f"   🔦 Управляем светофорами: {len(controller.tls_ids)} шт")
            
            # Стартовая статистика
            self.stats['start_time'] = time.time()
            
            # Основной цикл симуляции
            print(f"\n🔄 ВЫПОЛНЕНИЕ СИМУЛЯЦИИ...")
            print("   Смотрите движение в окне SUMO-GUI!")
            
            for step in range(self.steps):
                # Выполняем шаг симуляции
                traci.simulationStep()
                
                # Обновляем контроллер
                try:
                    controller.step()
                    if hasattr(controller, 'last_decision') and controller.last_decision:
                        self.stats['phase_changes'] += len(controller.last_decision)
                except Exception as e:
                    print(f"   ⚠️ Ошибка контроллера: {e}")
                
                # Собираем статистику
                vehicles = traci.vehicle.getIDCount()
                self.stats['vehicle_history'].append(vehicles)
                self.stats['max_vehicles'] = max(self.stats['max_vehicles'], vehicles)
                
                # Вычисляем общее время ожидания
                try:
                    for veh_id in traci.vehicle.getIDList():
                        self.stats['total_waiting_time'] += traci.vehicle.getWaitingTime(veh_id)
                except:
                    pass
                
                # Выводим прогресс каждые 50 шагов
                if (step + 1) % 50 == 0:
                    self._print_progress(step, vehicles, self.stats['total_waiting_time'])
            
            # Завершаем
            traci.close()
            self.stats['end_time'] = time.time()
            
            print(f"\n\n✅ СИМУЛЯЦИЯ ЗАВЕРШЕНА!")
            
            # Анализируем результаты
            self._analyze_results()
            
            return True
            
        except traci.exceptions.TraCIException as e:
            print(f"\n❌ ОШИБКА TRACI: {e}")
            print("   Возможно, SUMO-GUI был закрыт пользователем")
            return False
        except Exception as e:
            print(f"\n❌ ОШИБКА: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _analyze_results(self):
        """Анализирует результаты симуляции"""
        print(f"\n📊 РЕЗУЛЬТАТЫ СТРАТЕГИИ '{self.strategy_name}':")
        print(f"   Время выполнения: {self.stats['end_time'] - self.stats['start_time']:.1f} сек")
        print(f"   Максимум ТС за шаг: {self.stats['max_vehicles']}")
        print(f"   Смен фаз светофоров: {self.stats['phase_changes']}")
        print(f"   Общее время ожидания: {self.stats['total_waiting_time']:.1f} сек")
        
        # Анализируем файл tripinfo если он существует
        if self.tripinfo_path.exists():
            try:
                from tripinfo_calculator import calculate_metrics
                metrics = calculate_metrics(str(self.tripinfo_path))
                
                if metrics:
                    print(f"\n📈 МЕТРИКИ ЭФФЕКТИВНОСТИ:")
                    print(f"   Эффективность: {metrics.get('efficiency', 0):.4f}")
                    print(f"   Средняя задержка: {metrics.get('average_delay_per_vehicle', 0):.2f} сек")
                    print(f"   Средняя скорость: {metrics.get('average_speed_kmh', 0):.1f} км/ч")
                    print(f"   Всего ТС: {metrics.get('total_vehicles', 0)}")
                    
                    # Создаем график истории ТС
                    self._create_vehicle_chart()
            except Exception as e:
                print(f"   ⚠️ Ошибка анализа метрик: {e}")
    
    def _create_vehicle_chart(self):
        """Создает график истории транспортных средств"""
        try:
            import matplotlib.pyplot as plt
            import numpy as np
            
            if len(self.stats['vehicle_history']) < 2:
                return
            
            plt.figure(figsize=(10, 6))
            
            # График количества ТС
            plt.plot(self.stats['vehicle_history'], 'b-', linewidth=2, alpha=0.7, label='Количество ТС')
            plt.fill_between(range(len(self.stats['vehicle_history'])), 
                             self.stats['vehicle_history'], alpha=0.3, color='blue')
            
            # Скользящее среднее
            if len(self.stats['vehicle_history']) > 10:
                window = min(20, len(self.stats['vehicle_history']) // 10)
                import pandas as pd
                moving_avg = pd.Series(self.stats['vehicle_history']).rolling(window=window).mean()
                plt.plot(moving_avg, 'r-', linewidth=2, label=f'Среднее ({window} шагов)')
            
            plt.title(f'История транспортных средств: {self.strategy_name}', fontsize=14)
            plt.xlabel('Шаг симуляции', fontsize=12)
            plt.ylabel('Количество ТС', fontsize=12)
            plt.grid(True, alpha=0.3)
            plt.legend()
            
            # Статистика на графике
            stats_text = f"""
            Статистика:
            Среднее: {np.mean(self.stats['vehicle_history']):.1f}
            Максимум: {self.stats['max_vehicles']}
            Минимум: {min(self.stats['vehicle_history'])}
            Шагов: {len(self.stats['vehicle_history'])}
            Стратегия: {self.strategy_name}
            """
            plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes,
                    fontsize=10, verticalalignment='top',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
            
            plt.tight_layout()
            
            # Сохраняем график
            chart_path = RESULT_DIR / f"vehicle_chart_{self.strategy_name}_{int(time.time())}.png"
            plt.savefig(chart_path, dpi=150, bbox_inches='tight')
            print(f"   📊 График сохранен: {chart_path.name}")
            
            plt.show()
            
        except Exception as e:
            print(f"   ⚠️ Ошибка создания графика: {e}")

# ============================================================================
# ФУНКЦИИ ДЛЯ ТЕСТИРОВАНИЯ ОТДЕЛЬНЫХ СТРАТЕГИЙ
# ============================================================================

def test_simple_cyclic(steps: int = 300, gui_delay: int = 100, show_gui: bool = True):
    """
    Тестирует простую циклическую стратегию с визуализацией
    
    Args:
        steps: количество шагов симуляции
        gui_delay: задержка между шагами (мс)
        show_gui: показывать ли графический интерфейс
    """
    print("\n" + "="*70)
    print("🧪 ТЕСТИРОВАНИЕ: ПРОСТАЯ ЦИКЛИЧЕСКАЯ СТРАТЕГИЯ")
    print("="*70)
    
    sim = VisualSimulation(
        strategy_name="Простая циклическая",
        controller_class=SimpleCyclicController,
        steps=steps,
        gui_delay=gui_delay,
        show_gui=show_gui
    )
    
    return sim.run()

def test_enhanced_algorithmic(steps: int = 300, gui_delay: int = 100, show_gui: bool = True):
    """
    Тестирует улучшенную алгоритмическую стратегию с визуализацией
    
    Args:
        steps: количество шагов симуляции
        gui_delay: задержка между шагами (мс)
        show_gui: показывать ли графический интерфейс
    """
    print("\n" + "="*70)
    print("🧪 ТЕСТИРОВАНИЕ: УЛУЧШЕННАЯ АЛГОРИТМИЧЕСКАЯ СТРАТЕГИЯ")
    print("="*70)
    
    sim = VisualSimulation(
        strategy_name="Улучшенная алгоритмическая",
        controller_class=EnhancedAlgorithmicController,
        steps=steps,
        gui_delay=gui_delay,
        show_gui=show_gui
    )
    
    return sim.run()

def test_qlearning(steps: int = 300, gui_delay: int = 100, show_gui: bool = True):
    """
    Тестирует Q-learning стратегию с визуализацией
    
    Args:
        steps: количество шагов симуляции
        gui_delay: задержка между шагами (мс)
        show_gui: показывать ли графический интерфейс
    """
    print("\n" + "="*70)
    print("🧪 ТЕСТИРОВАНИЕ: Q-LEARNING СТРАТЕГИЯ")
    print("="*70)
    
    sim = VisualSimulation(
        strategy_name="Q-learning",
        controller_class=ImprovedQLearningController,
        steps=steps,
        gui_delay=gui_delay,
        show_gui=show_gui
    )
    
    return sim.run()

def test_ppo(steps: int = 300, gui_delay: int = 100, show_gui: bool = True):
    """
    Тестирует PPO стратегию с визуализацией
    
    Args:
        steps: количество шагов симуляции
        gui_delay: задержка между шагами (мс)
        show_gui: показывать ли графический интерфейс
    """
    print("\n" + "="*70)
    print("🧪 ТЕСТИРОВАНИЕ: PPO СТРАТЕГИЯ")
    print("="*70)
    
    sim = VisualSimulation(
        strategy_name="PPO",
        controller_class=PPOTrafficController,
        steps=steps,
        gui_delay=gui_delay,
        show_gui=show_gui
    )
    
    return sim.run()

def test_multiagent(steps: int = 300, gui_delay: int = 100, show_gui: bool = True):
    """
    Тестирует мультиагентную систему с визуализацией
    
    Args:
        steps: количество шагов симуляции
        gui_delay: задержка между шагами (мс)
        show_gui: показывать ли графический интерфейс
    """
    print("\n" + "="*70)
    print("🧪 ТЕСТИРОВАНИЕ: МУЛЬТИАГЕНТНАЯ СИСТЕМА")
    print("="*70)
    
    sim = VisualSimulation(
        strategy_name="Мультиагентная",
        controller_class=MultiAgentTrafficController,
        steps=steps,
        gui_delay=gui_delay,
        show_gui=show_gui
    )
    
    return sim.run()

def test_all_strategies_quick(steps: int = 200, gui_delay: int = 50):
    """
    Быстро тестирует все стратегии по очереди
    
    Args:
        steps: количество шагов для каждой стратегии
        gui_delay: задержка между шагами (мс)
    """
    print("\n" + "="*70)
    print("🚀 БЫСТРОЕ ТЕСТИРОВАНИЕ ВСЕХ СТРАТЕГИЙ")
    print("="*70)
    
    strategies = [
        ("Простая циклическая", test_simple_cyclic),
        ("Улучшенная алгоритмическая", test_enhanced_algorithmic),
        ("Q-learning", test_qlearning),
        ("PPO", test_ppo),
        ("Мультиагентная", test_multiagent),
    ]
    
    results = []
    
    for name, test_func in strategies:
        print(f"\n▶️ Запускаем: {name}")
        
        success = test_func(
            steps=steps,
            gui_delay=gui_delay,
            show_gui=True  # Можно поставить False для ускорения
        )
        
        results.append((name, success))
        
        if not success:
            print(f"⚠️  Стратегия {name} завершилась с ошибкой")
        
        # Пауза между стратегиями
        time.sleep(2)
    
    print("\n" + "="*70)
    print("📋 ИТОГИ ТЕСТИРОВАНИЯ:")
    for name, success in results:
        status = "✅ УСПЕШНО" if success else "❌ ОШИБКА"
        print(f"  {name:30} - {status}")
    print("="*70)

def interactive_strategy_test():
    """
    Интерактивное меню для тестирования стратегий
    """
    print("\n" + "="*70)
    print("🎮 ИНТЕРАКТИВНОЕ ТЕСТИРОВАНИЕ СТРАТЕГИЙ")
    print("="*70)
    
    while True:
        print("\nВыберите стратегию для тестирования:")
        print("1. Простая циклическая")
        print("2. Улучшенная алгоритмическая")
        print("3. Q-learning")
        print("4. PPO")
        print("5. Мультиагентная система")
        print("6. Быстро протестировать все стратегии")
        print("7. Выход")
        
        choice = input("\nВаш выбор (1-7): ").strip()
        
        if choice == "1":
            steps = input("Количество шагов [300]: ").strip()
            steps = int(steps) if steps else 300
            
            delay = input("Задержка GUI (мс) [100]: ").strip()
            delay = int(delay) if delay else 100
            
            test_simple_cyclic(steps=steps, gui_delay=delay)
            
        elif choice == "2":
            steps = input("Количество шагов [300]: ").strip()
            steps = int(steps) if steps else 300
            
            delay = input("Задержка GUI (мс) [100]: ").strip()
            delay = int(delay) if delay else 100
            
            test_enhanced_algorithmic(steps=steps, gui_delay=delay)
            
        elif choice == "3":
            steps = input("Количество шагов [300]: ").strip()
            steps = int(steps) if steps else 300
            
            delay = input("Задержка GUI (мс) [100]: ").strip()
            delay = int(delay) if delay else 100
            
            test_qlearning(steps=steps, gui_delay=delay)
            
        elif choice == "4":
            steps = input("Количество шагов [300]: ").strip()
            steps = int(steps) if steps else 300
            
            delay = input("Задержка GUI (мс) [100]: ").strip()
            delay = int(delay) if delay else 100
            
            test_ppo(steps=steps, gui_delay=delay)
            
        elif choice == "5":
            steps = input("Количество шагов [300]: ").strip()
            steps = int(steps) if steps else 300
            
            delay = input("Задержка GUI (мс) [100]: ").strip()
            delay = int(delay) if delay else 100
            
            test_multiagent(steps=steps, gui_delay=delay)
            
        elif choice == "6":
            steps = input("Количество шагов для каждой стратегии [200]: ").strip()
            steps = int(steps) if steps else 200
            
            delay = input("Задержка GUI (мс) [50]: ").strip()
            delay = int(delay) if delay else 50
            
            test_all_strategies_quick(steps=steps, gui_delay=delay)
            
        elif choice == "7":
            print("Выход из программы")
            break
            
        else:
            print("Неверный выбор, попробуйте снова")

# ============================================================================
# ДОПОЛНИТЕЛЬНАЯ ВИЗУАЛИЗАЦИЯ С ГРАФИКАМИ В РЕАЛЬНОМ ВРЕМЕНИ
# ============================================================================

class RealTimeVisualizationSimulation(VisualSimulation):
    """
    Расширенная версия с графиками в реальном времени
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Для графиков в реальном времени
        self.real_time_data = {
            'vehicles': [],
            'waiting_time': [],
            'speed': []
        }
        
        # Флаг для потоков
        self.running = True
    
    def run(self) -> bool:
        """Запускает симуляцию с графиками в реальном времени"""
        # Создаем поток для обновления графиков
        if self.show_gui:
            plot_thread = threading.Thread(target=self._update_plots, daemon=True)
            plot_thread.start()
        
        # Запускаем основную симуляцию
        result = super().run()
        
        # Останавливаем поток графиков
        self.running = False
        
        return result
    
    def _update_plots(self):
        """Обновляет графики в реальном времени"""
        try:
            import matplotlib.pyplot as plt
            import numpy as np
            
            # Создаем окно с графиками
            plt.ion()  # Включаем интерактивный режим
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))
            
            while self.running:
                if len(self.real_time_data['vehicles']) > 0:
                    # Очищаем графики
                    ax1.clear()
                    ax2.clear()
                    
                    # График 1: Количество ТС
                    ax1.plot(self.real_time_data['vehicles'], 'b-', linewidth=2)
                    ax1.set_title('Количество транспортных средств (реальное время)')
                    ax1.set_xlabel('Шаг')
                    ax1.set_ylabel('ТС')
                    ax1.grid(True, alpha=0.3)
                    
                    # График 2: Время ожидания
                    if len(self.real_time_data['waiting_time']) > 0:
                        ax2.plot(self.real_time_data['waiting_time'], 'r-', linewidth=2)
                        ax2.set_title('Общее время ожидания (реальное время)')
                        ax2.set_xlabel('Шаг')
                        ax2.set_ylabel('Секунды')
                        ax2.grid(True, alpha=0.3)
                    
                    plt.tight_layout()
                    plt.pause(0.1)  # Обновляем каждые 100 мс
                
                time.sleep(0.1)  # Пауза между обновлениями
            
            plt.ioff()
            plt.close()
            
        except Exception as e:
            print(f"Ошибка в потоке графиков: {e}")

# ============================================================================
# ФУНКЦИИ С ГРАФИКАМИ В РЕАЛЬНОМ ВРЕМЕНИ
# ============================================================================

def test_strategy_with_realtime_plots(strategy_name: str, controller_class, 
                                     steps: int = 300, gui_delay: int = 100):
    """
    Тестирует стратегию с графиками в реальном времени
    
    Args:
        strategy_name: название стратегии
        controller_class: класс контроллера
        steps: количество шагов
        gui_delay: задержка GUI
    """
    print(f"\n📊 ТЕСТИРОВАНИЕ С ГРАФИКАМИ В РЕАЛЬНОМ ВРЕМЕНИ: {strategy_name}")
    
    sim = RealTimeVisualizationSimulation(
        strategy_name=strategy_name,
        controller_class=controller_class,
        steps=steps,
        gui_delay=gui_delay,
        show_gui=True
    )
    
    return sim.run()

# Примеры использования отдельных функций
if __name__ == "__main__":
    # Можно запустить интерактивное меню
    interactive_strategy_test()
    
    # Или тестировать конкретную стратегию
    # test_simple_cyclic(steps=200, gui_delay=100)
    # test_qlearning(steps=300, gui_delay=150)
    # test_all_strategies_quick(steps=150, gui_delay=50)
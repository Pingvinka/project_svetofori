# strategy_controllers.py
import numpy as np
import random
import json
from typing import Dict, List, Tuple, Any, Optional
from collections import defaultdict, deque
import pickle
from pathlib import Path

from controller import IntersectionController

# ============================================================================
# 1. ПРОСТАЯ ЦИКЛИЧЕСКАЯ СТРАТЕГИЯ
# ============================================================================

class SimpleCyclicController(IntersectionController):
    """
    Простая циклическая стратегия с чередованием фаз по направлениям
    (север-юг, восток-запад)
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # Для каждого светофора определяем фазы по направлениям
        self.phase_cycles = {}
        self.current_phase_idx = {}
        self.phase_durations = {}
        self.last_switch_time = {}
        
        for tls_id in self.tls_ids:
            self._setup_phases_for_tls(tls_id)
        
        print(f"✅ Простая циклическая стратегия инициализирована")
        print(f"   Управляем {len(self.tls_ids)} светофорами")
    
    def _setup_phases_for_tls(self, tls_id: str):
        """Настраивает фазы для светофора"""
        phases = self.get_phase_catalog(tls_id)
        
        # Группируем фазы по направлениям
        ns_phases = []  # Север-Юг
        ew_phases = []  # Восток-Запад
        
        for phase in phases:
            state = phase.state
            # Простая эвристика: если есть G в первых позициях - север-юг
            # Если G в последних позициях - восток-запад
            if 'G' in state[:len(state)//2]:
                ns_phases.append(phase.index)
            elif 'G' in state[len(state)//2:]:
                ew_phases.append(phase.index)
        
        # Если не удалось определить, берем все зеленые фазы
        if not ns_phases and not ew_phases:
            green_phases = [phase.index for phase in phases 
                           if 'G' in phase.state or 'g' in phase.state]
            if green_phases:
                ns_phases = green_phases[:len(green_phases)//2]
                ew_phases = green_phases[len(green_phases)//2:]
        
        # Создаем цикл: север-юг -> желтый -> восток-запад -> желтый
        cycle = []
        
        if ns_phases:
            cycle.extend(ns_phases)  # Север-юг
        
        # Добавляем желтые фазы если есть
        yellow_phases = [phase.index for phase in phases 
                        if 'y' in phase.state or 'Y' in phase.state]
        if yellow_phases:
            cycle.append(yellow_phases[0])
        
        if ew_phases:
            cycle.extend(ew_phases)  # Восток-запад
        
        if yellow_phases and len(yellow_phases) > 1:
            cycle.append(yellow_phases[1])
        
        if cycle:
            self.phase_cycles[tls_id] = cycle
            self.current_phase_idx[tls_id] = 0
            self.phase_durations[tls_id] = 30.0  # секунд
            self.last_switch_time[tls_id] = 0.0
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """Принимает решение о смене фазы"""
        decision = {}
        sim_time = observation.get('sim_time', 0)
        
        for tls_id in self.tls_ids:
            if tls_id not in self.phase_cycles:
                continue
            
            # Проверяем, не пора ли сменить фазу
            time_since_switch = sim_time - self.last_switch_time.get(tls_id, 0)
            
            if time_since_switch >= self.phase_durations[tls_id]:
                # Переходим к следующей фазе в цикле
                cycle = self.phase_cycles[tls_id]
                current_idx = self.current_phase_idx[tls_id]
                next_idx = (current_idx + 1) % len(cycle)
                
                decision[tls_id] = {
                    'phase_id': cycle[next_idx],
                    'duration': self.phase_durations[tls_id]
                }
                
                self.current_phase_idx[tls_id] = next_idx
                self.last_switch_time[tls_id] = sim_time
        
        return decision if decision else None

# ============================================================================
# 2. УЛУЧШЕННАЯ АЛГОРИТМИЧЕСКАЯ СТРАТЕГИЯ
# ============================================================================

class EnhancedAlgorithmicController(IntersectionController):
    """
    Улучшенная алгоритмическая стратегия с адаптивными длительностями фаз
    на основе загруженности дорог
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # Параметры стратегии
        self.min_green_time = 10.0  # минимальное время зеленого
        self.max_green_time = 60.0  # максимальное время зеленого
        self.yellow_time = 3.0      # время желтого
        
        # История загруженности
        self.congestion_history = defaultdict(lambda: deque(maxlen=10))
        
        # Для каждого светофора
        self.current_phases = {}
        self.phase_start_time = {}
        self.phase_queues = defaultdict(lambda: defaultdict(int))
        
        for tls_id in self.tls_ids:
            self._initialize_tls(tls_id)
        
        print(f"✅ Улучшенная алгоритмическая стратегия инициализирована")
    
    def _initialize_tls(self, tls_id: str):
        """Инициализирует светофор"""
        phases = self.get_phase_catalog(tls_id)
        
        # Находим зеленые фазы
        green_phases = [phase.index for phase in phases 
                       if 'G' in phase.state or 'g' in phase.state]
        
        if green_phases:
            self.current_phases[tls_id] = green_phases[0]
            self.phase_start_time[tls_id] = 0.0
    
    def _estimate_congestion(self, tls_id: str, observation: Dict) -> float:
        """Оценивает загруженность перекрестка"""
        # Используем детекторы и ребра для оценки
        total_vehicles = 0
        
        # Считаем ТС на ребрах, связанных с перекрестком
        for edge_id, edge_data in observation.get('edges', {}).items():
            total_vehicles += edge_data.get('veh_number', 0)
        
        # Нормализуем
        max_expected = 50  # максимальное ожидаемое количество ТС
        congestion = min(1.0, total_vehicles / max_expected)
        
        # Сохраняем в историю
        self.congestion_history[tls_id].append(congestion)
        
        return congestion
    
    def _calculate_green_time(self, tls_id: str, congestion: float) -> float:
        """Рассчитывает длительность зеленой фазы на основе загруженности"""
        if congestion < 0.2:  # низкая загруженность
            return self.min_green_time
        elif congestion < 0.5:  # средняя загруженность
            return self.min_green_time + (self.max_green_time - self.min_green_time) * 0.3
        elif congestion < 0.8:  # высокая загруженность
            return self.min_green_time + (self.max_green_time - self.min_green_time) * 0.6
        else:  # очень высокая загруженность
            return self.max_green_time
    
    def _get_next_phase(self, tls_id: str, current_phase: int) -> int:
        """Выбирает следующую фазу"""
        phases = self.get_phase_catalog(tls_id)
        
        # Находим все зеленые фазы
        green_phases = [phase.index for phase in phases 
                       if 'G' in phase.state or 'g' in phase.state]
        
        if not green_phases:
            return current_phase
        
        # Простая стратегия: чередуем направления
        current_idx = green_phases.index(current_phase) if current_phase in green_phases else 0
        next_idx = (current_idx + 1) % len(green_phases)
        
        return green_phases[next_idx]
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """Принимает адаптивное решение"""
        decision = {}
        sim_time = observation.get('sim_time', 0)
        
        for tls_id in self.tls_ids:
            current_phase = self.current_phases.get(tls_id)
            if current_phase is None:
                continue
            
            # Проверяем время текущей фазы
            phase_start = self.phase_start_time.get(tls_id, 0)
            phase_duration = sim_time - phase_start
            
            # Оцениваем загруженность
            congestion = self._estimate_congestion(tls_id, observation)
            
            # Рассчитываем оптимальную длительность
            optimal_duration = self._calculate_green_time(tls_id, congestion)
            
            # Если время вышло, меняем фазу
            if phase_duration >= optimal_duration:
                next_phase = self._get_next_phase(tls_id, current_phase)
                
                # Проверяем, нужно ли включать желтую фазу
                phases = self.get_phase_catalog(tls_id)
                current_state = phases[current_phase].state if current_phase < len(phases) else ""
                
                if 'G' in current_state or 'g' in current_state:
                    # Включаем желтую фазу перед сменой
                    yellow_phases = [p.index for p in phases 
                                    if 'y' in p.state or 'Y' in p.state]
                    if yellow_phases:
                        decision[tls_id] = {
                            'phase_id': yellow_phases[0],
                            'duration': self.yellow_time
                        }
                        
                        # Запланируем следующую зеленую фазу
                        self.current_phases[tls_id] = next_phase
                        self.phase_start_time[tls_id] = sim_time + self.yellow_time
                    else:
                        # Нет желтой фазы, переключаемся сразу
                        decision[tls_id] = {
                            'phase_id': next_phase,
                            'duration': optimal_duration
                        }
                        self.current_phases[tls_id] = next_phase
                        self.phase_start_time[tls_id] = sim_time
        
        return decision if decision else None

# ============================================================================
# 3. УЛУЧШЕННЫЙ Q-LEARNING КОНТРОЛЛЕР
# ============================================================================

class ImprovedQLearningController(IntersectionController):
    """
    Улучшенный Q-learning контроллер с лучшим представлением состояния
    и более сложной функцией награды
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # Параметры обучения
        self.alpha = 0.2      # скорость обучения
        self.gamma = 0.95     # коэффициент дисконтирования
        self.epsilon = 0.3    # начальная вероятность исследования
        self.min_epsilon = 0.01
        self.epsilon_decay = 0.995
        
        # Q-таблица
        self.q_table = defaultdict(lambda: defaultdict(float))
        
        # Текущее состояние и действие
        self.current_state = None
        self.current_action = None
        
        # Статистика
        self.episode_rewards = []
        self.learning_history = []
        self.step_count = 0
        
        # Загрузка сохраненной Q-таблицы
        self.load_q_table()
        
        # Инициализация
        self._define_state_space()
        self._define_action_space()
        
        print(f"✅ Улучшенный Q-learning контроллер инициализирован")
        print(f"   ε (exploration): {self.epsilon:.3f}")
        print(f"   Размер Q-таблицы: {len(self.q_table)} состояний")
    
    def _define_state_space(self):
        """Определяет пространство состояний"""
        # Будем использовать дискретные признаки:
        # 1. Уровень загруженности на каждом подходе (0-3)
        # 2. Текущая фаза светофора
        # 3. Время с последней смены фазы
        pass  # Определяется динамически
    
    def _define_action_space(self):
        """Определяет пространство действий"""
        self.actions = {}
        for tls_id in self.tls_ids:
            phases = self.get_phase_catalog(tls_id)
            # Берем только зеленые фазы как возможные действия
            green_phases = [
                phase.index for phase in phases 
                if 'G' in phase.state or 'g' in phase.state
            ]
            self.actions[tls_id] = green_phases
    
    def _get_state_features(self, observation: Dict) -> Dict:
        """Извлекает признаки из наблюдения"""
        features = {}
        
        for tls_id in self.tls_ids:
            # Получаем информацию о светофоре
            light_info = observation['lights'].get(tls_id, {})
            current_phase = light_info.get('current_phase', {})
            
            # 1. Время с последней смены фазы
            time_to_switch = light_info.get('time_to_next_switch', 0)
            
            # 2. Загруженность на подходах
            congestion_level = self._estimate_congestion_near_tls(tls_id, observation)
            
            # 3. Текущая фаза
            phase_idx = current_phase.get('index', 0)
            
            features[tls_id] = {
                'time_to_switch': time_to_switch,
                'congestion': congestion_level,
                'phase': phase_idx
            }
        
        return features
    
    def _estimate_congestion_near_tls(self, tls_id: str, observation: Dict) -> int:
        """Оценивает загруженность возле светофора"""
        # Простая эвристика: считаем ТС на всех ребрах
        total_vehicles = 0
        for edge_id, edge_data in observation.get('edges', {}).items():
            total_vehicles += edge_data.get('veh_number', 0)
        
        # Дискретизируем
        if total_vehicles == 0:
            return 0  # нет машин
        elif total_vehicles <= 5:
            return 1  # мало машин
        elif total_vehicles <= 15:
            return 2  # средняя загруженность
        else:
            return 3  # много машин
    
    def get_state(self, observation: Dict) -> str:
        """Создает строковое представление состояния"""
        features = self._get_state_features(observation)
        
        # Создаем компактное строковое представление
        state_parts = []
        
        for tls_id in self.tls_ids[:3]:  # Берем только первые 3 для простоты
            if tls_id in features:
                f = features[tls_id]
                # Формат: T{время}C{загруженность}P{фаза}
                state_part = f"T{int(f['time_to_switch'])}C{f['congestion']}P{f['phase']}"
                state_parts.append(state_part)
        
        # Добавляем общую информацию
        total_vehicles = sum(
            edge_data.get('veh_number', 0) 
            for edge_data in observation.get('edges', {}).values()
        )
        
        if total_vehicles < 10:
            traffic_level = 'L'
        elif total_vehicles < 30:
            traffic_level = 'M'
        else:
            traffic_level = 'H'
        
        state_parts.append(f"V{traffic_level}")
        
        return "_".join(state_parts)
    
    def calculate_reward(self, observation: Dict) -> float:
        """Вычисляет награду за текущее состояние"""
        reward = 0.0
        
        # 1. Штраф за ожидание (основной компонент)
        total_waiting_time = 0
        total_vehicles = 0
        
        for edge_id, edge_data in observation.get('edges', {}).items():
            waiting_time = edge_data.get('waiting_time', 0)
            vehicles = edge_data.get('veh_number', 0)
            
            total_waiting_time += waiting_time
            total_vehicles += vehicles
            
            # Штраф за стоящие ТС
            halting = edge_data.get('halting_number', 0)
            reward -= halting * 2.0
        
        # 2. Награда за движение
        avg_speed = 0
        if total_vehicles > 0:
            total_speed = sum(
                edge_data.get('mean_speed', 0) 
                for edge_data in observation.get('edges', {}).values()
            )
            avg_speed = total_speed / total_vehicles if total_vehicles > 0 else 0
            reward += avg_speed * 0.5
        
        # 3. Штраф за слишком частые переключения
        if self.current_action:
            reward -= 0.1 * len(self.current_action)
        
        # 4. Награда за пропускную способность
        reward += total_vehicles * 0.01
        
        # 5. Большой штраф за пробки
        if total_waiting_time > 100:
            reward -= (total_waiting_time - 100) * 0.05
        
        return reward
    
    def choose_action(self, state: str, observation: Dict) -> Dict:
        """Выбирает действие с использованием ε-жадной стратегии"""
        # Инициализируем состояние если нужно
        if state not in self.q_table:
            self._initialize_state(state)
        
        # ε-жадная стратегия
        if random.random() < self.epsilon:
            # Случайное действие (исследование)
            return self._get_random_action(observation)
        else:
            # Жадное действие (использование)
            return self._get_greedy_action(state, observation)
    
    def _initialize_state(self, state: str):
        """Инициализирует новое состояние в Q-таблице"""
        for tls_id in self.tls_ids:
            for action in self.actions[tls_id]:
                # Начальные значения близкие к 0 с небольшим разбросом
                self.q_table[state][(tls_id, action)] = random.uniform(-0.1, 0.1)
    
    def _get_random_action(self, observation: Dict) -> Dict:
        """Возвращает случайное действие"""
        action_dict = {}
        
        for tls_id in self.tls_ids:
            if tls_id in self.actions and self.actions[tls_id]:
                action = random.choice(self.actions[tls_id])
                # Адаптивная длительность на основе загруженности
                duration = self._calculate_adaptive_duration(tls_id, observation)
                
                action_dict[tls_id] = {
                    'phase_id': action,
                    'duration': duration
                }
        
        return action_dict
    
    def _get_greedy_action(self, state: str, observation: Dict) -> Dict:
        """Возвращает жадное действие"""
        action_dict = {}
        
        for tls_id in self.tls_ids:
            if tls_id not in self.actions or not self.actions[tls_id]:
                continue
            
            # Находим действие с максимальным Q-значением
            best_action = None
            best_q_value = -float('inf')
            
            for action in self.actions[tls_id]:
                q_value = self.q_table[state].get((tls_id, action), 0)
                if q_value > best_q_value:
                    best_q_value = q_value
                    best_action = action
            
            if best_action is not None:
                duration = self._calculate_adaptive_duration(tls_id, observation)
                action_dict[tls_id] = {
                    'phase_id': best_action,
                    'duration': duration
                }
        
        return action_dict
    
    def _calculate_adaptive_duration(self, tls_id: str, observation: Dict) -> float:
        """Рассчитывает адаптивную длительность фазы"""
        base_duration = 30.0
        
        # Учитываем загруженность
        congestion = self._estimate_congestion_near_tls(tls_id, observation)
        
        if congestion == 0:  # нет машин
            return min(60.0, base_duration * 0.7)
        elif congestion == 1:  # мало машин
            return base_duration
        elif congestion == 2:  # средняя загруженность
            return min(90.0, base_duration * 1.5)
        else:  # много машин
            return min(120.0, base_duration * 2.0)
    
    def update_q_table(self, state: str, action: Dict, reward: float, next_state: str):
        """Обновляет Q-таблицу"""
        # Для каждого светофора
        for tls_id, action_info in action.items():
            if tls_id not in self.actions:
                continue
            
            action_idx = action_info['phase_id']
            
            # Текущее Q-значение
            current_q = self.q_table[state].get((tls_id, action_idx), 0)
            
            # Максимальное Q-значение для следующего состояния
            max_next_q = 0
            if next_state in self.q_table:
                next_actions = [a for a in self.q_table[next_state].keys() 
                               if a[0] == tls_id]
                if next_actions:
                    max_next_q = max(self.q_table[next_state][a] for a in next_actions)
            
            # Обновление Q-learning
            new_q = current_q + self.alpha * (
                reward + self.gamma * max_next_q - current_q
            )
            
            self.q_table[state][(tls_id, action_idx)] = new_q
        
        # Записываем в историю
        self.learning_history.append({
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'epsilon': self.epsilon
        })
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """Основной метод принятия решения"""
        # Получаем состояние
        state = self.get_state(observation)
        
        # Если это не первый шаг, обновляем Q-таблицу
        if self.current_state is not None and self.current_action is not None:
            reward = self.calculate_reward(observation)
            self.episode_rewards.append(reward)
            self.update_q_table(self.current_state, self.current_action, reward, state)
        
        # Выбираем действие
        action = self.choose_action(state, observation)
        
        # Обновляем текущее состояние и действие
        self.current_state = state
        self.current_action = action
        
        # Уменьшаем epsilon
        self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
        self.step_count += 1
        
        # Сохраняем каждые 100 шагов
        if self.step_count % 100 == 0:
            self.save_q_table()
        
        return action
    
    def save_q_table(self, filename=None):
        """Сохраняет Q-таблицу"""
        if filename is None:
            filename = Path("result") / "improved_q_table.json"
        
        # Сериализуем
        q_table_serializable = {}
        for state, actions in self.q_table.items():
            q_table_serializable[state] = {}
            for (tls_id, action), q_value in actions.items():
                key = f"{tls_id}_{action}"
                q_table_serializable[state][key] = q_value
        
        with open(filename, 'w') as f:
            json.dump(q_table_serializable, f, indent=2)
    
    def load_q_table(self):
        """Загружает Q-таблицу"""
        filename = Path("result") / "improved_q_table.json"
        if filename.exists():
            try:
                with open(filename, 'r') as f:
                    q_table_loaded = json.load(f)
                
                # Восстанавливаем
                for state, actions in q_table_loaded.items():
                    for key, q_value in actions.items():
                        if '_' in key:
                            tls_id, action_str = key.split('_', 1)
                            action = int(action_str)
                            self.q_table[state][(tls_id, action)] = q_value
                
                print(f"Загружена Q-таблица: {len(self.q_table)} состояний")
            except Exception as e:
                print(f"Ошибка загрузки Q-таблицы: {e}")

# ============================================================================
# 4. PPO КОНТРОЛЛЕР (упрощенная версия)
# ============================================================================

class PPOTrafficController(IntersectionController):
    """
    Упрощенная версия PPO контроллера
    В реальном проекте нужно использовать библиотеки типа stable-baselines3
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # Упрощенные параметры PPO
        self.learning_rate = 0.001
        self.clip_epsilon = 0.2
        self.entropy_coef = 0.01
        
        # Политика (упрощенная)
        self.policy = {}
        self.value_network = {}
        
        # Буферы для обучения
        self.states_buffer = []
        self.actions_buffer = []
        self.rewards_buffer = []
        self.values_buffer = []
        
        # Инициализация
        self._initialize_networks()
        
        print(f"✅ PPO контроллер инициализирован (упрощенная версия)")
        print(f"   Для полноценного PPO используйте stable-baselines3")
    
    def _initialize_networks(self):
        """Инициализирует нейронные сети (упрощенно)"""
        for tls_id in self.tls_ids:
            phases = self.get_phase_catalog(tls_id)
            green_phases = [p.index for p in phases if 'G' in p.state or 'g' in p.state]
            
            if green_phases:
                # Простая равномерная политика
                num_actions = len(green_phases)
                self.policy[tls_id] = np.ones(num_actions) / num_actions
                self.value_network[tls_id] = 0.0
    
    def _extract_features(self, observation: Dict) -> np.ndarray:
        """Извлекает признаки из наблюдения"""
        features = []
        
        # Простые признаки
        total_vehicles = 0
        total_waiting = 0
        
        for edge_id, edge_data in observation.get('edges', {}).items():
            total_vehicles += edge_data.get('veh_number', 0)
            total_waiting += edge_data.get('waiting_time', 0)
        
        features.append(total_vehicles / 100.0)  # нормализовано
        features.append(total_waiting / 1000.0)  # нормализовано
        
        return np.array(features)
    
    def select_action(self, tls_id: str, features: np.ndarray) -> int:
        """Выбирает действие согласно политике"""
        if tls_id not in self.policy:
            return 0
        
        policy_probs = self.policy[tls_id]
        
        # Выбор действия
        action = np.random.choice(len(policy_probs), p=policy_probs)
        
        return action
    
    def estimate_value(self, tls_id: str, features: np.ndarray) -> float:
        """Оценивает value-функцию"""
        if tls_id not in self.value_network:
            return 0.0
        
        # Упрощенная value-функция
        value = self.value_network[tls_id]
        
        return value
    
    def calculate_reward(self, observation: Dict) -> float:
        """Вычисляет награду"""
        reward = 0.0
        
        # Штраф за ожидание
        for edge_id, edge_data in observation.get('edges', {}).items():
            waiting_time = edge_data.get('waiting_time', 0)
            reward -= waiting_time * 0.1
        
        # Награда за движение
        total_speed = sum(
            edge_data.get('mean_speed', 0) 
            for edge_data in observation.get('edges', {}).values()
        )
        reward += total_speed * 0.01
        
        return reward
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """Принимает решение"""
        decision = {}
        
        # Извлекаем признаки
        features = self._extract_features(observation)
        
        for tls_id in self.tls_ids:
            # Выбираем действие
            action_idx = self.select_action(tls_id, features)
            
            # Получаем соответствующую фазу
            phases = self.get_phase_catalog(tls_id)
            green_phases = [p.index for p in phases if 'G' in p.state or 'g' in p.state]
            
            if green_phases and action_idx < len(green_phases):
                phase_id = green_phases[action_idx]
                
                # Простая адаптивная длительность
                duration = 30.0
                
                decision[tls_id] = {
                    'phase_id': phase_id,
                    'duration': duration
                }
        
        return decision if decision else None
    
    def update_policy(self):
        """Обновляет политику (упрощенно)"""
        # В реальной реализации здесь был бы алгоритм PPO
        # Для упрощения просто обновляем на основе наград
        pass

# ============================================================================
# 5. МУЛЬТИАГЕНТНАЯ СИСТЕМА
# ============================================================================

class MultiAgentTrafficController(IntersectionController):
    """
    Мультиагентная система, где светофоры обмениваются информацией
    и координируют свои действия
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # Параметры координации
        self.communication_range = 200.0  # метров
        self.coordination_threshold = 0.7  # порог для координации
        
        # Информация о соседях
        self.neighbors = self._find_neighbors()
        
        # Общая информация
        self.shared_state = {}
        self.coordination_history = defaultdict(list)
        
        # Агенты для каждого светофора
        self.agents = {}
        for tls_id in self.tls_ids:
            self.agents[tls_id] = TrafficLightAgent(tls_id)
        
        print(f"✅ Мультиагентная система инициализирована")
        print(f"   Количество агентов: {len(self.agents)}")
        print(f"   Среднее количество соседей: {np.mean([len(n) for n in self.neighbors.values()]):.1f}")
    
    def _find_neighbors(self) -> Dict[str, List[str]]:
        """Находит соседние светофоры на основе расстояния"""
        neighbors = defaultdict(list)
        
        try:
            import traci
            
            # Получаем позиции всех светофоров
            positions = {}
            for tls_id in self.tls_ids:
                try:
                    pos = traci.junction.getPosition(tls_id)
                    positions[tls_id] = pos
                except:
                    positions[tls_id] = (0, 0)
            
            # Находим соседей по расстоянию
            for tls_id1, pos1 in positions.items():
                for tls_id2, pos2 in positions.items():
                    if tls_id1 == tls_id2:
                        continue
                    
                    # Вычисляем расстояние
                    distance = np.sqrt((pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2)
                    
                    if distance <= self.communication_range:
                        neighbors[tls_id1].append(tls_id2)
        
        except:
            # Простая эвристика если traci не доступен
            for i, tls_id1 in enumerate(self.tls_ids):
                for j, tls_id2 in enumerate(self.tls_ids):
                    if i != j and abs(i - j) <= 2:  # Близкие по индексу считаем соседями
                        neighbors[tls_id1].append(tls_id2)
        
        return neighbors
    
    def _exchange_information(self, observation: Dict):
        """Обмен информацией между агентами"""
        for tls_id, agent in self.agents.items():
            # Собираем локальную информацию
            local_info = {
                'congestion': self._estimate_local_congestion(tls_id, observation),
                'current_phase': self._get_current_phase_index(tls_id),
                'queue_length': self._estimate_queue_length(tls_id, observation)
            }
            
            # Отправляем информацию соседям
            for neighbor_id in self.neighbors.get(tls_id, []):
                if neighbor_id in self.agents:
                    self.agents[neighbor_id].receive_message(tls_id, local_info)
    
    def _estimate_local_congestion(self, tls_id: str, observation: Dict) -> float:
        """Оценивает локальную загруженность"""
        total_vehicles = 0
        
        for edge_id, edge_data in observation.get('edges', {}).items():
            # Простая эвристика: считаем все ТС
            total_vehicles += edge_data.get('veh_number', 0)
        
        return total_vehicles / 50.0  # нормализовано
    
    def _get_current_phase_index(self, tls_id: str) -> int:
        """Получает индекс текущей фазы"""
        try:
            return self.current_phase_index.get(tls_id, 0)
        except:
            return 0
    
    def _estimate_queue_length(self, tls_id: str, observation: Dict) -> float:
        """Оценивает длину очереди"""
        total_queue = 0
        
        for edge_id, edge_data in observation.get('edges', {}).items():
            halting = edge_data.get('halting_number', 0)
            total_queue += halting
        
        return total_queue
    
    def _coordinate_actions(self) -> Dict[str, Dict]:
        """Координирует действия агентов"""
        coordinated_actions = {}
        
        for tls_id, agent in self.agents.items():
            # Агент принимает решение с учетом информации от соседей
            neighbor_info = agent.get_neighbor_info()
            
            if neighbor_info:
                # Учитываем состояние соседей
                avg_neighbor_congestion = np.mean([info['congestion'] for info in neighbor_info.values()])
                neighbor_phases = [info['current_phase'] for info in neighbor_info.values()]
                
                # Простая координация: избегаем одновременного зеленого на пересекающихся направлениях
                action = agent.decide_action(
                    avg_neighbor_congestion=avg_neighbor_congestion,
                    neighbor_phases=neighbor_phases
                )
                
                if action:
                    coordinated_actions[tls_id] = action
        
        return coordinated_actions
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """Принимает скоординированное решение"""
        # Обмен информацией между агентами
        self._exchange_information(observation)
        
        # Координация действий
        coordinated_actions = self._coordinate_actions()
        
        # Если есть скоординированные действия, используем их
        if coordinated_actions:
            return coordinated_actions
        
        # Иначе каждый агент принимает независимое решение
        independent_actions = {}
        
        for tls_id, agent in self.agents.items():
            action = agent.decide_independent_action()
            if action:
                independent_actions[tls_id] = action
        
        return independent_actions if independent_actions else None


class TrafficLightAgent:
    """Агент для управления одним светофором"""
    
    def __init__(self, tls_id: str):
        self.tls_id = tls_id
        self.neighbor_messages = {}
        self.history = deque(maxlen=10)
        
        # Параметры принятия решений
        self.congestion_threshold = 0.3
        self.coordination_weight = 0.7
        
    def receive_message(self, sender_id: str, message: Dict):
        """Получает сообщение от соседа"""
        self.neighbor_messages[sender_id] = message
    
    def get_neighbor_info(self) -> Dict[str, Dict]:
        """Возвращает информацию от соседей"""
        return self.neighbor_messages.copy()
    
    def clear_messages(self):
        """Очищает полученные сообщения"""
        self.neighbor_messages.clear()
    
    def decide_action(self, avg_neighbor_congestion: float, neighbor_phases: List[int]) -> Dict:
        """Принимает решение с учетом информации от соседей"""
        # Простая логика: если соседи сильно загружены, даем им приоритет
        if avg_neighbor_congestion > self.congestion_threshold:
            # Выбираем фазу, которая не конфликтует с соседями
            # В реальной реализации здесь была бы более сложная логика
            return {
                'phase_id': 0,  # Дефолтная фаза
                'duration': 20.0
            }
        
        return None
    
    def decide_independent_action(self) -> Dict:
        """Принимает независимое решение"""
        # Простая циклическая стратегия
        return {
            'phase_id': 0,
            'duration': 30.0
        }
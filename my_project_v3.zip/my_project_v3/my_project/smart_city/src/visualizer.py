# ============================================
# visualizer.py
# Визуализатор SUMO с PyGame и анимацией поворотников
# ============================================

import pygame
import numpy as np
from typing import Dict, List, Tuple, Optional
import traci
import time
import math
from pathlib import Path

try:
    from blinker_animation import get_blinker_manager
    HAS_BLINKERS = True
except ImportError:
    HAS_BLINKERS = False
    print("⚠️  Модуль blinker_animation не найден, поворотники отключены")

class SUMOVisualizer:
    """
    Продвинутый визуализатор для SUMO с:
    - 3D-стилем отображения транспортных средств
    - Анимацией поворотников
    - Графиками в реальном времени
    - Интерактивным управлением
    """
    
    def __init__(self, width: int = 1400, height: int = 900, scale: float = 2.0):
        pygame.init()
        
        # Настройки окна
        self.width = width
        self.height = height
        self.scale = scale
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Адаптивное управление светофорами - RL Визуализатор")
        
        # Цветовая схема
        self.colors = {
            'background': (245, 245, 250),
            'road': (60, 60, 70),
            'road_marking': (255, 255, 255),
            'lane_marking': (200, 200, 200),
            'junction': (80, 80, 90),
            'vehicle': (70, 130, 180),      # стальной синий
            'bus': (220, 20, 60),           # красный
            'truck': (34, 139, 34),         # зеленый лесной
            'emergency': (255, 0, 0),       # красный (экстренные)
            'traffic_light_red': (255, 50, 50),
            'traffic_light_yellow': (255, 200, 50),
            'traffic_light_green': (50, 200, 50),
            'traffic_light_gray': (150, 150, 150),
            'detector_active': (255, 165, 0),   # оранжевый
            'detector_inactive': (100, 100, 100),
            'blinker_orange': (255, 165, 0),    # оранжевый поворотник
            'blinker_red': (255, 50, 50),       # красный поворотник
            'text': (30, 30, 30),
            'panel_bg': (255, 255, 255, 200),
            'chart_bg': (250, 250, 255),
            'chart_line': (70, 130, 180),
            'chart_grid': (220, 220, 230)
        }
        
        # Шрифты
        self.font_small = pygame.font.SysFont('Arial', 11)
        self.font_medium = pygame.font.SysFont('Arial', 13, bold=True)
        self.font_large = pygame.font.SysFont('Arial', 16, bold=True)
        self.font_title = pygame.font.SysFont('Arial', 20, bold=True)
        
        # Смещение карты
        self.offset_x = width // 2
        self.offset_y = height // 2
        
        # Данные для графиков
        self.waiting_history = []
        self.queue_history = []
        self.throughput_history = []
        self.speed_history = []
        self.max_history = 200
        
        # Управление
        self.paused = False
        self.simulation_speed = 1.0
        self.show_detectors = True
        self.show_blinkers = True
        self.show_charts = True
        
        # Менеджер поворотников
        self.blinker_manager = None
        if HAS_BLINKERS:
            self.blinker_manager = get_blinker_manager()
        
        # Кэш геометрии
        self.road_cache = {}
        
        print("✅ Визуализатор инициализирован")
        if HAS_BLINKERS:
            print("   Анимация поворотников: ВКЛЮЧЕНА")
    
    def convert_coords(self, x: float, y: float) -> Tuple[int, int]:
        """Конвертирует SUMO координаты в экранные"""
        screen_x = int(x * self.scale + self.offset_x)
        screen_y = int(-y * self.scale + self.offset_y)
        return screen_x, screen_y
    
    def draw_road_network(self):
        """Рисует дорожную сеть с детализацией"""
        # Получаем все ребра
        edges = traci.edge.getIDList()
        
        for edge_id in edges:
            # Пропускаем внутренние ребра перекрестков
                        if edge_id.startswith(':'):
                continue
            
            # Получаем геометрию ребра
            shape = traci.edge.getShape(edge_id)
            if len(shape) < 2:
                continue
            
            # Рисуем дорогу сегментами
            for i in range(len(shape) - 1):
                x1, y1 = self.convert_coords(shape[i][0], shape[i][1])
                x2, y2 = self.convert_coords(shape[i+1][0], shape[i+1][1])
                
                # Основное полотно дороги (толстое)
                pygame.draw.line(self.screen, self.colors['road'], 
                               (x1, y1), (x2, y2), 14)
                
                # Разметка (тонкая)
                pygame.draw.line(self.screen, self.colors['road_marking'],
                               (x1, y1), (x2, y2), 2)
                
                # Боковые линии
                angle = math.atan2(y2 - y1, x2 - x1)
                perp_angle = angle + math.pi / 2
                offset = 7
                
                # Левая боковая линия
                x1_l = x1 + offset * math.cos(perp_angle)
                y1_l = y1 + offset * math.sin(perp_angle)
                x2_l = x2 + offset * math.cos(perp_angle)
                y2_l = y2 + offset * math.sin(perp_angle)
                pygame.draw.line(self.screen, self.colors['lane_marking'],
                               (int(x1_l), int(y1_l)), (int(x2_l), int(y2_l)), 1)
                
                # Правая боковая линия
                x1_r = x1 - offset * math.cos(perp_angle)
                y1_r = y1 - offset * math.sin(perp_angle)
                x2_r = x2 - offset * math.cos(perp_angle)
                y2_r = y2 - offset * math.sin(perp_angle)
                pygame.draw.line(self.screen, self.colors['lane_marking'],
                               (int(x1_r), int(y1_r)), (int(x2_r), int(y2_r)), 1)
    
    def draw_vehicle(self, veh_id: str, pos: Tuple[float, float], 
                    angle: float, veh_type: str):
        """Рисует одно транспортное средство с детализацией"""
        x, y = self.convert_coords(pos[0], pos[1])
        
        # Определяем цвет и размер в зависимости от типа ТС
        if 'bus' in veh_type.lower():
            color = self.colors['bus']
            length = 12
            width = 3
        elif 'truck' in veh_type.lower():
            color = self.colors['truck']
            length = 8
            width = 2.5
        elif 'emergency' in veh_type.lower():
            color = self.colors['emergency']
            length = 5
            width = 2
        else:
            color = self.colors['vehicle']
            length = 4.5
            width = 1.8
        
        # Масштабируем размеры
        scaled_length = length * self.scale * 0.5
        scaled_width = width * self.scale * 0.5
        
        # Создаем поверхность для транспортного средства
        veh_surface = pygame.Surface((int(scaled_length * 2), int(scaled_width * 2)), 
                                   pygame.SRCALPHA)
        
        # Рисуем кузов
        body_rect = pygame.Rect(scaled_length * 0.2, scaled_width * 0.2,
                               scaled_length * 0.6, scaled_width * 0.6)
        pygame.draw.rect(veh_surface, color, body_rect, border_radius=3)
        
        # Добавляем тень/объем
        pygame.draw.rect(veh_surface, (color[0]//2, color[1]//2, color[2]//2, 100),
                        body_rect, 1, border_radius=3)
        
        # РИСУЕМ ПОВОРОТНИКИ (если включены)
        if self.show_blinkers and self.blinker_manager:
            try:
                # Проверяем состояние поворотников
                if self.blinker_manager.is_blinking(veh_id, 'left'):
                    # Левый поворотник (оранжевый)
                    blinker_color = self.colors['blinker_orange']
                    # Рисуем левый поворотник
                    left_blinker = pygame.Rect(scaled_length * 0.1, scaled_width * 0.3,
                                              scaled_length * 0.15, scaled_width * 0.4)
                    pygame.draw.rect(veh_surface, blinker_color, left_blinker)
                
                if self.blinker_manager.is_blinking(veh_id, 'right'):
                    # Правый поворотник (красный)
                    blinker_color = self.colors['blinker_red']
                    # Рисуем правый поворотник
                    right_blinker = pygame.Rect(scaled_length * 0.75, scaled_width * 0.3,
                                               scaled_length * 0.15, scaled_width * 0.4)
                    pygame.draw.rect(veh_surface, blinker_color, right_blinker)
                
                # Добавляем ТС в отслеживание поворотников
                self.blinker_manager.add_vehicle(veh_id)
                
            except Exception as e:
                # Игнорируем ошибки анимации
                pass
        
        # Вращаем поверхность по направлению движения
        rotated_surface = pygame.transform.rotate(veh_surface, -angle)
        rotated_rect = rotated_surface.get_rect(center=(x, y))
        
        # Отображаем на экране
        self.screen.blit(rotated_surface, rotated_rect)
        
        # Если ТС стоит, рисуем индикатор ожидания
        try:
            speed = traci.vehicle.getSpeed(veh_id)
            if speed < 0.1:
                # Красный кружок над стоящим ТС
                pygame.draw.circle(self.screen, (255, 50, 50), 
                                 (x, y - int(scaled_width)), 3)
        except:
            pass
    
    def draw_vehicles(self):
        """Рисует все транспортные средства"""
        vehicles = traci.vehicle.getIDList()
        
        for veh_id in vehicles:
            try:
                pos = traci.vehicle.getPosition(veh_id)
                angle = traci.vehicle.getAngle(veh_id)
                veh_type = traci.vehicle.getTypeID(veh_id)
                
                self.draw_vehicle(veh_id, pos, angle, veh_type)
            except traci.TraCIException:
                continue
    
    def draw_traffic_lights(self):
        """Рисует светофоры с текущим состоянием"""
        tls_list = traci.trafficlight.getIDList()
        
        for tls_id in tls_list:
            try:
                pos = traci.junction.getPosition(tls_id)
                x, y = self.convert_coords(pos[0], pos[1])
                
                # Получаем состояние светофора
                state = traci.trafficlight.getRedYellowGreenState(tls_id)
                current_phase = traci.trafficlight.getPhase(tls_id)
                next_switch = traci.trafficlight.getNextSwitch(tls_id)
                current_time = traci.simulation.getTime()
                
                # Рисуем основание светофора
                radius = 12
                pygame.draw.circle(self.screen, self.colors['junction'], (x, y), radius)
                pygame.draw.circle(self.screen, (30, 30, 30), (x, y), radius, 2)
                
                # Рисуем индикаторы сигналов (первые 4 для простоты)
                signal_radius = 6
                for i in range(min(4, len(state))):
                    signal = state[i]
                    
                    # Цвет сигнала
                    if signal == 'r':
                        color = self.colors['traffic_light_red']
                    elif signal == 'y':
                        color = self.colors['traffic_light_yellow']
                    elif signal == 'G' or signal == 'g':
                        color = self.colors['traffic_light_green']
                    else:
                        color = self.colors['traffic_light_gray']
                    
                    # Позиция сигнала по кругу
                    angle = i * math.pi / 2
                    signal_x = x + (radius + 10) * math.cos(angle)
                    signal_y = y + (radius + 10) * math.sin(angle)
                    
                    # Рисуем сигнал
                    pygame.draw.circle(self.screen, color, 
                                     (int(signal_x), int(signal_y)), signal_radius)
                    pygame.draw.circle(self.screen, (30, 30, 30), 
                                     (int(signal_x), int(signal_y)), signal_radius, 1)
                
                # Информация о светофоре
                info_text = f"TLS: {tls_id[:6]}..."
                info_surface = self.font_small.render(info_text, True, self.colors['text'])
                self.screen.blit(info_surface, (x - 25, y - 30))
                
                time_text = f"Phase: {current_phase}"
                time_surface = self.font_small.render(time_text, True, self.colors['text'])
                self.screen.blit(time_surface, (x - 20, y + 20))
                
            except traci.TraCIException:
                continue
    
    def draw_detectors(self):
        """Рисует детекторы транспортных средств"""
        if not self.show_detectors:
            return
        
        detectors = traci.inductionloop.getIDList()
        
        for det_id in detectors:
            try:
                pos = traci.inductionloop.getPosition(det_id)
                if not pos:
                    continue
                
                x, y = self.convert_coords(pos[0], pos[1])
                
                # Получаем загруженность детектора
                occupancy = traci.inductionloop.getLastStepOccupancy(det_id)
                
                # Цвет в зависимости от загруженности
                intensity = min(255, int(occupancy * 255 * 3))
                color = (255, 255 - intensity, 0)  # от желтого к красному
                
                # Рисуем детектор
                pygame.draw.circle(self.screen, color, (int(x), int(y)), 6)
                pygame.draw.circle(self.screen, (0, 0, 0), (int(x), int(y)), 6, 1)
                
                # Показываем ID если занятость > 20%
                if occupancy > 0.2:
                    id_text = f"{det_id[-3:]}"
                    id_surface = self.font_small.render(id_text, True, self.colors['text'])
                    self.screen.blit(id_surface, (int(x) + 8, int(y) - 5))
                    
            except traci.TraCIException:
                continue
    
    def draw_info_panel(self):
        """Рисует панель информации и графики"""
        panel_height = 220
        panel_y = self.height - panel_height
        
        # Полупрозрачная панель
        panel_surface = pygame.Surface((self.width, panel_height), pygame.SRCALPHA)
        panel_surface.fill(self.colors['panel_bg'])
        self.screen.blit(panel_surface, (0, panel_y))
        
        # Заголовок
        sim_time = traci.simulation.getTime()
        title_text = f"Адаптивное управление светофорами | Время: {sim_time:.1f} с"
        title_surface = self.font_title.render(title_text, True, self.colors['text'])
        self.screen.blit(title_surface, (20, panel_y + 10))
        
        # Основные метрики
        metrics_y = panel_y + 50
        metrics = [
            f"Транспортных средств: {traci.vehicle.getIDCount()}",
            f"Средняя скорость: {self._get_average_speed():.1f} м/с ({self._get_average_speed()*3.6:.1f} км/ч)",
            f"Стоящих ТС: {self._get_stopped_vehicles()}",
            f"Общая длина очередей: {self._get_total_queue_length():.0f} м",
            f"Общее время ожидания: {self._get_total_waiting_time():.0f} с"
        ]
        
        for i, text in enumerate(metrics):
            metric_surface = self.font_medium.render(text, True, self.colors['text'])
            self.screen.blit(metric_surface, (20, metrics_y + i * 25))
        
        # Рисуем графики если включены
        if self.show_charts:
            self._draw_charts(panel_y)
        
        # Инструкции
        instructions = [
            "Управление:",
            "P - Пауза/Продолжить",
            "+/- - Изменить скорость",
            "D - Детекторы вкл/выкл",
            "B - Поворотники вкл/выкл",
            "C - Графики вкл/выкл",
            "R - Сбросить графики",
            "ESC - Выход"
        ]
        
        instr_x = self.width - 200
        for i, text in enumerate(instructions):
            instr_surface = self.font_small.render(text, True, (50, 50, 150))
            self.screen.blit(instr_surface, (instr_x, metrics_y + i * 20))
    
    def _draw_charts(self, panel_y: int):
        """Рисует мини-графики"""
        chart_width = 350
        chart_height = 80
        spacing = 10
        
        # 1. График времени ожидания
        chart1_x = self.width - chart_width * 2 - spacing * 3
        chart1_y = panel_y + 50
        self._draw_single_chart(chart1_x, chart1_y, chart_width, chart_height,
                              self.waiting_history, "Среднее время ожидания (с)", (0, 60))
        
        # 2. График длины очередей
        chart2_x = chart1_x + chart_width + spacing
        chart2_y = panel_y + 50
        self._draw_single_chart(chart2_x, chart2_y, chart_width, chart_height,
                              self.queue_history, "Длина очередей (м)", (0, 200))
        
        # 3. График пропускной способности
        chart3_x = chart1_x
        chart3_y = panel_y + 50 + chart_height + spacing
        self._draw_single_chart(chart3_x, chart3_y, chart_width, chart_height,
                              self.throughput_history, "Пропускная способность", (0, 50))
        
        # 4. График скорости
        chart4_x = chart2_x
        chart4_y = chart3_y
        self._draw_single_chart(chart4_x, chart4_y, chart_width, chart_height,
                              self.speed_history, "Средняя скорость (км/ч)", (0, 60))
    
    def _draw_single_chart(self, x: int, y: int, width: int, height: int,
                          data: List[float], title: str, y_range: Tuple[float, float]):
        """Рисует один график"""
        # Фон графика
        chart_surface = pygame.Surface((width, height))
        chart_surface.fill(self.colors['chart_bg'])
        
        # Сетка
        grid_step = height // 4
        for i in range(1, 4):
            pygame.draw.line(chart_surface, self.colors['chart_grid'],
                           (0, i * grid_step), (width, i * grid_step), 1)
        
        # Рамка
        pygame.draw.rect(chart_surface, (100, 100, 100), (0, 0, width, height), 1)
        
        # Рисуем данные если они есть
        if len(data) > 1:
            y_min, y_max = y_range
            
            points = []
            for i, value in enumerate(data[-width//2:]):  # ограничиваем количество точек
                x_pos = i * 2  # 2 пикселя на точку
                if y_max > y_min:
                    y_pos = height - ((value - y_min) / (y_max - y_min)) * height
                else:
                    y_pos = height // 2
                y_pos = max(1, min(height - 1, y_pos))
                points.append((x_pos, y_pos))
            
            # Рисуем линию
            if len(points) > 1:
                pygame.draw.lines(chart_surface, self.colors['chart_line'], 
                                False, points, 2)
                
                # Заполняем область под графиком
                fill_points = points + [(points[-1][0], height), (points[0][0], height)]
                pygame.draw.polygon(chart_surface, (*self.colors['chart_line'], 50), 
                                  fill_points)
        
        # Заголовок
        title_surface = self.font_small.render(title, True, self.colors['text'])
        chart_surface.blit(title_surface, (5, 5))
        
        # Текущее значение
        if data:
            current_value = data[-1]
            value_text = f"{current_value:.1f}"
            value_surface = self.font_small.render(value_text, True, self.colors['text'])
            chart_surface.blit(value_surface, (width - 40, 5))
        
        # Отображаем на экране
        self.screen.blit(chart_surface, (x, y))
    
    def _get_average_speed(self) -> float:
        """Вычисляет среднюю скорость всех ТС"""
        vehicles = traci.vehicle.getIDList()
        if not vehicles:
            return 0.0
        
        total_speed = 0
        count = 0
        for veh_id in vehicles:
            try:
                speed = traci.vehicle.getSpeed(veh_id)
                total_speed += speed
                count += 1
            except:
                continue
        
        return total_speed / count if count > 0 else 0.0
    
    def _get_stopped_vehicles(self) -> int:
        """Считает количество остановившихся ТС"""
        vehicles = traci.vehicle.getIDList()
        stopped = 0
        
        for veh_id in vehicles:
            try:
                if traci.vehicle.getSpeed(veh_id) < 0.5:
                    stopped += 1
            except:
                continue
        
        return stopped
    
    def _get_total_queue_length(self) -> float:
        """Вычисляет общую длину очередей"""
        lanes = traci.lane.getIDList()
        total_length = 0.0
        
        for lane_id in lanes:
            try:
                total_length += traci.lane.getJamLengthMeters(lane_id)
            except:
                continue
        
        return total_length
    
    def _get_total_waiting_time(self) -> float:
        """Вычисляет общее время ожидания"""
        vehicles = traci.vehicle.getIDList()
        total_waiting = 0.0
        
        for veh_id in vehicles:
            try:
                total_waiting += traci.vehicle.getWaitingTime(veh_id)
            except:
                continue
        
        return total_waiting
    
    def update_metrics(self):
        """Обновляет метрики для графиков"""
        # Среднее время ожидания
        vehicles = traci.vehicle.getIDList()
        avg_waiting = 0
        if vehicles:
            total_waiting = self._get_total_waiting_time()
            avg_waiting = total_waiting / len(vehicles)
        
        self.waiting_history.append(avg_waiting)
        
        # Длина очередей
        total_queue = self._get_total_queue_length()
        self.queue_history.append(total_queue)
        
        # Пропускная способность (количество ТС)
        self.throughput_history.append(len(vehicles))
        
        # Средняя скорость
        avg_speed = self._get_average_speed()
        self.speed_history.append(avg_speed * 3.6)  # в км/ч
        
        # Ограничиваем историю
        for history in [self.waiting_history, self.queue_history, 
                       self.throughput_history, self.speed_history]:
            if len(history) > self.max_history:
                history.pop(0)
    
    def handle_events(self) -> bool:
        """Обрабатывает события PyGame, возвращает False для выхода"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                
                elif event.key == pygame.K_p:
                    self.paused = not self.paused
                    print(f"{'⏸️ Пауза' if self.paused else '▶️ Продолжить'}")
                
                elif event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS:
                    self.simulation_speed = min(5.0, self.simulation_speed * 1.2)
                    print(f"Скорость симуляции: {self.simulation_speed:.1f}x")
                
                elif event.key == pygame.K_MINUS:
                    self.simulation_speed = max(0.2, self.simulation_speed / 1.2)
                    print(f"Скорость симуляции: {self.simulation_speed:.1f}x")
                
                elif event.key == pygame.K_d:
                    self.show_detectors = not self.show_detectors
                    print(f"Детекторы: {'ВКЛ' if self.show_detectors else 'ВЫКЛ'}")
                
                elif event.key == pygame.K_b:
                    self.show_blinkers = not self.show_blinkers
                    print(f"Поворотники: {'ВКЛ' if self.show_blinkers else 'ВЫКЛ'}")
                
                elif event.key == pygame.K_c:
                    self.show_charts = not self.show_charts
                    print(f"Графики: {'ВКЛ' if self.show_charts else 'ВЫКЛ'}")
                
                elif event.key == pygame.K_r:
                    # Сброс графиков
                    self.waiting_history = []
                    self.queue_history = []
                    self.throughput_history = []
                    self.speed_history = []
                    print("Графики сброшены")
                
                elif event.key == pygame.K_s:
                    # Скриншот
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    filename = f"screenshot_{timestamp}.png"
                    pygame.image.save(self.screen, result_dir / filename)
                    print(f"Скриншот сохранен: {filename}")
        
        return True
    
    def render(self, step: int = 0):
        """Основной метод рендеринга"""
        # Очищаем экран
        self.screen.fill(self.colors['background'])
        
        # Рисуем все компоненты
        self.draw_road_network()
        self.draw_vehicles()
        self.draw_traffic_lights()
        self.draw_detectors()
        self.draw_info_panel()
        
        # Обновляем метрики
        self.update_metrics()
        
        # Обновляем экран
        pygame.display.flip()
        
        # Обрабатываем события
        return self.handle_events()
    
    def cleanup(self):
        """Очистка ресурсов"""
        if self.blinker_manager:
            self.blinker_manager.stop()
        pygame.quit()

def run_simulation_with_visualization(sumo_cfg_path: str, steps: int = 1000, 
                                     controller_type: str = "qlearning"):
    """
    Запускает симуляцию с визуализацией
    
    Args:
        sumo_cfg_path: путь к конфигурационному файлу SUMO
        steps: количество шагов симуляции
        controller_type: тип контроллера ('qlearning', 'participant', 'none')
    """
    import traci
    from pathlib import Path
    
    print("="*70)
    print("🚀 ЗАПУСК СИМУЛЯЦИИ С ВИЗУАЛИЗАЦИЕЙ")
    print("="*70)
    
    # Создаем путь для результатов
    timestamp = int(time.time())
    tripinfo_path = result_dir / f"tripinfo_visual_{timestamp}.xml"
    
    # Команда для запуска SUMO
    cmd = [
        "sumo-gui" if os.path.exists(SUMO_GUI_BINARY) else "sumo",
        "-c", str(sumo_cfg_path),
        "--tripinfo-output", str(tripinfo_path),
        "--start", "true",
        "--quit-on-end", "true",
        "--delay", "100"  # задержка для визуализации
    ]
    
    print(f"Конфиг: {Path(sumo_cfg_path).name}")
    print(f"Шагов: {steps}")
    print(f"Контроллер: {controller_type}")
    print(f"Результаты: {tripinfo_path.name}")
    
    # Запускаем SUMO
    traci.start(cmd)
    
    # Создаем контроллер
    if controller_type == "qlearning":
        from qlearning_controller import QLearningTrafficController
        controller = QLearningTrafficController(tls_ids=None)
        print("✅ Q-learning контроллер создан")
    elif controller_type == "participant":
        from participant_controller import ParticipantController
        controller = ParticipantController(tls_ids=None)
        print("✅ Базовый контроллер создан")
    else:
        controller = None
        print("✅ Контроллер не используется")
    
    # Создаем визуализатор
    visualizer = SUMOVisualizer()
    
    try:
        # Главный цикл симуляции
        for step in range(steps):
            # Обрабатываем паузу
            while visualizer.paused:
                if not visualizer.render(step):
                    traci.close()
                    visualizer.cleanup()
                    return
                time.sleep(0.1)
            
            # Выполняем шаг симуляции
            traci.simulationStep()
            
            # Обновляем контроллер
            if controller:
                try:
                    controller.step()
                except Exception as e:
                    print(f"Ошибка контроллера: {e}")
            
            # Рендерим
            if not visualizer.render(step):
                break
            
            # Задержка для управления скоростью
            time.sleep(0.1 / visualizer.simulation_speed)
            
            # Прогресс
            if (step + 1) % 100 == 0:
                print(f"Шаг {step + 1}/{steps} | ТС: {traci.vehicle.getIDCount()}")
    
    except KeyboardInterrupt:
        print("
⏹️  Симуляция прервана пользователем")
    except Exception as e:
        print(f"
❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Завершаем
        traci.close()
        visualizer.cleanup()
        
        # Анализируем результаты
        if tripinfo_path.exists():
            print(f"
📊 АНАЛИЗ РЕЗУЛЬТАТОВ...")
            from tripinfo_calculator import calculate_metrics, print_metrics
            metrics = calculate_metrics(str(tripinfo_path))
            if metrics:
                print_metrics(metrics)
    
    print("
✅ СИМУЛЯЦИЯ ЗАВЕРШЕНА")

if __name__ == "__main__":
    # Пример использования
    sumo_cfg = "../data/sumo/osm.net_cut.sumocfg"
    run_simulation_with_visualization(
        sumo_cfg_path=sumo_cfg,
        steps=500,
        controller_type="qlearning"
    )

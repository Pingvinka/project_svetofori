# qlearning_controller.py
import numpy as np
import random
import json
import os
from typing import Dict, List, Tuple
from collections import defaultdict
from pathlib import Path

from controller import IntersectionController

class QLearningController(IntersectionController):
    """
    Контроллер с табличным Q-learning для управления светофорами.
    
    State (состояние): комбинация очередей на подходах к перекрестку
    Action (действие): выбор фазы светофора
    Reward (награда): отрицательная сумма времен ожидания всех ТС на перекрестке
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # Параметры Q-learning
        self.alpha = 0.1  # скорость обучения
        self.gamma = 0.9  # коэффициент дисконтирования
        self.epsilon = 0.1  # вероятность случайного действия
        self.min_epsilon = 0.01
        self.epsilon_decay = 0.995
        
        # Q-таблица
        self.q_table = defaultdict(lambda: defaultdict(float))
        
        # Текущее состояние и действие
        self.current_state = None
        self.current_action = None
        self.last_reward = 0
        
        # Для статистики
        self.episode_rewards = []
        self.learning_history = []
        
        # Загрузка сохраненной Q-таблицы, если есть
        self.load_q_table()
        
        # Определяем возможные действия (фазы) для каждого светофора
        self.define_actions()
        
        print(f"QLearningController инициализирован для светофоров: {self.tls_ids}")
        print(f"Размер Q-таблицы: {len(self.q_table)} состояний")
    
    def define_actions(self):
        """Определяем возможные действия (фазы) для каждого светофора"""
        self.actions = {}
        for tls_id in self.tls_ids:
            phases = self.get_phase_catalog(tls_id)
            # Берем только зеленые фазы как возможные действия
            green_phases = [
                phase.index for phase in phases 
                if any(ch in ("G", "g") for ch in phase.state)
            ]
            self.actions[tls_id] = green_phases
            
            print(f"Светофор {tls_id}: {len(green_phases)} зеленых фаз")
    
    def get_state(self, observation: Dict) -> str:
        """
        Преобразуем наблюдение в дискретное состояние.
        Состояние = комбинация уровня загруженности на каждом подходе.
        """
        state_parts = []
        
        # Для каждого светофора определяем уровень очередей на подходах
        for tls_id in self.tls_ids:
            # Получаем ребра, связанные с этим светофором
            # В реальном проекте нужно анализировать конфигурацию перекрестка
            # Здесь используем упрощенный подход: считаем общее количество ТС поблизости
            
            # Ищем детекторы рядом со светофором
            tls_pos = self.get_tls_position(tls_id)
            
            total_vehicles_nearby = 0
            for det_id, det_data in observation['detectors'].items():
                # Простая эвристика: если детектор показывает > 0.2 occupancy, считаем его активным
                if det_data['occupancy'] > 0.2:
                    total_vehicles_nearby += 1
            
            # Дискретизируем: 0=нет машин, 1=мало, 2=много
            if total_vehicles_nearby == 0:
                level = '0'
            elif total_vehicles_nearby <= 3:
                level = '1'
            else:
                level = '2'
            
            state_parts.append(f"{tls_id[:3]}:{level}")
        
        # Также учитываем общее количество ТС в сети
        total_vehicles = sum(
            edge_data['veh_number'] 
            for edge_data in observation['edges'].values()
        )
        
        if total_vehicles < 50:
            traffic_level = 'L'  # Low
        elif total_vehicles < 150:
            traffic_level = 'M'  # Medium
        else:
            traffic_level = 'H'  # High
            
        state_parts.append(f"T:{traffic_level}")
        
        return "_".join(state_parts)
    
    def get_tls_position(self, tls_id: str) -> Tuple[float, float]:
        """Получаем позицию светофора (упрощенная версия)"""
        try:
            import traci
            pos = traci.junction.getPosition(tls_id)
            return pos
        except:
            return (0, 0)
    
    def get_reward(self, observation: Dict) -> float:
        """
        Вычисляем награду:
        Отрицательная сумма времен ожидания всех ТС на подходах к перекрестку
        """
        reward = 0
        
        # Штраф за каждое ожидающее ТС
        for edge_id, edge_data in observation['edges'].items():
            # Используем количество остановившихся ТС и время ожидания
            waiting_vehicles = edge_data.get('halting_number', 0)
            waiting_time = edge_data.get('waiting_time', 0)
            
            # Комбинированный штраф
            reward -= (waiting_vehicles * 0.5 + waiting_time * 0.1)
        
        # Небольшой штраф за смену фазы (чтобы избежать слишком частых переключений)
        if self.current_action and len(self.current_action) > 0:
            reward -= 0.1 * len(self.current_action)
        
        # Награда за движение (положительная скорость)
        total_speed = sum(
            edge_data.get('mean_speed', 0) 
            for edge_data in observation['edges'].values()
        )
        reward += total_speed * 0.01
        
        return reward
    
    def choose_action(self, state: str, observation: Dict) -> Dict:
        """Выбираем действие с использованием ε-жадной стратегии"""
        # Если состояние новое, инициализируем его в Q-таблице
        if state not in self.q_table:
            for tls_id in self.tls_ids:
                for action in self.actions[tls_id]:
                    self.q_table[state][(tls_id, action)] = 0
        
        # ε-жадная стратегия
        if random.random() < self.epsilon:
            # Случайное действие
            action_dict = {}
            for tls_id in self.tls_ids:
                action = random.choice(self.actions[tls_id])
                # Базовая длительность фазы
                duration = 30.0  # секунд
                action_dict[tls_id] = {"phase_id": action, "duration": duration}
            
            print(f"[RL] Случайное действие: {action_dict}")
            return action_dict
        else:
            # Жадное действие (максимизируем Q-value)
            action_dict = {}
            for tls_id in self.tls_ids:
                # Находим лучшее действие для этого светофора
                best_action = None
                best_q_value = -float('inf')
                
                for action in self.actions[tls_id]:
                    q_value = self.q_table[state].get((tls_id, action), 0)
                    if q_value > best_q_value:
                        best_q_value = q_value
                        best_action = action
                
                if best_action is not None:
                    # Адаптивная длительность фазы в зависимости от загруженности
                    base_duration = 30.0
                    
                    # Увеличиваем длительность, если много машин
                    vehicles_nearby = self.count_vehicles_near_tls(tls_id, observation)
                    if vehicles_nearby > 5:
                        duration = min(60.0, base_duration * 1.5)
                    elif vehicles_nearby > 10:
                        duration = min(90.0, base_duration * 2.0)
                    else:
                        duration = base_duration
                    
                    action_dict[tls_id] = {"phase_id": best_action, "duration": duration}
            
            print(f"[RL] Жадное действие: {action_dict}")
            return action_dict
    
    def count_vehicles_near_tls(self, tls_id: str, observation: Dict) -> int:
        """Считаем ТС поблизости от светофора"""
        count = 0
        for edge_id, edge_data in observation['edges'].items():
            # Простая эвристика: считаем ТС на всех ребрах
            count += int(edge_data.get('veh_number', 0))
        return count
    
    def update_q_value(self, state: str, action: Dict, reward: float, next_state: str):
        """Обновляем Q-таблицу по правилу Q-learning"""
        # Для каждого светофора в действии
        for tls_id, action_info in action.items():
            action_idx = action_info['phase_id']
            
            # Текущее Q-значение
            current_q = self.q_table[state].get((tls_id, action_idx), 0)
            
            # Максимальное Q-значение для следующего состояния
            max_next_q = 0
            if next_state in self.q_table:
                next_actions = [a for a in self.q_table[next_state].keys() if a[0] == tls_id]
                if next_actions:
                    max_next_q = max(self.q_table[next_state][a] for a in next_actions)
            
            # Обновление по правилу Q-learning
            new_q = current_q + self.alpha * (
                reward + self.gamma * max_next_q - current_q
            )
            
            self.q_table[state][(tls_id, action_idx)] = new_q
        
        # Запись в историю
        self.learning_history.append({
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'epsilon': self.epsilon
        })
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """Основной метод принятия решения"""
        # Получаем текущее состояние
        state = self.get_state(observation)
        
        # Если это не первый шаг, обновляем Q-таблицу
        if self.current_state is not None and self.current_action is not None:
            reward = self.get_reward(observation)
            self.last_reward = reward
            self.update_q_value(self.current_state, self.current_action, reward, state)
            
            # Сохраняем награду для статистики
            self.episode_rewards.append(reward)
        
        # Выбираем новое действие
        action = self.choose_action(state, observation)
        
        # Сохраняем текущее состояние и действие
        self.current_state = state
        self.current_action = action
        
        # Уменьшаем epsilon (эксплорейшн)
        self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
        
        return action
    
    def save_q_table(self):
        """Сохраняем Q-таблицу в файл"""
        # Преобразуем defaultdict в обычный dict для сериализации
        q_table_serializable = {}
        for state, actions in self.q_table.items():
            q_table_serializable[state] = {}
            for (tls_id, action), q_value in actions.items():
                key = f"{tls_id}_{action}"
                q_table_serializable[state][key] = q_value
        
        save_path = Path("result") / "q_table.json"
        with open(save_path, 'w') as f:
            json.dump(q_table_serializable, f, indent=2)
        
        print(f"[RL] Q-таблица сохранена: {save_path}")
    
    def load_q_table(self):
        """Загружаем Q-таблицу из файла"""
        save_path = Path("result") / "q_table.json"
        if save_path.exists():
            try:
                with open(save_path, 'r') as f:
                    q_table_loaded = json.load(f)
                
                # Восстанавливаем defaultdict
                for state, actions in q_table_loaded.items():
                    for key, q_value in actions.items():
                        if '_' in key:
                            tls_id, action_str = key.split('_', 1)
                            action = int(action_str)
                            self.q_table[state][(tls_id, action)] = q_value
                
                print(f"[RL] Q-таблица загружена: {len(self.q_table)} состояний")
            except Exception as e:
                print(f"[RL] Ошибка загрузки Q-таблицы: {e}")
    
    def save_learning_stats(self):
        """Сохраняем статистику обучения"""
        if not self.learning_history:
            return
        
        stats_path = Path("result") / "learning_stats.json"
        stats = {
            'total_episodes': len(self.episode_rewards),
            'average_reward': np.mean(self.episode_rewards) if self.episode_rewards else 0,
            'total_states': len(self.q_table),
            'epsilon': self.epsilon,
            'recent_rewards': self.episode_rewards[-100:] if len(self.episode_rewards) > 100 else self.episode_rewards
        }
        
        with open(stats_path, 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"[RL] Статистика сохранена: {stats_path}")
    
    def reset_episode(self):
        """Сброс для нового эпизода"""
        self.current_state = None
        self.current_action = None
        self.last_reward = 0
        
        # Сохраняем статистику каждые 10 эпизодов
        if len(self.episode_rewards) % 10 == 0:
            self.save_q_table()
            self.save_learning_stats()
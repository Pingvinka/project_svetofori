# simple_qlearning_controller.py
import numpy as np
from typing import Dict, List
import pickle
import os
import random
import traci
from controller import IntersectionController

class SimpleQLearningController(IntersectionController):
    """
    Максимально простой Q-learning контроллер для демонстрации
    """
    
    def __init__(self, tls_ids=None, detector_ids=None, edge_ids=None):
        super().__init__(tls_ids, detector_ids, edge_ids)
        
        # ОЧЕНЬ простые параметры
        self.alpha = 0.1  # скорость обучения
        self.gamma = 0.9  # дисконтирование
        self.epsilon = 0.3  # exploration
        self.min_epsilon = 0.01
        self.epsilon_decay = 0.995
        
        # Q-таблица
        self.q_table = {}
        
        # Статистика
        self.total_reward = 0
        self.step_count = 0
        self.rewards = []  # Список наград
        
        # Инициализация
        self.current_state = None
        self.last_action = None
        self.last_reward = 0
        
        print(f"✅ Простой Q-learning контроллер создан")
        print(f"   Управляем {len(self.tls_ids)} светофорами")
    
    def _get_state_key(self) -> str:
        """Создает простой ключ состояния"""
        try:
            # Только 2 параметра: текущие фазы и количество ТС
            phase_str = ""
            for tls_id in list(self.tls_ids)[:2]:  # только 2 светофора
                phase_idx = self.current_phase_index.get(tls_id, 0)
                phase_str += f"p{phase_idx}"
            
            # Количество ТС (грубо)
            veh_count = traci.vehicle.getIDCount()
            veh_bin = min(5, veh_count // 10)
            
            return f"{phase_str}_v{veh_bin}"
            
        except:
            return "default"
    
    def _get_available_actions(self) -> List[Dict]:
        """Очень простые действия"""
        actions = []
        
        for tls_id in list(self.tls_ids)[:2]:  # только 2 светофора
            # Только 2 варианта: текущая фаза или следующая
            current_phase = self.current_phase_index.get(tls_id, 0)
            
            # Получаем количество фаз
            try:
                phases = self.get_phase_catalog(tls_id)
                num_phases = len(phases)
                next_phase = (current_phase + 1) % num_phases
            except:
                num_phases = 4
                next_phase = (current_phase + 1) % 4
            
            # Только 2 фазы
            for phase in [current_phase, next_phase]:
                actions.append({
                    'tls_id': tls_id,
                    'phase_id': phase,
                    'duration': 30  # фиксированная длительность
                })
        
        # Если нет действий - создаем одно по умолчанию
        if not actions:
            actions.append({
                'tls_id': list(self.tls_ids)[0] if self.tls_ids else "default",
                'phase_id': 0,
                'duration': 30
            })
        
        return actions
    
    def _calculate_reward(self) -> float:
        """Простая награда"""
        try:
            # 1. Награда за движущиеся ТС
            moving_vehicles = 0
            for veh_id in traci.vehicle.getIDList():
                if traci.vehicle.getSpeed(veh_id) > 0.1:
                    moving_vehicles += 1
            
            # 2. Штраф за ожидающие ТС
            waiting_vehicles = 0
            for veh_id in traci.vehicle.getIDList():
                if traci.vehicle.getSpeed(veh_id) < 0.1:
                    waiting_vehicles += 1
            
            # Простая формула
            reward = moving_vehicles * 0.1 - waiting_vehicles * 0.2
            
            # Ограничиваем диапазон
            reward = max(-10, min(10, reward))
            
            return reward
            
        except:
            return 0
    
    def decide_next_phase(self, observation):
        """Принимает решение"""
        try:
            # Получаем состояние
            state_key = self._get_state_key()
            self.current_state = state_key
            
            # Получаем доступные действия
            available_actions = self._get_available_actions()
            
            # Инициализируем Q-значения если нужно
            if state_key not in self.q_table:
                self.q_table[state_key] = np.zeros(len(available_actions))
            
            # Epsilon-greedy выбор
            if random.random() < self.epsilon:
                # Случайное действие
                action_idx = random.randint(0, len(available_actions) - 1)
            else:
                # Жадное действие
                q_values = self.q_table[state_key]
                action_idx = np.argmax(q_values)
            
            # Выбираем действие
            action = available_actions[action_idx]
            self.last_action = (state_key, action_idx)
            
            # Создаем решение
            decision = {}
            for tls_id in list(self.tls_ids)[:2]:
                # Находим действие для этого светофора
                for act in available_actions:
                    if act['tls_id'] == tls_id:
                        decision[tls_id] = {
                            'phase_id': act['phase_id'],
                            'duration': act['duration']
                        }
                        break
            
            return decision
            
        except Exception as e:
            print(f"⚠️ Ошибка в decide_next_phase: {e}")
            return None
    
    def step(self):
        """Выполняет шаг с обучением"""
        # Получаем наблюдение
        observation = self.build_observation()
        
        # Принимаем решение
        decision = self.decide_next_phase(observation)
        
        # Применяем решение
        self.apply_decision(decision)
        
        # Выполняем шаг симуляции
        traci.simulationStep()
        
        # Вычисляем награду
        reward = self._calculate_reward()
        self.last_reward = reward
        self.total_reward += reward
        self.rewards.append(reward)
        
        # Обновляем Q-таблицу
        if self.last_action and self.current_state:
            old_state, action_idx = self.last_action
            
            # Получаем новое состояние
            new_state = self._get_state_key()
            
            # Инициализируем Q-значения если нужно
            if old_state not in self.q_table:
                self.q_table[old_state] = np.zeros(10)  # произвольный размер
            if new_state not in self.q_table:
                self.q_table[new_state] = np.zeros(10)
            
            # Проверяем размеры
            if action_idx >= len(self.q_table[old_state]):
                # Расширяем
                new_size = action_idx + 1
                new_array = np.zeros(new_size)
                old_array = self.q_table[old_state]
                new_array[:len(old_array)] = old_array
                self.q_table[old_state] = new_array
            
            # Q-learning update
            old_q = self.q_table[old_state][action_idx]
            next_max_q = np.max(self.q_table[new_state])
            new_q = old_q + self.alpha * (reward + self.gamma * next_max_q - old_q)
            self.q_table[old_state][action_idx] = new_q
        
        # Обновляем статистику
        self.step_count += 1
        self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
        
        # Сохраняем каждые 200 шагов
        if self.step_count % 200 == 0:
            self._save_q_table()
        
        return observation
    
    def _save_q_table(self, filename=None):
        """Сохраняет Q-таблицу"""
        if filename is None:
            filename = result_dir / f"simple_qtable_{self.step_count}.pkl"
        
        # Конвертируем numpy массивы в списки
        q_table_serializable = {}
        for key, value in self.q_table.items():
            q_table_serializable[key] = value.tolist()
        
        data = {
            'q_table': q_table_serializable,
            'step_count': self.step_count,
            'epsilon': self.epsilon,
            'total_reward': self.total_reward,
            'rewards': self.rewards[-500:]  # сохраняем последние 500 наград
        }
        
        with open(filename, 'wb') as f:
            pickle.dump(data, f)
        
        print(f"💾 Q-таблица сохранена (шаг {self.step_count})")
    
    def get_stats(self):
        """Возвращает статистику"""
        avg_reward = np.mean(self.rewards[-100:]) if len(self.rewards) >= 100 else 0
        
        # Среднее Q-значение
        avg_q = 0
        if self.q_table:
            all_q = []
            for q_values in self.q_table.values():
                all_q.extend(q_values.tolist())
            avg_q = np.mean(all_q) if all_q else 0
        
        return {
            'steps': self.step_count,
            'total_reward': self.total_reward,
            'avg_reward': avg_reward,
            'epsilon': self.epsilon,
            'q_table_size': len(self.q_table),
            'avg_q_value': avg_q
        }
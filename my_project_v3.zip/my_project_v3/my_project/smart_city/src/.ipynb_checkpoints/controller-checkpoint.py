from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union, cast

import traci


@dataclass(frozen=True)
class PhaseDescriptor:
    """Описание одной фазы SUMO: что горит, сколько длится и куда можно перейти дальше"""

    tls_id: str
    index: int
    state: str
    default_duration: float
    min_duration: Optional[float]
    max_duration: Optional[float]
    next_phases: List[int]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "tls_id": self.tls_id,
            "index": self.index,
            "state": self.state,
            "default_duration": self.default_duration,
            "min_duration": self.min_duration,
            "max_duration": self.max_duration,
            "next_phases": list(self.next_phases),
        }

    def clamp_duration(self, duration: Optional[float]) -> float:
        """Применяет min/max, если они указаны в программе светофора."""
        if duration is None:
            duration = self.default_duration or 1.0
        if duration <= 0:
            raise ValueError("Phase duration must be positive.")
        if self.min_duration is not None:
            duration = max(duration, self.min_duration)
        if self.max_duration is not None:
            duration = min(duration, self.max_duration)
        return duration


class IntersectionController:
    """
    Контроллер перекрестка SUMO
    Управляем всем набором светофоров на перекрестке и собираем наблюдения о загруженности
    """

    def __init__(
        self,
        tls_ids: Union[str, Sequence[str], None],
        detector_ids: Optional[Iterable[str]] = None,
        edge_ids: Optional[Iterable[str]] = None,
    ):
        """
        :param tls_ids: идентификаторы светофоров (traffic light systems), которыми нужно управлять.
                        Можно указать один id, последовательность id или None — тогда возьмём все
                        светофоры из текущей сети
        :param detector_ids: список ID детекторов
        :param edge_ids: список ID ребер для агрегированной статистики
        """
        if tls_ids is None:
            tls_iter = traci.trafficlight.getIDList()
            if not tls_iter:
                raise ValueError("В сети не найдено светофоров, передайте tls_ids вручную")
            tls = list(tls_iter)
        elif isinstance(tls_ids, str):
            tls = [tls_ids]
        else:
            tls = list(tls_ids)

        if not tls:
            raise ValueError("Список tls_ids не может быть пустым")
        
        self.tls_ids: Tuple[str, ...] = tuple(tls)

        if detector_ids is None:
            det_iter = traci.inductionloop.getIDList()
            self.detector_ids = list(det_iter)
        else:
            self.detector_ids = list(detector_ids)

        self.edge_ids = list(edge_ids or [])

        self._programs: Dict[str, Any] = {}
        self._phase_catalog: Dict[str, List[PhaseDescriptor]] = {}
        self._state_to_phase: Dict[str, Dict[str, PhaseDescriptor]] = {}
        self.current_phase_index: Dict[str, int] = {}

        for tls_id in self.tls_ids:
            # Берем активную программу светофора
            program = traci.trafficlight.getCompleteRedYellowGreenDefinition(tls_id)[0]
            catalog = self._build_phase_catalog(tls_id, program)
            self._programs[tls_id] = program
            self._phase_catalog[tls_id] = catalog
            self._state_to_phase[tls_id] = {phase.state: phase for phase in catalog}
            self.current_phase_index[tls_id] = traci.trafficlight.getPhase(tls_id)

        self.last_decision: Dict[str, Dict[str, Any]] = {}
        self.step_count = 0

    # ---------- ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ----------

    def _build_phase_catalog(self, tls_id: str, program: Any) -> List[PhaseDescriptor]:
        catalog: List[PhaseDescriptor] = []
        for idx, phase in enumerate(program.phases):
            min_dur = getattr(phase, "minDur", None)
            max_dur = getattr(phase, "maxDur", None)

            min_dur = None if min_dur is None or min_dur < 0 else float(min_dur)
            max_dur = None if max_dur is None or max_dur < 0 else float(max_dur)
            default_duration = float(getattr(phase, "duration", 0) or 0)

            if (
                min_dur is not None
                and max_dur is not None
                and abs(min_dur - max_dur) < 1e-6
                and abs(min_dur - default_duration) < 1e-6
            ):
                min_dur = None
                max_dur = None

            next_list = list(getattr(phase, "next", []) or [])

            catalog.append(
                PhaseDescriptor(
                    tls_id=tls_id,
                    index=idx,
                    state=phase.state,
                    default_duration=default_duration,
                    min_duration=min_dur,
                    max_duration=max_dur,
                    next_phases=next_list,
                )
            )
        return catalog

    def get_phase_catalog(self, tls_id: Optional[str] = None):
        """
        Возвращает описание фаз.
        Без аргумента вернёт dict {tls_id: [PhaseDescriptor, ...]}
        """
        if tls_id is None:
            return {tid: list(phases) for tid, phases in self._phase_catalog.items()}
        if tls_id not in self._phase_catalog:
            raise KeyError(f"Неизвестный tls_id '{tls_id}'.")
        return list(self._phase_catalog[tls_id])

    def get_current_phase(self, tls_id: Optional[str] = None) -> PhaseDescriptor:
        """
        Возвращает descriptor текущей фазы
        Если tls_id не указан, используем единственный светофор (если их больше одного — ошибка)
        """
        if tls_id is None:
            if len(self.tls_ids) != 1:
                raise ValueError("Для перекрестка с несколькими светофорами укажите tls_id явно.")
            tls_id = self.tls_ids[0]
        return self._phase_catalog[tls_id][self.current_phase_index[tls_id]]

    def get_phase(self, index: int, tls_id: Optional[str] = None) -> PhaseDescriptor:
        if tls_id is None:
            if len(self.tls_ids) != 1:
                raise ValueError("Для перекрестка с несколькими светофорами укажите tls_id явно.")
            tls_id = self.tls_ids[0]
        return self._phase_catalog[tls_id][index]

    # ---------- СБОР ДАННЫХ ----------

    def read_detectors(self) -> Dict[str, Dict[str, float]]:
        """значения с детекторов"""
        data: Dict[str, Dict[str, float]] = {}
        for det_id in self.detector_ids:
            veh_number = 0.0
            mean_speed = 0.0
            occupancy = 0.0
            queue_length = 0.0
            try:
                veh_number = float(traci.inductionloop.getLastStepVehicleNumber(det_id))
                mean_speed = float(traci.inductionloop.getLastStepMeanSpeed(det_id))
                occupancy = float(traci.inductionloop.getLastStepOccupancy(det_id))
                lane_id = traci.inductionloop.getLaneID(det_id)
                if lane_id:
                    try:
                        queue_length = float(traci.lane.getJamLengthVehicle(lane_id))
                    except AttributeError:
                        queue_length = float(traci.lane.getLength(lane_id))
                    except traci.TraCIException:
                        queue_length = 0.0
            except traci.TraCIException:
                pass

            data[det_id] = {
                "veh_number": veh_number,
                "mean_speed": mean_speed,
                "occupancy": occupancy,
                "queue_length": queue_length,
            }
        return data

    def read_edges(self) -> Dict[str, Dict[str, float]]:
        """Собирает агрегированные метрики по ребрам."""
        data: Dict[str, Dict[str, float]] = {}
        for edge_id in self.edge_ids:
            try:
                data[edge_id] = {
                    "veh_number": float(traci.edge.getLastStepVehicleNumber(edge_id)),
                    "halting_number": float(traci.edge.getLastStepHaltingNumber(edge_id)),
                    "mean_speed": float(traci.edge.getLastStepMeanSpeed(edge_id)),
                    "waiting_time": float(traci.edge.getWaitingTime(edge_id)),
                    "travel_time": float(traci.edge.getTraveltime(edge_id)),
                }
            except traci.TraCIException:
                data[edge_id] = {
                    "veh_number": 0.0,
                    "halting_number": 0.0,
                    "mean_speed": 0.0,
                    "waiting_time": 0.0,
                    "travel_time": 0.0,
                }
        return data

    def build_observation(self) -> Dict[str, Any]:
        """Формирует наблюдение: время шага, состояние светофоров, показания датчиков."""
        sim_time = float(traci.simulation.getTime())
        lights: Dict[str, Dict[str, Any]] = {}
        for tls_id in self.tls_ids:
            next_switch = float(traci.trafficlight.getNextSwitch(tls_id))
            # Отдаем все, что нужно для планирования: текущую фазу и остаток времени
            lights[tls_id] = {
                "current_phase": self.get_current_phase(tls_id).as_dict(),
                "time_to_next_switch": max(0.0, next_switch - sim_time),
            }

        obs = {
            "sim_time": sim_time,
            "lights": lights,
            "detectors": self.read_detectors(),
            "edges": self.read_edges(),
        }
        return obs

    # ---------- УПРАВЛЕНИЕ ФАЗАМИ ----------

    def _set_phase(self, tls_id: str, descriptor: PhaseDescriptor, duration: float) -> PhaseDescriptor:
        traci.trafficlight.setPhase(tls_id, descriptor.index)
        traci.trafficlight.setPhaseDuration(tls_id, duration)
        self.current_phase_index[tls_id] = descriptor.index
        return descriptor

    def apply_decision(
        self, decision: Optional[Union[Dict[str, Any], Dict[str, Dict[str, Any]]]]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Применяет решение участника к каждому светофору на перекрестке.

        Ожидаемый формат:
            {
                "TLS_ID": {"phase_id": 0, "duration": 25.0},
                ...
            }
        Для перекрестков с одним светофором допускается краткая форма {"phase_id": ..., "duration": ...}.
        """
        if decision is None:
            return {}
        if not isinstance(decision, dict):
            raise TypeError("Decision must be a dict mapping tls_id to phase spec.")

        if len(self.tls_ids) == 1 and ("phase_id" in decision or "state" in decision):
            normalized_decision: Dict[str, Dict[str, Any]] = {
                self.tls_ids[0]: cast(Dict[str, Any], decision)
            }
        else:
            normalized_decision = cast(Dict[str, Dict[str, Any]], decision)

        applied_info: Dict[str, Dict[str, Any]] = {}
        for tls_id, sub_decision in normalized_decision.items():
            if tls_id not in self._phase_catalog:
                raise KeyError(f"Светофор '{tls_id}' не управляется этим контроллером.")
            if sub_decision is None:
                continue
            if not isinstance(sub_decision, dict):
                raise TypeError(f"Decision for '{tls_id}' must be a dict.")

            # Решение можно сформулировать индексом или строкой состояния — оставляем обе опции.
            descriptor: Optional[PhaseDescriptor] = None
            if "phase_id" in sub_decision:
                phase_id = int(sub_decision["phase_id"])
                if phase_id < 0 or phase_id >= len(self._phase_catalog[tls_id]):
                    raise ValueError(f"Phase id {phase_id} is out of range for '{tls_id}'.")
                descriptor = self._phase_catalog[tls_id][phase_id]
            elif "state" in sub_decision:
                state = str(sub_decision["state"])
                phase_map = self._state_to_phase[tls_id]
                if state not in phase_map:
                    raise ValueError(f"Unknown state '{state}' for '{tls_id}'.")
                descriptor = phase_map[state]
            else:
                raise KeyError(f"Decision for '{tls_id}' must contain 'phase_id' or 'state'.")

            duration = descriptor.clamp_duration(sub_decision.get("duration"))
            self._set_phase(tls_id, descriptor, duration)
            applied_info[tls_id] = {"phase_id": descriptor.index, "duration": duration}

        if applied_info:
            self.last_decision = applied_info
        return applied_info

    # ---------- ИНТЕРФЕЙС ДЛЯ РЕШЕНИЙ ----------

    def decide_next_phase(self, observation: Dict[str, Any]) -> Optional[Dict[str, Dict[str, Any]]]:
        """
        переобпределяемый метод
        На входе — наблюдение, на выходе — решение в формате apply_decision()
        """
        raise NotImplementedError("Участник должен реализовать decide_next_phase().")

    def step(self) -> Dict[str, Any]:
        """Собирает наблюдение, принимает решение и применяет его"""
        observation = self.build_observation()
        decision = self.decide_next_phase(observation)
        self.apply_decision(decision)
        self.step_count += 1
        return observation

# participant_controller.py (обновленная версия)
import os
from typing import Dict

# Используем наш QLearningController вместо простого циклического
from qlearning_controller import QLearningController

# Можно переключаться между разными стратегиями
STRATEGY = os.environ.get("CONTROL_STRATEGY", "qlearning").strip().lower()

class ParticipantController(QLearningController):
    """
    Контроллер участника с Q-learning.
    Наследуется от QLearningController для обучения с подкреплением.
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        print(f"Участник использует стратегию: {STRATEGY}")
        
        # Дополнительные настройки в зависимости от стратегии
        if STRATEGY == "balanced":
            # Балансированная стратегия (циклическая)
            self.use_rl = False
            self.setup_balanced_strategy()
        else:
            # Q-learning стратегия
            self.use_rl = True
    
    def setup_balanced_strategy(self):
        """Настройка циклической стратегии"""
        self.green_phases = {}
        self.cursor = {}
        
        for tls_id in self.tls_ids:
            phases = self.get_phase_catalog(tls_id)
            greens = [
                phase.index
                for phase in phases
                if "y" not in phase.state and any(ch in ("G", "g") for ch in phase.state)
            ]
            if greens:
                self.green_phases[tls_id] = greens
                self.cursor[tls_id] = 0
    
    def decide_next_phase(self, observation: Dict) -> Dict:
        """
        Переопределяем метод принятия решения.
        В зависимости от стратегии используем RL или циклический алгоритм.
        """
        if self.use_rl:
            # Используем Q-learning
            return super().decide_next_phase(observation)
        else:
            # Используем циклическую стратегию
            return self.balanced_decision(observation)
    
    def balanced_decision(self, observation: Dict) -> Dict:
        """Циклическая стратегия (для сравнения)"""
        decision = {}
        
        for tls_id in self.tls_ids:
            if tls_id not in self.green_phases:
                continue
                
            greens = self.green_phases[tls_id]
            if not greens:
                continue
            
            # Проверяем, не пора ли сменить фазу
            light_info = observation["lights"].get(tls_id, {})
            time_to_switch = light_info.get("time_to_next_switch", 0)
            
            if time_to_switch > 0.5:
                continue
            
            # Выбираем следующую фазу по циклу
            idx = self.cursor[tls_id]
            next_phase = greens[idx]
            self.cursor[tls_id] = (idx + 1) % len(greens)
            
            # Фиксированная длительность
            duration = 30.0
            
            decision[tls_id] = {
                "phase_id": next_phase,
                "duration": duration
            }
        
        return decision if decision else None
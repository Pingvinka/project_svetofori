# ============================================
# blinker_animation.py
# Модуль для анимации поворотников транспортных средств
# ============================================

import traci
import time
import math
import threading
from typing import Dict

class BlinkerManager:
    """Управляет анимацией поворотников"""
    
    def __init__(self, frequency: float = 1.0):
        self.frequency = frequency  # частота мигания (Гц)
        self.blinker_states: Dict[str, Dict] = {}  # состояние поворотников
        self.running = True
        self.last_update = time.time()
        
        # Запускаем поток анимации
        self.thread = threading.Thread(target=self._animation_loop, daemon=True)
        self.thread.start()
    
    def _animation_loop(self):
        """Основной цикл анимации"""
        while self.running:
            current_time = time.time()
            dt = current_time - self.last_update
            
            # Обновляем состояние всех ТС
            for veh_id in list(self.blinker_states.keys()):
                if veh_id in traci.vehicle.getIDList():
                    # Увеличиваем фазу мигания
                    phase = self.blinker_states[veh_id].get('phase', 0)
                    phase = (phase + dt * self.frequency) % 1.0
                    self.blinker_states[veh_id]['phase'] = phase
                    
                    # Определяем, нужно ли мигать
                    speed = traci.vehicle.getSpeed(veh_id)
                    if speed < 1.0:  # ТС остановилось
                        # Включаем поворотники
                        lane_idx = traci.vehicle.getLaneIndex(veh_id)
                        if lane_idx == 0:  # правая полоса
                            self.blinker_states[veh_id]['left'] = True
                            self.blinker_states[veh_id]['right'] = False
                        else:  # левая полоса
                            self.blinker_states[veh_id]['left'] = False
                            self.blinker_states[veh_id]['right'] = True
                    else:
                        # Выключаем поворотники при движении
                        self.blinker_states[veh_id]['left'] = False
                        self.blinker_states[veh_id]['right'] = False
            
            self.last_update = current_time
            time.sleep(0.05)  # 20 FPS
    
    def is_blinking(self, veh_id: str, side: str) -> bool:
        """Проверяет, мигает ли поворотник"""
        if veh_id not in self.blinker_states:
            return False
        
        state = self.blinker_states[veh_id]
        if not state.get(side, False):
            return False
        
        # Мигание: синусоида с периодом frequency
        phase = state.get('phase', 0)
        return math.sin(phase * 2 * math.pi) > 0
    
    def get_blinker_color(self, veh_id: str, side: str) -> tuple:
        """Возвращает цвет поворотника"""
        if self.is_blinking(veh_id, side):
            return (255, 165, 0) if 'front' in side else (255, 0, 0)
        return (100, 100, 100)  # серый (выключен)
    
    def add_vehicle(self, veh_id: str):
        """Добавляет ТС для отслеживания"""
        if veh_id not in self.blinker_states:
            self.blinker_states[veh_id] = {
                'phase': 0,
                'left': False,
                'right': False
            }
    
    def stop(self):
        """Останавливает анимацию"""
        self.running = False
        if self.thread.is_alive():
            self.thread.join(timeout=1.0)

# Глобальный экземпляр
blinker_manager = BlinkerManager()

def get_blinker_manager() -> BlinkerManager:
    return blinker_manager

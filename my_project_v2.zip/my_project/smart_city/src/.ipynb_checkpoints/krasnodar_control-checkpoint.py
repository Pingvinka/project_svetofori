# ============================================
# krasnodar_controller.py
# Улучшенный контроллер для адаптивного управления светофорами
# ============================================

from typing import Dict, List, Optional, Tuple, Any
import traci
import numpy as np
from dataclasses import dataclass
import time


@dataclass
class TrafficMetrics:
    """Метрики трафика для перекрестка"""
    vehicle_count: int = 0
    waiting_time: float = 0
    queue_length: float = 0
    average_speed: float = 0
    occupancy: float = 0
    
    def to_array(self) -> np.ndarray:
        """Преобразует метрики в numpy массив"""
        return np.array([
            self.vehicle_count,
            self.waiting_time,
            self.queue_length,
            self.average_speed,
            self.occupancy
        ])


class KrasnodarTrafficController:
    """
    Улучшенный контроллер для управления светофорами Краснодара
    с поддержкой RL и адаптивного управления
    """
    
    def __init__(self, tls_ids: Optional[List[str]] = None, 
                 simulation_interval: int = 5):
        """
        :param tls_ids: список ID светофоров для управления
        :param simulation_interval: интервал обновления в шагах
        """
        if tls_ids is None:
            self.tls_ids = list(traci.trafficlight.getIDList())
        else:
            self.tls_ids = tls_ids
            
        self.simulation_interval = simulation_interval
        self.step_count = 0
        
        # История метрик для каждого светофора
        self.metrics_history: Dict[str, List[TrafficMetrics]] = {
            tls_id: [] for tls_id in self.tls_ids
        }
        
        # Конфигурация фаз для каждого светофора
        self.phase_configs = self._analyze_phase_configurations()
        
        # Параметры управления
        self.min_green_time = 10  # минимальное зеленое время
        self.max_green_time = 60  # максимальное зеленое время
        self.yellow_time = 3      # время желтого сигнала
        
        # RL параметры (можно настроить)
        self.learning_rate = 0.1
        self.discount_factor = 0.9
        
        print(f"✅ Контроллер инициализирован для {len(self.tls_ids)} светофоров")
    
    def _analyze_phase_configurations(self) -> Dict[str, Dict]:
        """Анализирует конфигурацию фаз светофоров"""
        configs = {}
        
        for tls_id in self.tls_ids:
            try:
                # Получаем программу светофора
                programs = traci.trafficlight.getAllProgramLogics(tls_id)
                if not programs:
                    continue
                    
                program = programs[0]
                phases = program.phases
                
                # Анализируем фазы
                green_phases = []
                phase_durations = []
                
                for i, phase in enumerate(phases):
                    state = phase.state
                    duration = phase.duration
                    
                    # Проверяем, есть ли зеленый сигнал
                    if 'G' in state or 'g' in state:
                        green_phases.append(i)
                        phase_durations.append(duration)
                
                configs[tls_id] = {
                    'total_phases': len(phases),
                    'green_phases': green_phases,
                    'phase_durations': phase_durations,
                    'current_phase': traci.trafficlight.getPhase(tls_id),
                    'next_switch': traci.trafficlight.getNextSwitch(tls_id)
                }
                
            except traci.TraCIException as e:
                print(f"⚠️ Ошибка анализа светофора {tls_id}: {e}")
                configs[tls_id] = {'error': str(e)}
        
        return configs
    
    def collect_traffic_metrics(self, tls_id: str) -> TrafficMetrics:
        """Собирает метрики трафика для светофора"""
        metrics = TrafficMetrics()
        
        try:
            # Получаем связанные с светофором дороги
            controlled_lanes = traci.trafficlight.getControlledLanes(tls_id)
            
            vehicle_count = 0
            total_waiting = 0
            total_queue = 0
            total_speed = 0
            total_occupancy = 0
            lane_count = 0
            
            for lane_id in controlled_lanes:
                # Количество транспортных средств
                vehicles = traci.lane.getLastStepVehicleNumber(lane_id)
                vehicle_count += vehicles
                
                # Время ожидания
                waiting_time = traci.lane.getWaitingTime(lane_id)
                total_waiting += waiting_time
                
                # Длина очереди
                queue_length = traci.lane.getLastStepHaltingNumber(lane_id)
                total_queue += queue_length
                
                # Средняя скорость
                speed = traci.lane.getLastStepMeanSpeed(lane_id)
                total_speed += speed if speed > 0 else 0
                
                # Загрузка полосы
                occupancy = traci.lane.getLastStepOccupancy(lane_id)
                total_occupancy += occupancy
                
                lane_count += 1
            
            # Вычисляем средние значения
            if lane_count > 0:
                metrics.vehicle_count = vehicle_count
                metrics.waiting_time = total_waiting / lane_count
                metrics.queue_length = total_queue / lane_count
                metrics.average_speed = total_speed / lane_count
                metrics.occupancy = total_occupancy / lane_count
        
        except traci.TraCIException as e:
            print(f"⚠️ Ошибка сбора метрик для {tls_id}: {e}")
        
        return metrics
    
    def compute_reward(self, old_metrics: TrafficMetrics, 
                      new_metrics: TrafficMetrics) -> float:
        """
        Вычисляет награду на основе изменений в метриках
        Положительная награда за улучшение, отрицательная за ухудшение
        """
        reward = 0.0
        
        # Награда за уменьшение количества транспортных средств
        reward += (old_metrics.vehicle_count - new_metrics.vehicle_count) * 0.1
        
        # Награда за уменьшение времени ожидания
        reward += (old_metrics.waiting_time - new_metrics.waiting_time) * 0.2
        
        # Награда за уменьшение длины очереди
        reward += (old_metrics.queue_length - new_metrics.queue_length) * 0.3
        
        # Награда за увеличение средней скорости
        reward += (new_metrics.average_speed - old_metrics.average_speed) * 0.05
        
        # Штраф за высокую загрузку
        if new_metrics.occupancy > 0.8:
            reward -= 2.0
        
        return reward
    
    def adaptive_phase_selection(self, tls_id: str, 
                                metrics: TrafficMetrics) -> Dict[str, Any]:
        """
        Адаптивный выбор фазы на основе текущих метрик
        """
        config = self.phase_configs.get(tls_id)
        if not config or 'green_phases' not in config:
            return {'phase': 0, 'duration': self.min_green_time}
        
        green_phases = config['green_phases']
        current_phase = traci.trafficlight.getPhase(tls_id)
        
        # Простая стратегия: выбираем фазу на основе загруженности
        if metrics.queue_length > 5:
            # Высокая загрузка - длинная фаза
            duration = min(self.max_green_time, 
                          self.min_green_time + metrics.queue_length * 2)
        elif metrics.vehicle_count < 2:
            # Низкая загрузка - короткая фаза
            duration = self.min_green_time
        else:
            # Средняя загрузка - балансированная фаза
            duration = (self.min_green_time + self.max_green_time) // 2
        
        # Выбираем следующую фазу (простая ротация)
        if current_phase in green_phases:
            current_idx = green_phases.index(current_phase)
            next_idx = (current_idx + 1) % len(green_phases)
            next_phase = green_phases[next_idx]
        else:
            next_phase = green_phases[0] if green_phases else 0
        
        return {
            'phase': next_phase,
            'duration': duration,
            'yellow_time': self.yellow_time
        }
    
    def rl_phase_selection(self, tls_id: str, 
                          state: np.ndarray) -> Dict[str, Any]:
        """
        Выбор фазы с использованием подхода RL
        (упрощенная версия для начала)
        """
        # TODO: Реализовать полноценный RL алгоритм
        # Пока используем адаптивную стратегию
        metrics = TrafficMetrics()
        metrics.vehicle_count = state[0] if len(state) > 0 else 0
        metrics.queue_length = state[2] if len(state) > 2 else 0
        
        return self.adaptive_phase_selection(tls_id, metrics)
    
    def step(self, use_rl: bool = False) -> Dict[str, Dict[str, Any]]:
        """
        Выполняет один шаг управления светофорами
        :param use_rl: использовать ли RL алгоритм
        :return: словарь с примененными действиями
        """
        self.step_count += 1
        actions = {}
        
        # Обновляем каждые N шагов
        if self.step_count % self.simulation_interval != 0:
            return actions
        
        for tls_id in self.tls_ids:
            try:
                # Собираем текущие метрики
                current_metrics = self.collect_traffic_metrics(tls_id)
                self.metrics_history[tls_id].append(current_metrics)
                
                # Ограничиваем историю
                if len(self.metrics_history[tls_id]) > 100:
                    self.metrics_history[tls_id].pop(0)
                
                # Проверяем время до следующего переключения
                next_switch = traci.trafficlight.getNextSwitch(tls_id)
                current_time = traci.simulation.getTime()
                
                if next_switch - current_time > 0.5:
                    continue  # Еще рано переключать
                
                # Выбираем стратегию
                if use_rl:
                    # Преобразуем метрики в состояние для RL
                    state = current_metrics.to_array()
                    action = self.rl_phase_selection(tls_id, state)
                else:
                    action = self.adaptive_phase_selection(tls_id, current_metrics)
                
                # Применяем действие
                phase = action['phase']
                duration = action['duration']
                
                traci.trafficlight.setPhase(tls_id, phase)
                traci.trafficlight.setPhaseDuration(tls_id, duration)
                
                actions[tls_id] = {
                    'phase': phase,
                    'duration': duration,
                    'time': current_time,
                    'metrics': current_metrics.__dict__
                }
                
                # Логируем действие
                if len(actions) > 0:
                    print(f"[Шаг {self.step_count}] {tls_id}: "
                          f"фаза {phase}, длительность {duration}с")
                
            except traci.TraCIException as e:
                print(f"⚠️ Ошибка управления светофором {tls_id}: {e}")
        
        return actions
    
    def get_statistics(self) -> Dict[str, Any]:
        """Возвращает статистику по всем светофорам"""
        stats = {
            'total_tls': len(self.tls_ids),
            'total_steps': self.step_count,
            'tls_details': {}
        }
        
        for tls_id in self.tls_ids:
            history = self.metrics_history.get(tls_id, [])
            if history:
                avg_vehicles = np.mean([m.vehicle_count for m in history])
                avg_waiting = np.mean([m.waiting_time for m in history])
                avg_queue = np.mean([m.queue_length for m in history])
                
                stats['tls_details'][tls_id] = {
                    'avg_vehicles': float(avg_vehicles),
                    'avg_waiting_time': float(avg_waiting),
                    'avg_queue_length': float(avg_queue),
                    'history_length': len(history)
                }
        
        return stats


class KrasnodarEmergencyController(KrasnodarTrafficController):
    """
    Контроллер с поддержкой приоритета экстренного транспорта
    """
    
    def __init__(self, tls_ids: Optional[List[str]] = None, 
                 simulation_interval: int = 5):
        super().__init__(tls_ids, simulation_interval)
        
        # Детекторы экстренного транспорта
        self.emergency_vehicles = set()
        self.emergency_proximity = 100  # метров
        self.priority_phase_duration = 15  # секунд
    
    def detect_emergency_vehicles(self) -> List[str]:
        """Обнаруживает экстренный транспорт поблизости"""
        emergency_vehicles = []
        
        for veh_id in traci.vehicle.getIDList():
            try:
                vehicle_type = traci.vehicle.getTypeID(veh_id)
                vehicle_class = traci.vehicle.getVehicleClass(veh_id)
                
                # Проверяем тип транспортного средства
                if (vehicle_class == 'emergency' or 
                    'emergency' in vehicle_type.lower() or
                    'ambulance' in vehicle_type.lower() or
                    'fire' in vehicle_type.lower() or
                    'police' in vehicle_type.lower()):
                    
                    emergency_vehicles.append(veh_id)
                    
                    # Получаем позицию и маршрут
                    position = traci.vehicle.getPosition(veh_id)
                    route = traci.vehicle.getRoute(veh_id)
                    
                    print(f"🚑 Обнаружен экстренный транспорт: {veh_id} "
                          f"на позиции {position}")
                    
            except traci.TraCIException:
                continue
        
        return emergency_vehicles
    
    def calculate_emergency_priority(self, tls_id: str, 
                                    emergency_vehicle_id: str) -> float:
        """Вычисляет приоритет для экстренного транспорта"""
        try:
            # Позиция транспортного средства
            veh_pos = traci.vehicle.getPosition(emergency_vehicle_id)
            
            # Позиция светофора
            tls_pos = traci.junction.getPosition(tls_id)
            
            # Расстояние до светофора
            distance = ((veh_pos[0] - tls_pos[0]) ** 2 + 
                       (veh_pos[1] - tls_pos[1]) ** 2) ** 0.5
            
            # Приоритет обратно пропорционален расстоянию
            if distance < self.emergency_proximity:
                priority = 1.0 - (distance / self.emergency_proximity)
                return max(0.1, priority)
            
        except traci.TraCIException:
            pass
        
        return 0.0
    
    def step(self, use_rl: bool = False) -> Dict[str, Dict[str, Any]]:
        """
        Расширенный шаг с поддержкой экстренного транспорта
        """
        # Обнаруживаем экстренный транспорт
        emergency_vehicles = self.detect_emergency_vehicles()
        
        if emergency_vehicles:
            # Приоритетное управление для экстренных случаев
            return self.emergency_step(emergency_vehicles)
        else:
            # Обычное управление
            return super().step(use_rl)
    
    def emergency_step(self, emergency_vehicles: List[str]) -> Dict[str, Dict[str, Any]]:
        """Управление при наличии экстренного транспорта"""
        actions = {}
        
        for tls_id in self.tls_ids:
            max_priority = 0.0
            target_vehicle = None
            
            # Находим транспорт с максимальным приоритетом для этого светофора
            for veh_id in emergency_vehicles:
                priority = self.calculate_emergency_priority(tls_id, veh_id)
                if priority > max_priority:
                    max_priority = priority
                    target_vehicle = veh_id
            
            if max_priority > 0.5:  # Порог приоритета
                # Переключаем на зеленый для направления движения транспорта
                try:
                    # Получаем текущую фазу
                    current_phase = traci.trafficlight.getPhase(tls_id)
                    
                    # Получаем направление движения транспорта
                    veh_lane = traci.vehicle.getLaneID(target_vehicle)
                    if veh_lane:
                        # Упрощенная логика: устанавливаем зеленый на 15 секунд
                        green_phases = self.phase_configs[tls_id].get('green_phases', [0])
                        phase = green_phases[0]  # Первая зеленая фаза
                        
                        traci.trafficlight.setPhase(tls_id, phase)
                        traci.trafficlight.setPhaseDuration(tls_id, 
                                                          self.priority_phase_duration)
                        
                        actions[tls_id] = {
                            'phase': phase,
                            'duration': self.priority_phase_duration,
                            'emergency': True,
                            'vehicle': target_vehicle,
                            'priority': max_priority
                        }
                        
                        print(f"🚨 ПРИОРИТЕТ: {tls_id} -> фаза {phase} "
                              f"для {target_vehicle}")
                        
                except traci.TraCIException as e:
                    print(f"⚠️ Ошибка приоритетного управления {tls_id}: {e}")
        
        return actions


# Функции для использования в Jupyter Notebook
def create_krasnodar_controller(tls_ids=None, emergency_mode=False):
    """Создает контроллер для Краснодара"""
    if emergency_mode:
        return KrasnodarEmergencyController(tls_ids)
    else:
        return KrasnodarTrafficController(tls_ids)


def run_simulation_with_controller(sumo_cfg_path, steps=1000, 
                                   controller_type='adaptive',
                                   gui=True):
    """Запускает симуляцию с контроллером"""
    import subprocess
    
    # Определяем команду
    if gui:
        cmd = ['sumo-gui', '-c', sumo_cfg_path]
    else:
        cmd = ['sumo', '-c', sumo_cfg_path]
    
    # Запускаем SUMO
    traci.start(cmd)
    
    # Создаем контроллер
    if controller_type == 'emergency':
        controller = KrasnodarEmergencyController()
    else:
        controller = KrasnodarTrafficController()
    
    print(f"🚀 Запуск симуляции с контроллером {controller_type}")
    print(f"   Шагов: {steps}")
    print(f"   Светофоров: {len(controller.tls_ids)}")
    
    # Главный цикл
    for step in range(steps):
        traci.simulationStep()
        
        # Используем RL для каждого 10-го шага
        use_rl = (step % 10 == 0) and (controller_type == 'adaptive')
        actions = controller.step(use_rl=use_rl)
        
        # Прогресс
        if (step + 1) % 100 == 0:
            print(f"   Шаг {step + 1}/{steps} завершен")
    
    # Завершаем
    traci.close()
    
    # Возвращаем статистику
    stats = controller.get_statistics()
    print(f"\n📊 Статистика симуляции:")
    print(f"   Всего шагов: {stats['total_steps']}")
    print(f"   Управляемых светофоров: {stats['total_tls']}")
    
    return stats
# ============================================
# create_vehicle_models.py
# ============================================

import os
from pathlib import Path

def create_simple_vehicle_models():
    """Создает простые 3D модели транспортных средств в формате OBJ"""
    
    print("="*70)
    print("СОЗДАНИЕ 3D МОДЕЛЕЙ ТРАНСПОРТНЫХ СРЕДСТВ")
    print("="*70)
    
    # Создаем папки
    project_root = Path.cwd()
    vehicles_dir = project_root / "smart_city" / "data" / "vehicles"
    
    for subdir in ['cars', 'buses', 'trucks']:
        (vehicles_dir / subdir).mkdir(parents=True, exist_ok=True)
    
    # 1. Легковой автомобиль (седан)
    sedan_obj = '''# Simple Sedan Car Model
v 0.0 0.0 0.0
v 4.0 0.0 0.0
v 4.0 1.5 0.0
v 0.0 1.5 0.0
v 1.0 0.0 2.0
v 3.0 0.0 2.0
v 3.0 1.5 2.0
v 1.0 1.5 2.0

# Кузов
f 1 2 3 4
f 5 6 7 8
f 1 2 6 5
f 2 3 7 6
f 3 4 8 7
f 4 1 5 8

# Стекло
v 1.0 0.8 2.1
v 3.0 0.8 2.1
v 3.0 1.2 2.1
v 1.0 1.2 2.1
f 9 10 11 12

# Колеса (упрощенные)
v 0.5 -0.3 0.5
v 3.5 -0.3 0.5
v 0.5 -0.3 1.5
v 3.5 -0.3 1.5
# ... можно добавить больше деталей
'''
    
    # 2. Автобус
    bus_obj = '''# Simple Bus Model
v 0.0 0.0 0.0
v 12.0 0.0 0.0
v 12.0 3.0 0.0
v 0.0 3.0 0.0
v 0.0 0.0 2.5
v 12.0 0.0 2.5
v 12.0 3.0 2.5
v 0.0 3.0 2.5

# Кузов
f 1 2 3 4
f 5 6 7 8
f 1 2 6 5
f 2 3 7 6
f 3 4 8 7
f 4 1 5 8

# Окна
v 0.5 1.0 2.6
v 11.5 1.0 2.6
v 11.5 2.5 2.6
v 0.5 2.5 2.6
f 9 10 11 12
'''
    
    # Сохраняем модели
    with open(vehicles_dir / 'cars' / 'sedan.obj', 'w') as f:
        f.write(sedan_obj)
    
    with open(vehicles_dir / 'buses' / 'city_bus.obj', 'w') as f:
        f.write(bus_obj)
    
    print("✅ Простые 3D модели созданы")
    print(f"📁 Папка с моделями: {vehicles_dir}")
    
    # Создаем конфигурационный файл для моделей
    create_vehicle_config(vehicles_dir)
    
def create_vehicle_config(vehicles_dir):
    """Создает конфигурационный файл для транспортных средств"""
    
    config_content = '''<?xml version="1.0" encoding="UTF-8"?>
<vehicleTypes>
    <!-- Легковые автомобили -->
    <vType id="sedan" vClass="passenger" accel="2.6" decel="4.5" length="4.5" maxSpeed="50">
        <param key="3DModel" value="cars/sedan.obj"/>
        <param key="color" value="50,100,200"/>
        <param key="imgFile" value="vehicles/car_sedan.png"/>
    </vType>
    
    <vType id="suv" vClass="passenger" accel="2.4" decel="4.0" length="5.0" maxSpeed="45">
        <param key="3DModel" value="cars/suv.obj"/>
        <param key="color" value="30,120,180"/>
        <param key="imgFile" value="vehicles/car_suv.png"/>
    </vType>
    
    <vType id="sports_car" vClass="passenger" accel="3.5" decel="6.0" length="4.2" maxSpeed="80">
        <param key="3DModel" value="cars/sports_car.obj"/>
        <param key="color" value="220,50,50"/>
        <param key="imgFile" value="vehicles/car_sports.png"/>
    </vType>
    
    <vType id="taxi" vClass="passenger" accel="2.5" decel="4.5" length="4.5" maxSpeed="50">
        <param key="3DModel" value="cars/sedan.obj"/>
        <param key="color" value="255,200,0"/>
        <param key="imgFile" value="vehicles/car_taxi.png"/>
    </vType>
    
    <!-- Автобусы -->
    <vType id="city_bus" vClass="bus" accel="1.2" decel="3.0" length="12.0" maxSpeed="40">
        <param key="3DModel" value="buses/city_bus.obj"/>
        <param key="color" value="220,50,50"/>
        <param key="imgFile" value="vehicles/bus_city.png"/>
    </vType>
    
    <vType id="minibus" vClass="bus" accel="1.5" decel="3.5" length="8.0" maxSpeed="45">
        <param key="3DModel" value="buses/minibus.obj"/>
        <param key="color" value="180,60,60"/>
        <param key="imgFile" value="vehicles/bus_mini.png"/>
    </vType>
    
    <!-- Грузовики -->
    <vType id="delivery_truck" vClass="truck" accel="1.0" decel="2.5" length="8.0" maxSpeed="40">
        <param key="3DModel" value="trucks/delivery_truck.obj"/>
        <param key="color" value="50,180,50"/>
        <param key="imgFile" value="vehicles/truck_delivery.png"/>
    </vType>
    
    <vType id="trailer_truck" vClass="trailer" accel="0.8" decel="2.0" length="18.0" maxSpeed="35">
        <param key="3DModel" value="trucks/trailer_truck.obj"/>
        <param key="color" value="40,160,40"/>
        <param key="imgFile" value="vehicles/truck_trailer.png"/>
    </vType>
    
    <!-- Специальный транспорт -->
    <vType id="emergency" vClass="emergency" accel="3.0" decel="5.0" length="5.0" maxSpeed="70">
        <param key="3DModel" value="cars/sedan.obj"/>
        <param key="color" value="255,0,0"/>
        <param key="imgFile" value="vehicles/car_emergency.png"/>
    </vType>
    
    <vType id="bicycle" vClass="bicycle" accel="0.8" decel="1.5" length="1.8" maxSpeed="25">
        <param key="color" value="255,100,100"/>
        <param key="imgFile" value="vehicles/bicycle.png"/>
    </vType>
    
    <vType id="motorcycle" vClass="motorcycle" accel="3.0" decel="5.0" length="2.2" maxSpeed="70">
        <param key="color" value="150,50,200"/>
        <param key="imgFile" value="vehicles/motorcycle.png"/>
    </vType>
</vehicleTypes>'''
    
    config_file = vehicles_dir / "vehicle_types.xml"
    with open(config_file, 'w', encoding='utf-8') as f:
        f.write(config_content)
    
    print(f"✅ Конфигурационный файл создан: {config_file}")
    
    return config_file

if __name__ == "__main__":
    create_simple_vehicle_models()
# ============================================
# krasnodar_tripinfo_calculator.py
# Исправленный калькулятор метрик
# ============================================

import xml.etree.ElementTree as ET
import os
import json
import math

def calculate_realistic_efficiency(tripinfo_file_path: str) -> dict:
    """
    Вычисляет реалистичные метрики на основе tripinfo.xml.
    Вместо Z0 использует теоретически минимальное время поездок.
    """
    if not os.path.exists(tripinfo_file_path):
        print(f"Файл с логами {tripinfo_file_path} не найден")
        return None

    print(f"Анализируем файл: {tripinfo_file_path}")

    try:
        tree = ET.parse(tripinfo_file_path)
        root = tree.getroot()

        total_time_loss = 0.0
        total_duration = 0.0
        total_route_length = 0.0
        total_depart_delay = 0.0
        total_waiting_time = 0.0
        total_speed = 0.0
        vehicle_count = 0
        
        # Собираем дополнительные статистики
        durations = []
        time_losses = []
        route_lengths = []

        for trip in root.findall('tripinfo'):
            # Основные метрики
            time_loss = float(trip.get('timeLoss', 0))
            duration = float(trip.get('duration', 0))
            route_length = float(trip.get('routeLength', 0))
            depart_delay = float(trip.get('departDelay', 0))
            waiting_time = float(trip.get('waitingTime', 0))
            
            # Вычисляем среднюю скорость
            if duration > 0:
                speed = route_length / duration
            else:
                speed = 0
            
            total_time_loss += time_loss
            total_duration += duration
            total_route_length += route_length
            total_depart_delay += depart_delay
            total_waiting_time += waiting_time
            total_speed += speed
            vehicle_count += 1
            
            durations.append(duration)
            time_losses.append(time_loss)
            route_lengths.append(route_length)

        if vehicle_count == 0:
            print("Нет данных о транспортных средствах")
            return None

        # Базовые средние
        avg_delay = total_time_loss / vehicle_count
        avg_duration = total_duration / vehicle_count
        avg_route_length = total_route_length / vehicle_count
        avg_speed = total_speed / vehicle_count
        avg_waiting_time = total_waiting_time / vehicle_count

        # Вычисляем теоретическое минимальное время (средняя скорость 50 км/ч ≈ 13.89 м/с)
        # Добавляем 10% на разгон/торможение
        theoretical_min_time = total_route_length / 13.89 * 1.1
        
        # Эффективность как отношение теоретического времени к фактическому
        if theoretical_min_time > 0:
            efficiency = theoretical_min_time / total_duration
            efficiency = min(1.0, max(0.0, efficiency))  # Ограничиваем 0-1
        else:
            efficiency = 0.0
            
        # Дополнительные метрики
        if time_losses:
            delay_std = math.sqrt(sum((x - avg_delay) ** 2 for x in time_losses) / len(time_losses))
        else:
            delay_std = 0.0
            
        # Коэффициент задержки (отношение времени ожидания к общему времени)
        if total_duration > 0:
            delay_ratio = total_time_loss / total_duration
        else:
            delay_ratio = 0.0

        metrics = {
            'total_vehicles': vehicle_count,
            'total_time_loss': total_time_loss,
            'total_duration': total_duration,
            'total_route_length': total_route_length,
            'total_waiting_time': total_waiting_time,
            'total_depart_delay': total_depart_delay,
            
            'average_delay': avg_delay,
            'average_duration': avg_duration,
            'average_route_length': avg_route_length,
            'average_speed': avg_speed,
            'average_waiting_time': avg_waiting_time,
            
            'delay_std_deviation': delay_std,
            'delay_ratio': delay_ratio,
            'efficiency': efficiency,
            
            # Дополнительные показатели
            'max_duration': max(durations) if durations else 0,
            'min_duration': min(durations) if durations else 0,
            'max_delay': max(time_losses) if time_losses else 0,
            'min_delay': min(time_losses) if time_losses else 0,
            
            # Оценка производительности
            'performance_score': efficiency * (1 - delay_ratio) * 100,
        }

        return metrics

    except ET.ParseError as e:
        print(f"Ошибка парсинга XML: {e}")
        return None
    except Exception as e:
        print(f"Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return None


def print_detailed_metrics(metrics: dict):
    """Выводит подробные метрики"""
    if metrics is None:
        print("Нет данных для отображения")
        return

    print("\n" + "="*70)
    print("ПОДРОБНАЯ СТАТИСТИКА ЭФФЕКТИВНОСТИ")
    print("="*70)
    
    print(f"\n📊 ОСНОВНЫЕ ПОКАЗАТЕЛИ:")
    print(f"   Количество ТС: {metrics['total_vehicles']}")
    print(f"   Общая длина маршрутов: {metrics['total_route_length']:.0f} м")
    print(f"   Общее время в пути: {metrics['total_duration']:.1f} сек")
    
    print(f"\n⏱️  ЗАДЕРЖКИ:")
    print(f"   Общая задержка: {metrics['total_time_loss']:.1f} сек")
    print(f"   Средняя задержка на ТС: {metrics['average_delay']:.1f} сек")
    print(f"   Стандартное отклонение: {metrics['delay_std_deviation']:.1f} сек")
    print(f"   Коэфф. задержки (время_задержки/время_пути): {metrics['delay_ratio']:.3f}")
    
    print(f"\n🚗 СКОРОСТЬ:")
    print(f"   Средняя скорость: {metrics['average_speed']:.2f} м/с ({metrics['average_speed']*3.6:.1f} км/ч)")
    print(f"   Средняя длина поездки: {metrics['average_route_length']:.0f} м")
    print(f"   Среднее время поездки: {metrics['average_duration']:.1f} сек")
    
    print(f"\n📈 ЭФФЕКТИВНОСТЬ:")
    print(f"   Теоретическая эффективность: {metrics['efficiency']:.3f}")
    print(f"   Общий балл производительности: {metrics['performance_score']:.1f}")
    
    print(f"\n📋 ДИАПАЗОНЫ:")
    print(f"   Минимальная задержка: {metrics['min_delay']:.1f} сек")
    print(f"   Максимальная задержка: {metrics['max_delay']:.1f} сек")
    print(f"   Минимальное время поездки: {metrics['min_duration']:.1f} сек")
    print(f"   Максимальное время поездки: {metrics['max_duration']:.1f} сек")
    
    # Оценка эффективности
    print(f"\n🎯 ОЦЕНКА СИСТЕМЫ:")
    efficiency = metrics['efficiency']
    if efficiency > 0.85:
        print("   ✅ ОТЛИЧНО! Система работает эффективно")
    elif efficiency > 0.7:
        print("   👍 ХОРОШО! Система работает хорошо")
    elif efficiency > 0.5:
        print("   ⚠️  УДОВЛЕТВОРИТЕЛЬНО! Есть возможности для улучшения")
    elif efficiency > 0.3:
        print("   ❗ ПЛОХО! Требуются значительные улучшения")
    else:
        print("   ❌ КРИТИЧЕСКИ ПЛОХО! Система неэффективна")
    
    print("="*70)


def save_metrics_json(metrics: dict, output_dir: str = "result", filename: str = "krasnodar_metrics.json"):
    """Сохраняет метрики в JSON файл"""
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, filename)
    
    if metrics is None:
        result = {
            "status": "ERROR",
            "message": "Не удалось вычислить метрики"
        }
    else:
        result = {
            "status": "SUCCESS",
            "metrics": metrics,
            "summary": {
                "total_vehicles": metrics['total_vehicles'],
                "total_duration": round(metrics['total_duration'], 2),
                "average_delay": round(metrics['average_delay'], 2),
                "efficiency": round(metrics['efficiency'], 4),
                "performance_score": round(metrics['performance_score'], 2)
            }
        }
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print(f"\n📁 Метрики сохранены в: {output_path}")
    return output_path


def analyze_tripinfo_quality(tripinfo_file_path: str):
    """Анализирует качество данных в tripinfo файле"""
    if not os.path.exists(tripinfo_file_path):
        print(f"Файл не найден: {tripinfo_file_path}")
        return
    
    try:
        tree = ET.parse(tripinfo_file_path)
        root = tree.getroot()
        
        trips = list(root.findall('tripinfo'))
        print(f"\n🔍 АНАЛИЗ ФАЙЛА {tripinfo_file_path}")
        print(f"   Всего записей: {len(trips)}")
        
        if trips:
            # Проверяем первую запись
            first_trip = trips[0]
            print(f"\n   Пример записи:")
            for attr in first_trip.attrib:
                print(f"     {attr}: {first_trip.get(attr)[:50]}...")
            
            # Проверяем наличие критических полей
            required_fields = ['timeLoss', 'duration', 'routeLength']
            missing_fields = []
            for field in required_fields:
                if field not in first_trip.attrib:
                    missing_fields.append(field)
            
            if missing_fields:
                print(f"\n   ⚠️  Отсутствуют поля: {missing_fields}")
            else:
                print(f"\n   ✅ Все необходимые поля присутствуют")
                
    except Exception as e:
        print(f"Ошибка анализа файла: {e}")


if __name__ == "__main__":
    # Тестирование
    tripinfo_file = "result/tripinfo.xml"
    if os.path.exists(tripinfo_file):
        analyze_tripinfo_quality(tripinfo_file)
        metrics = calculate_realistic_efficiency(tripinfo_file)
        print_detailed_metrics(metrics)
        save_metrics_json(metrics)
    else:
        print(f"Файл {tripinfo_file} не найден для тестирования")
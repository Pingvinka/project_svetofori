# ============================================
# simple_krasnodar_controller.py
# Упрощенный контроллер для тестирования
# ============================================

import traci
import time

class SimpleKrasnodarController:
    """
    Простой контроллер для управления светофорами Краснодара
    """
    
    def __init__(self, tls_ids=None):
        if tls_ids is None:
            self.tls_ids = list(traci.trafficlight.getIDList())
        else:
            self.tls_ids = tls_ids
        
        print(f"🚦 Простой контроллер для {len(self.tls_ids)} светофоров")
        self.step_count = 0
    
    def step(self):
        """Простой шаг управления"""
        self.step_count += 1
        
        for tls_id in self.tls_ids:
            try:
                # Проверяем время до следующего переключения
                next_switch = traci.trafficlight.getNextSwitch(tls_id)
                current_time = traci.simulation.getTime()
                
                if next_switch - current_time < 1.0:
                    # Переключаем на следующую фазу
                    current_phase = traci.trafficlight.getPhase(tls_id)
                    programs = traci.trafficlight.getAllProgramLogics(tls_id)
                    
                    if programs:
                        total_phases = len(programs[0].phases)
                        next_phase = (current_phase + 1) % total_phases
                        
                        # Устанавливаем длительность в зависимости от шага
                        duration = 30
                        if self.step_count % 100 < 50:
                            duration = 20  # Более короткие фазы в первой половине
                        
                        traci.trafficlight.setPhase(tls_id, next_phase)
                        traci.trafficlight.setPhaseDuration(tls_id, duration)
                        
                        if self.step_count % 100 == 0:
                            print(f"[Шаг {self.step_count}] {tls_id}: фаза {next_phase}")
            
            except Exception as e:
                print(f"⚠️ Ошибка в {tls_id}: {e}")
        
        return {}

def create_simple_controller():
    """Создает простой контроллер"""
    return SimpleKrasnodarController()
